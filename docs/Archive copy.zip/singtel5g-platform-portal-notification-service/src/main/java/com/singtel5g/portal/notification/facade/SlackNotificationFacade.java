/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.facade;

import com.singtel5g.portal.core.function.ErrorHandlingType;
import com.singtel5g.portal.core.function.GenericServiceFunction;
import com.singtel5g.portal.core.function.Orchestrator;
import com.singtel5g.portal.core.function.TransactionType;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import com.singtel5g.portal.notification.common.Constants;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link SlackNotificationFacade} is extend by the {@link
 * CoreNotificationFacade}. all of Email related validations and processes implements using this
 * class.
 */
@Lazy
@Component
public class SlackNotificationFacade extends CoreNotificationFacade {

    /**
     * Additional send notifications validation derivation.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    @Override
    protected void additionalSendNotificationsValidationDerivation(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
    }

    /**
     * Additional send notifications processing.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    @Override
    protected void additionalSendNotificationsProcessing(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        GenericServiceFunction[] func1 = {
                () -> coreProcessor.sendSlackMessages(notificationRequestBeans, notificationResponseBean)
        };
        Orchestrator.execute(
                Constants.SEND_NOTIFICATION, TransactionType.NOT, ErrorHandlingType.GROUP, func1);
    }
}
