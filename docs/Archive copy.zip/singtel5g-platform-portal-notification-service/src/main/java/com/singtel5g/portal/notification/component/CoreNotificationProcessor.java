/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.component;

import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.CoreNotificationResponseBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link CoreNotificationProcessor} process all the validated requests for
 * notification related and call particular endpoints.
 *
 * <h3>Usage :</h3>
 * <p> <u>for email</u></p>
 * <pre>
 *     {@code
 *     public void sendEmails(
 *             List<NotificationRequestBean> notificationRequestBeans,
 *             NotificationResponseBean notificationResponseBean)
 *     }
 * </pre>
 *
 * <pre>
 *     {@code
 *         public void sendSlackMessages(
 *             List<NotificationRequestBean> notificationRequestBeans,
 *             NotificationResponseBean notificationResponseBean)
 *             }
 * </pre>
 */
@Component
public class CoreNotificationProcessor {
    private final ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);
    /**
     * The Core notification integrator.
     */
    @Autowired
    CoreNotificationIntegrator coreNotificationIntegrator;

    /**
     * Send emails.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    @SneakyThrows
    public void sendEmails(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        CompletionService<CoreNotificationResponseBean> completionService =
                new ExecutorCompletionService<>(executor);
        notificationRequestBeans.parallelStream()
                .forEach(
                        notificationRequestBean ->
                                completionService.submit(
                                        () ->
                                                coreNotificationIntegrator.sendEmail(
                                                        notificationRequestBean.getFrom(),
                                                        notificationRequestBean.getRecipients(),
                                                        notificationRequestBean.getSubject(),
                                                        notificationRequestBean.getMessage())));

        buildResponse(notificationRequestBeans, notificationResponseBean, completionService);
    }

    /**
     * Build response. Here collecting all the Futures and build response from Futures
     *
     * <pre>{@code
     * Future<CoreNotificationResponseBean> resultFuture =
     *                     completionService.take();
     * }***
     * }</pre>
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     * @param completionService        the completion service
     * @throws InterruptedException the interrupted exception
     */
    protected void buildResponse(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean,
            CompletionService<CoreNotificationResponseBean> completionService)
            throws InterruptedException {
        int received = 0;
        boolean errors = false;
        while (received < notificationRequestBeans.size() && !errors) {
            Future<CoreNotificationResponseBean> resultFuture = completionService.take();
            try {
                CoreNotificationResponseBean result = resultFuture.get();
                received++;
                if (null != notificationResponseBean.getResult()) {
                    List<CoreNotificationResponseBean> resultLit =
                            (List<CoreNotificationResponseBean>) notificationResponseBean.getResult();
                    resultLit.add(result);
                }
            } catch (Exception e) {
                LogUtils.ERROR(CoreNotificationProcessor.class, "buildResponse", e.getMessage(), e);
                errors = true;
            }
        }
    }

    /**
     * Send slack messages.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    @SneakyThrows
    public void sendSlackMessages(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        CompletionService<CoreNotificationResponseBean> completionService =
                new ExecutorCompletionService<>(executor);
        notificationRequestBeans.parallelStream()
                .forEach(
                        notificationRequestBean ->
                                notificationRequestBean.getRecipients().parallelStream()
                                        .forEach(
                                                urlSlackWebHook ->
                                                        completionService.submit(
                                                                () ->
                                                                        coreNotificationIntegrator.sendMessageToSlack(
                                                                                urlSlackWebHook,
                                                                                notificationRequestBean.getSubject(),
                                                                                notificationRequestBean.getMessage()))));
        buildResponse(notificationRequestBeans, notificationResponseBean, completionService);
    }

    /**
     * Initiate response bean.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    public void initiateResponseBean(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        List<String> result = new ArrayList<>();
        notificationResponseBean.setResult(result);
        notificationResponseBean.setResultCode(HttpStatus.OK);
    }
}
