/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.facade;

import com.singtel5g.portal.core.function.ErrorHandlingType;
import com.singtel5g.portal.core.function.GenericServiceFunction;
import com.singtel5g.portal.core.function.Orchestrator;
import com.singtel5g.portal.core.function.TransactionType;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import com.singtel5g.portal.notification.common.Constants;
import com.singtel5g.portal.notification.component.CoreNotificationProcessor;
import com.singtel5g.portal.notification.component.CoreNotificationValidatorDerivator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This abstract class {@link CoreNotificationFacade} working as base class for the
 * notification related validations and process. all of common validations , processes and
 * Integration need to be handle on this class.
 *
 * <h3>Examples :</h3>
 *
 * <u>validations</u>
 *
 * <ul>
 *   <li>validate Base request Form
 *   <li>validate Base request Message
 * </ul>
 *
 * <u>processes</u>
 *
 * <ul>
 *   <li>Initialize response list
 * </ul>
 *
 * <u>Integration</u>
 *
 * <ul>
 *   <li>Send details to other system. ex: Audit
 * </ul>
 */
@Component
public abstract class CoreNotificationFacade {
    /**
     * The Core validator.
     */
    @Autowired
    CoreNotificationValidatorDerivator coreValidator;
    /**
     * The Core processor.
     */
    @Autowired
    CoreNotificationProcessor coreProcessor;

    /* ==============================Send Notifications===================================*/

    /**
     * Send notifications notification response bean.
     *
     * @param notificationRequestBeans the notification request beans
     * @return the notification response bean
     */
    public NotificationResponseBean sendNotifications(
            List<NotificationRequestBean> notificationRequestBeans) {
        NotificationResponseBean notificationResponseBean = new NotificationResponseBean();
        sendNotificationsValidationDerivation(notificationRequestBeans, notificationResponseBean);
        additionalSendNotificationsValidationDerivation(
                notificationRequestBeans, notificationResponseBean);
        sendNotificationsProcessing(notificationRequestBeans, notificationResponseBean);
        additionalSendNotificationsProcessing(notificationRequestBeans, notificationResponseBean);
        sendNotificationsIntegration(notificationRequestBeans, notificationResponseBean);
        return notificationResponseBean;
    }

    /**
     * Send notifications validation derivation.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    protected void sendNotificationsValidationDerivation(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        GenericServiceFunction[] func = {
                () ->
                        coreValidator.validateNotificationBaseForm(
                                notificationRequestBeans, notificationResponseBean),
                () ->
                        coreValidator.validateNotificationBaseMessage(
                                notificationRequestBeans, notificationResponseBean)
        };
        Orchestrator.execute(
                Constants.SEND_NOTIFICATION, TransactionType.NOT, ErrorHandlingType.GROUP, func);
    }

    /**
     * Additional send notifications validation derivation.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    protected abstract void additionalSendNotificationsValidationDerivation(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean);

    /**
     * Send notifications processing.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    protected void sendNotificationsProcessing(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        GenericServiceFunction[] func = {
                () -> coreProcessor.initiateResponseBean(notificationRequestBeans, notificationResponseBean),
        };
        Orchestrator.execute(
                Constants.SEND_NOTIFICATION, TransactionType.NOT, ErrorHandlingType.GROUP, func);
    }

    /**
     * Additional send notifications processing.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    protected abstract void additionalSendNotificationsProcessing(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean);

    /**
     * Send notifications integration.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    protected void sendNotificationsIntegration(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
    }
}
