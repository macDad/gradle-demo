/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.proxy;

import com.singtel5g.portal.core.exception.ErrorCodes;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.notification.common.Constants;
import com.singtel5g.portal.security.component.KeyVaults;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by   : dave.soh@Singtel
 * Date         : 14/12/2022
 * Project      : singtel5g-platform-portal-notification-service
 * Since        : Version 6.17
 * Description  : VaultProxy
 */
@Component
public class VaultProxy {

    @Value("${spring.application.name}")
    public String applicationName;

    @Autowired
    private KeyVaults keyVaults;

    private static final String FETCH_SECRET_FROM_VAULT = "fetchSecretFromVault";

    /**
     * Method to fetch secret from key vault
     * @return the vault secret containing username and password
     */
    public Map<String,String> fetchSecretFromVault(String ... keys) {
        Map<String,String> vaultSecret = new HashMap<>();
        for(String key : keys) {
            String value = keyVaults.retrieveKeyVault(key);
            if (!ObjectUtils.isNullOrEmpty(value)) {
                vaultSecret.put(key,value);
            } else {
                LogUtils.ERROR(this.getClass(), FETCH_SECRET_FROM_VAULT, Constants.INVALID_RESPONSE_VAULT_PROXY + key);
                throw ExceptionUtils.newNetworkUnreachableException(applicationName, ErrorCodes.API_GENERIC_ERROR, Constants.INVALID_RESPONSE_VAULT_PROXY + key);
            }
        }

        return vaultSecret;
    }


}