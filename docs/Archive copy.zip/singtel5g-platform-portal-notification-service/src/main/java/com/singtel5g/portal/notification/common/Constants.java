// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

package com.singtel5g.portal.notification.common;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jetbrains.annotations.NonNls;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link Constants} Constant class to add project related Constants
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Constants {

  public static final String INVALID_RESPONSE_VAULT_PROXY =
      "Received invalid response while fetching secret from Vault for key : ";
  public static final String EMAIL_USERNAME_KEY = "email.username";
  public static final String EMAIL_PASSWORD_KEY = "email.password";

    /**
     * The constant EMAIL.
     */
    @NonNls
    public static final String EMAIL = "EMAIL";
    /**
     * The constant SLACK.
     */
    @NonNls
    public static final String SLACK = "SLACK";
    /**
     * The constant SEND_NOTIFICATION.
     */
    @NonNls
    public static final String SEND_NOTIFICATION = "send_notification";
}
