/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.singtel5g.portal.core.exception.NetworkUnreachableException;
import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.notification.bean.SlackMessage;
import com.singtel5g.portal.notification.bean.response.CoreNotificationResponseBean;
import com.singtel5g.portal.notification.common.Constants;
import com.singtel5g.portal.notification.proxy.VaultProxy;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import static java.text.MessageFormat.format;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link CoreNotificationIntegrator} allows to manage send notifications
 * fro endpoints.
 *
 * <h3>Usage :</h3>
 *
 * <pre>{@code
 * @Autowired
 * CoreNotificationIntegrator coreNotificationIntegrator;
 *
 * coreNotificationIntegrator.sendEmail(
 *                notificationRequestBean.getFrom(),
 *                notificationRequestBean.getRecipients(),
 *                notificationRequestBean.getSubject(),
 *                notificationRequestBean.getMessage())));
 * }****
 * </pre>
 *
 * <hr>
 *
 * <h3><em><u>for send email using the following method :</u></em></h3>
 *
 * <pre>{@code
 * public CoreNotificationResponseBean sendEmail(
 *                                       String from,
 *                                       List<String> recipients,
 *                                       String subject,
 *                                       Object messageBody)
 * }****
 * </pre>
 *
 * <p><hr>
 *
 * <h3><em><u>for send Slack using the following method :</u></em></h3>
 *
 * <pre>{@code
 *     public CoreNotificationResponseBean sendMessageToSlack(
 *                                     String urlSlackWebHook,
 *                                     String subject,
 *                                     Object notificationRequestBeanMessage)
 * }****
 * </pre>
 *
 * <hr>
 */
@Component
public class CoreNotificationIntegrator {

    /**
     * The Mail smtp host.
     */
    @Value("${mail.smtp.host}")
    String mailSmtpHost;

    /**
     * The Mail smtp port.
     */
    @Value("${mail.smtp.port}")
    String mailSmtpPort;

    /**
     * The Mail smtp auth.
     */
    @Value("${mail.smtp.auth}")
    String mailSmtpAuth;

    @Value("${mail.smtp.startTls:false}")
    String startTls;

    /**
     * The Mail smtp socket factory port.
     */
    @Value("${mail.smtp.socket.factory.port}")
    String mailSmtpSocketFactoryPort;

    /**
     * The Mail smtp ssl checkserveridentity.
     */
    @Value("${mail.smtp.ssl.checkserveridentity}")
    String mailSmtpSslCheckserveridentity;

  @Autowired VaultProxy vaultProxy;

  /**
   * Send email.
   *
   * @param from the from
   * @param recipients the recipients
   * @param subject the subject
   * @param messageBody the message body
   * @return the core notification response bean
   */
  public CoreNotificationResponseBean sendEmail(
      String from, List<String> recipients, String subject, Object messageBody) {

    Properties prop = new Properties();
    buildEmailProperties(prop);
    Map<String, String> secret;
    try {
      secret =
          vaultProxy.fetchSecretFromVault(
              Constants.EMAIL_PASSWORD_KEY, Constants.EMAIL_USERNAME_KEY);
    } catch (NetworkUnreachableException mex) {
      return new CoreNotificationResponseBean(
          "EMAIL", "FAILED", format("Error occurred while send Email with subject: {0}", subject));
    }

    Session session =
        Session.getInstance(
            prop,
            new javax.mail.Authenticator() {
              @Override
              protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(
                    secret.get(Constants.EMAIL_USERNAME_KEY),
                    secret.get(Constants.EMAIL_PASSWORD_KEY));
              }
            });

    try {
      Message message = new MimeMessage(session);
      message.setFrom(new InternetAddress(from));
      final var recipientString = recipients.stream().collect(Collectors.joining(","));
      message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientString));
      message.setSubject(subject);
      message.setContent(messageBody, "text/html; charset=utf-8");
      Transport.send(message);

      LogUtils.INFO(
          CoreNotificationIntegrator.class,
          "sendEmail",
          format("Email sent with subject: {0}", subject));
      return new CoreNotificationResponseBean(
          "EMAIL", "SUCCESS", format("Email sent with subject: {0}", subject));

    } catch (Exception mex) {
      LogUtils.ERROR(
          CoreNotificationIntegrator.class,
          "sendEmail",
          format("Error occurred while send Email with subject: {0}", subject),
          mex.getCause());
      return new CoreNotificationResponseBean(
          "EMAIL", "FAILED", format("Error occurred while send Email with subject: {0}", subject));
    }
  }

    /**
     * Build email properties.
     *
     * @param prop the prop
     */
    protected void buildEmailProperties(Properties prop) {

        prop.put("mail.smtp.host", mailSmtpHost);
        prop.put("mail.smtp.port", mailSmtpPort);
        prop.put("mail.smtp.auth", mailSmtpAuth);
        prop.put("mail.smtp.starttls.enable", startTls);
        prop.put("mail.smtp.socketFactory.port", mailSmtpSocketFactoryPort);
        prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        prop.put("mail.smtp.ssl.checkserveridentity", mailSmtpSslCheckserveridentity);
    }

    /**
     * Send message to slack.
     *
     * @param urlSlackWebHook                the url slack web hook
     * @param subject                        the subject
     * @param notificationRequestBeanMessage the notification request bean message
     * @return core notification response bean
     */
    public CoreNotificationResponseBean sendMessageToSlack(
            String urlSlackWebHook, String subject, Object notificationRequestBeanMessage) {
        StringBuilder messageBuider = new StringBuilder();
        messageBuider.append(notificationRequestBeanMessage);
        return processMessageToSlack(urlSlackWebHook, messageBuider.toString());
    }

    /**
     * Process message to slack.
     *
     * @param urlSlackWebHook the url slack web hook
     * @param message         the message
     * @return core notification response bean
     */
    protected CoreNotificationResponseBean processMessageToSlack(
            String urlSlackWebHook, String message) {
        SlackMessage payload =
                SlackMessage.builder()
                        .channel("#app-alerts")
                        .username("Paragon Notification")
                        .iconEmoji(":rocket:")
                        .text(message)
                        .build();
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(urlSlackWebHook);
            ObjectMapper objectMapper = new ObjectMapper();
            String json = objectMapper.writeValueAsString(payload);

            StringEntity entity = new StringEntity(json);
            httpPost.setEntity(entity);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");
            client.execute(httpPost);

            LogUtils.INFO(
                    CoreNotificationIntegrator.class,
                    "processMessageToSlack",
                    format("Slack message sent to urlSlackWebHook: {0}", urlSlackWebHook));
            return new CoreNotificationResponseBean(
                    "SLACK",
                    "SUCCESS",
                    format("Slack message sent to urlSlackWebHook: {0}", urlSlackWebHook));
        } catch (IOException e) {
            LogUtils.ERROR(CoreNotificationIntegrator.class, "processMessageToSlack", e.getMessage(), e);
            return new CoreNotificationResponseBean(
                    "SLACK",
                    "FAILED",
                    format(
                            "Error occurred while send Slack message to urlSlackWebHook :{0}", urlSlackWebHook));
        }
    }
}
