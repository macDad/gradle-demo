/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.component;

import com.singtel5g.portal.core.exception.ErrorCodes;
import com.singtel5g.portal.core.utils.DateUtils;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.core.utils.StringUtils;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 8/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link CoreNotificationIntegrator} use for validate all the request
 * parameters before process.
 */
@Component
public class CoreNotificationValidatorDerivator {

    /**
     * The constant APPLICATION_NAME.
     */
    @Value("${spring.application.name}")
    public  String APPLICATION_NAME;

    /**
     * Validate notification base form.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    public void validateNotificationBaseForm(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        if (ObjectUtils.isNullOrEmpty(notificationRequestBeans))
            throw ExceptionUtils.newValidationException(
                    APPLICATION_NAME,
                    ErrorCodes.VALIDATION_PARSE_ERROR,
                    "NotificationRequestBeans List cannot be null or empty.");
        notificationRequestBeans.forEach(
                notificationRequestBean -> {
                    if (ObjectUtils.isNullOrEmpty(notificationRequestBean))
                        throw ExceptionUtils.newValidationException(
                                APPLICATION_NAME,
                                ErrorCodes.VALIDATION_PARSE_ERROR,
                                "NotificationRequestBean cannot be null or empty.");
                    if (ObjectUtils.isNullOrEmpty(notificationRequestBean.getType()))
                        throw ExceptionUtils.newValidationException(
                                APPLICATION_NAME,
                                ErrorCodes.VALIDATION_PARSE_ERROR,
                                "NotificationRequestBean Type cannot be null or empty.");
                    if (!ObjectUtils.isNullOrEmpty(notificationRequestBean.getSequenceNumber()))
                        notificationRequestBean.setSequence(true);
                    if (StringUtils.isNullOrBlank(notificationRequestBean.getCurrentISODate()))
                        notificationRequestBean.setCurrentISODate(DateUtils.currentISODateFormat());
                });
    }

    /**
     * Validate notification request bean list.
     *
     * @param notificationRequestBeans2 the notification request beans 2
     * @param s                         the s
     */
    public void validateNotificationRequestBeanList(Object notificationRequestBeans2, String s) {
        if (ObjectUtils.isNullOrEmpty(notificationRequestBeans2)) {
            throw ExceptionUtils.newValidationException(
                    APPLICATION_NAME, ErrorCodes.VALIDATION_PARSE_ERROR, s);
        }
    }

    /**
     * Validate notification base message.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    public void validateNotificationBaseMessage(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        validateNotificationRequestBeanList(
                notificationRequestBeans, "NotificationRequestBeans List cannot be null or empty.");
        notificationRequestBeans.forEach(
                notificationRequestBean -> {
                    if (ObjectUtils.isNullOrEmpty(notificationRequestBean.getRecipients()))
                        throw ExceptionUtils.newValidationException(
                                APPLICATION_NAME,
                                ErrorCodes.VALIDATION_PARSE_ERROR,
                                "NotificationRequestBean Recipients cannot be null or empty.");
                    validateNotificationRequestBeanList(
                            notificationRequestBean.getMessage(),
                            "NotificationRequestBean Message cannot be null or empty.");
                });
    }

    /**
     * Validate email recipients.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    public void validateEmailRecipients(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        validateNotificationRequestBeanList(
                notificationRequestBeans, "NotificationRequestBeans List cannot be null or empty.");
        for (NotificationRequestBean notificationRequestBean : notificationRequestBeans) {
            for (String recipient : notificationRequestBean.getRecipients()) {
                if (StringUtils.isNullOrBlank(recipient))
                    throw ExceptionUtils.newValidationException(
                            APPLICATION_NAME,
                            ErrorCodes.VALIDATION_PARSE_ERROR,
                            "NotificationRequestBean recipient email cannot be null or empty.");
                if (!isValidEmailAddress(recipient))
                    throw ExceptionUtils.newValidationException(
                            APPLICATION_NAME,
                            ErrorCodes.VALIDATION_PARSE_ERROR,
                            "NotificationRequestBean recipient email address: {"
                                    + recipient
                                    + "} format not correct.");
            }
        }
    }

    /**
     * Is valid email address boolean.
     *
     * @param email the email
     * @return the boolean
     */
    public static boolean isValidEmailAddress(String email) {
        String emailRegex =
                "^[a-zA-Z0-9_+&*-]+(?:\\."
                        + "[a-zA-Z0-9_+&*-]+)*@"
                        + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                        + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        if (email == null) return false;
        return pat.matcher(email).matches();
    }

    /**
     * Validate email sender.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    public void validateEmailSender(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        validateNotificationRequestBeanList(
                notificationRequestBeans, "NotificationRequestBeans List cannot be null or empty.");
        for (NotificationRequestBean notificationRequestBean : notificationRequestBeans) {
            final var from = notificationRequestBean.getFrom();
            if (StringUtils.isNullOrBlank(from))
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME,
                        ErrorCodes.VALIDATION_PARSE_ERROR,
                        "NotificationRequestBean sender email cannot be null or empty.");

            if (!isValidEmailAddress(from))
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME,
                        ErrorCodes.VALIDATION_PARSE_ERROR,
                        "NotificationRequestBean sender email address: {" + from + "} format not correct.");
        }
    }

    /**
     * Validate subject.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    public void validateSubject(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        validateNotificationRequestBeanList(
                notificationRequestBeans, "NotificationRequestBeans List cannot be null or empty.");
        for (NotificationRequestBean notificationRequestBean : notificationRequestBeans) {
            final var subject = notificationRequestBean.getSubject();
            if (StringUtils.isNullOrBlank(subject))
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME,
                        ErrorCodes.VALIDATION_PARSE_ERROR,
                        "NotificationRequestBean subject cannot be null or empty.");
        }
    }

    /**
     * Validate message.
     *
     * @param notificationRequestBeans the notification request beans
     * @param notificationResponseBean the notification response bean
     */
    public void validateMessage(
            List<NotificationRequestBean> notificationRequestBeans,
            NotificationResponseBean notificationResponseBean) {
        validateNotificationRequestBeanList(
                notificationRequestBeans, "NotificationRequestBeans List cannot be null or empty.");
        for (NotificationRequestBean notificationRequestBean : notificationRequestBeans) {
            final var msg = notificationRequestBean.getMessage();
            if (ObjectUtils.isNullOrEmpty(msg))
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME,
                        ErrorCodes.VALIDATION_PARSE_ERROR,
                        "NotificationRequestBean msg cannot be null or empty.");
        }
    }
}
