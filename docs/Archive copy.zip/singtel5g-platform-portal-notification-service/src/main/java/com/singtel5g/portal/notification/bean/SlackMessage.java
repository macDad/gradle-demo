/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.bean;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link SlackMessage} use for Slack messages model.
 */
@AllArgsConstructor
@Builder(builderClassName = "Builder")
@Getter
@Setter
public class SlackMessage implements Serializable {

    /**
     * You can add the thread_ts parameter to your POST request in order to make your message appear
     * as a reply in a thread.
     */
    String threadTs;

    /**
     * The first step is to prepare this message as a key/value pair in JSON. For a simple message,
     * your JSON payload only needs to define a text property, containing the text that will be posted
     * to the channel.
     */
    String text;

    /**
     * Incoming webhooks originate from a default identity you configured when originally creating
     * your webhook. You can override a custom integration's configured name with the username field
     * in your JSON payload.
     */
    String username;
    /**
     * Incoming webhooks output to a default channel and can only send messages to a single channel at
     * a time. You can override a custom integration's configured channel by specifying the channel
     * field in your JSON payload.
     *
     * <p>Specify a Slack channel by name with "channel": "#other-channel", or send a Slackbot message
     * to a specific user with "channel": "@username".
     */
    String channel;

    /**
     * You can also override the bot icon either with icon_url or icon_emoji.
     */
    String iconUrl;
    /**
     * You can also override the bot icon either with icon_url or icon_emoji.
     */
    String iconEmoji;
}
