/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.facade;

import com.singtel5g.portal.notification.common.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link NotificationFacadeFactory} working as a Factory to initialize the
 * the facade according to the given type..
 *
 * <p>
 *     If there is new notification type here need to autowired Facade class and need to implement
 *     get Instance method. finally return insert inside the getFacade method.
 * </p>
 * <pre>
 *     {@code
 *          @Autowired
 *          NotificationFacadeFactory facadeFactory;
 *
 *          final var facade = facadeFactory.getFacade(
 *                                              "EMAIL",
 *                                              Constants.SEND_NOTIFICATION);
 *     }
 * </pre>
 */
@Component
public class NotificationFacadeFactory {
    /**
     * The Email notification facade.
     */
    @Lazy
    @Autowired
    private EmailNotificationFacade emailNotificationFacade;
    /**
     * The Slack notification facade.
     */
    @Lazy
    @Autowired
    private SlackNotificationFacade slackNotificationFacade;

    /**
     * Gets facade.
     *
     * @param type      the type
     * @param signature the signature
     * @return the facade
     */
    public CoreNotificationFacade getFacade(String type, String signature) {

        switch (type) {
            case Constants.EMAIL:
                return getEmailNotificationFacadeInstance();
            case Constants.SLACK:
                return getSlackNotificationFacadeInstance();
        }
        return null;
    }

    /**
     * Gets email notification facade instance.
     *
     * @return the email notification facade instance
     */
    public EmailNotificationFacade getEmailNotificationFacadeInstance() {
        return emailNotificationFacade;
    }

    /**
     * Gets slack notification facade instance.
     *
     * @return the slack notification facade instance
     */
    public SlackNotificationFacade getSlackNotificationFacadeInstance() {
        return slackNotificationFacade;
    }
}
