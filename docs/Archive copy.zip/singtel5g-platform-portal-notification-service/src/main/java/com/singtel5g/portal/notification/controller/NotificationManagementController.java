/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.notification.controller;

import com.singtel5g.portal.core.annotation.LogEnabled;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.CoreNotificationResponseBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import com.singtel5g.portal.notification.common.Constants;
import com.singtel5g.portal.notification.facade.NotificationFacadeFactory;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link NotificationManagementController} is Rest controller for
 * Notification Management.
 */
@LogEnabled
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping("/api/v1/notification")
@Tag(name = "NotificationManagementController", description = "Notification Management API")
public class NotificationManagementController {

    /**
     * The constant SEND_NOTIFICATION.
     */
    protected static final String SEND_NOTIFICATION = "/send";

    /**
     * The Facade factory.
     */
    @Autowired
    NotificationFacadeFactory facadeFactory;

    /**
     * Send notification response entity.
     *
     * @param notificationRequestBeanMap the notification request bean map
     * @return the response entity
     */
    @Operation(
            summary = "Send Notifications for given types and notifications list",
            description = "",
            tags = {"NotificationManagementController"})
    @ApiResponses(
            value = {
                    @ApiResponse(
                            responseCode = "200",
                            description = "successful operation",
                            content = @Content(schema = @Schema(implementation = NotificationResponseBean.class))),
                    @ApiResponse(
                            responseCode = "404",
                            description = "Notification API not found",
                            content = @Content(schema = @Schema(implementation = NotificationResponseBean.class))),
                    @ApiResponse(
                            responseCode = "400",
                            description = "Bad Request, Notification type not supported",
                            content = @Content(schema = @Schema(implementation = NotificationResponseBean.class))),
                    @ApiResponse(
                            responseCode = "500",
                            description = "Failure",
                            content = @Content(schema = @Schema(implementation = NotificationResponseBean.class)))
            })
    @PostMapping(SEND_NOTIFICATION)
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    public ResponseEntity<?> sendNotification(
            @Valid @RequestBody Map<String, List<NotificationRequestBean>> notificationRequestBeanMap) {
        try {
            var notificationResponseBeans = new ArrayList<>();
            notificationRequestBeanMap.entrySet().parallelStream()
                    .forEach(
                            entry -> {
                                final var facade =
                                        facadeFactory.getFacade(entry.getKey(), Constants.SEND_NOTIFICATION);
                                if (ObjectUtils.isNullOrEmpty(facade)) {
                                    final var errorMsg =
                                            MessageFormat.format(
                                                    "Notification type: '{'{0}'}' not supported.", entry.getKey());
                                    LogUtils.ERROR(
                                            NotificationManagementController.class, "sendNotification", errorMsg);
                                    List<CoreNotificationResponseBean> resultList = new ArrayList<>();
                                    resultList.add(
                                            new CoreNotificationResponseBean(entry.getKey(), "FAILED", errorMsg));
                                    notificationResponseBeans.add(
                                            new NotificationResponseBean(resultList, HttpStatus.BAD_REQUEST));
                                } else {
                                    NotificationResponseBean notificationResponseBean =
                                            facade.sendNotifications(entry.getValue());
                                    notificationResponseBeans.add(notificationResponseBean);
                                }
                            });
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            return new ResponseEntity<>(notificationResponseBeans, headers, HttpStatus.OK);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ExceptionUtils.formatExceptionMessage(e));
        }
    }
}
