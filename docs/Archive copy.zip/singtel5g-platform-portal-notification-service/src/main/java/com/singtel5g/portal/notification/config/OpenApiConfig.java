/*
 *  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************
 */

package com.singtel5g.portal.notification.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 6/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link OpenApiConfig} The type Open api config.
 */
@Configuration
public class OpenApiConfig {

    /**
     * The Api controller package.
     */
    @Value("${api-package}")
    public String apiControllerPackage;
    /**
     * The Application name.
     */
    @Value("${application.name}")
    public String applicationName;

    /**
     * The Application contact name.
     */
    @Value("${application.contact.name}")
    public String applicationContactName;

    /**
     * The Application contact url.
     */
    @Value("${application.contact.url}")
    public String applicationContactUrl;

    /**
     * The Application contact email.
     */
    @Value("${application.contact.email}")
    public String applicationContactEmail;
    /**
     * The Application description.
     */
    @Value("${application.description}")
    public String applicationDescription;

    @Value("${application.apache.license.url}")
    private String apacheLicenseUrl;

    @Value("${application.version}")
    private String version;

    /**
     * Custom open api open api.
     *
     * @return the open api
     */
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI().components(new Components()).info(apiEndPointsInfo());
    }

    private Info apiEndPointsInfo() {
        /**
         * The constant LICENSE.
         */
        License LICENSE = new License().name("Apache 2.0").url(apacheLicenseUrl);
        /**
         * The constant DEFAULT_CONTACT.
         */
        Contact DEFAULT_CONTACT =
                new Contact()
                        .name(applicationContactName)
                        .url(applicationContactUrl)
                        .email(applicationContactEmail);
        return new Info()
                .title(applicationName)
                .description(applicationDescription)
                .contact(DEFAULT_CONTACT)
                .license(LICENSE)
                .version(version);
    }
}
