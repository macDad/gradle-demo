/*
 *  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************
 */

package com.singtel5g.portal.notification.config;

import com.singtel5g.portal.core.aop.LoggingAspect;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 6/10/2020<br>
 * Project      : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link AppConfig} is use for config application related main
 * configuration .
 */
@Configuration
public class AppConfig {

    /**
     * Rest template rest template.
     *
     * @return the rest template
     */
    @Bean
    public RestTemplate restTemplate() {

        return new RestTemplate();
    }

    /**
     * Transaction manager mongo transaction manager.
     *
     * @param dbFactory the db factory
     * @return the mongo transaction manager
     */
    @Bean
    MongoTransactionManager transactionManager(MongoDatabaseFactory dbFactory) {
        return new MongoTransactionManager(dbFactory);
    }

    /**
     * LoggingAspect.
     *
     * @return LoggingAspect logging aspect
     */
    @Bean
    public LoggingAspect loggingAspect() {
        LoggingAspect aspect = new LoggingAspect();
        aspect.setEnableDataScrubbing(true);
        aspect.setDefaultScrubbedValue("*******");
        aspect.setParamBlacklistRegex("private.*");
        aspect.setCustomParamBlacklist(new HashSet<>(Arrays.asList("securityProtocol")));
        return aspect;
    }
}
