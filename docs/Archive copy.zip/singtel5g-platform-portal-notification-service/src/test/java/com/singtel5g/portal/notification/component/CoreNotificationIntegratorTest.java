package com.singtel5g.portal.notification.component;

import com.singtel5g.portal.notification.bean.response.CoreNotificationResponseBean;
import com.singtel5g.portal.notification.common.Constants;
import com.singtel5g.portal.notification.proxy.VaultProxy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.config.environment.Environment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Transport;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

/**
 * The type Core notification integrator test.
 *
 * @author <B>MadukaJ@Singtel</B>
 * @version 1.0
 * @since <pre>Nov 5, 2020</pre> Description : This class {@link CoreNotificationIntegratorTest} CoreNotificationIntegrator Tester.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest({Transport.class, CloseableHttpClient.class})
@ActiveProfiles("test")
@SpringBootTest
@TestPropertySource(locations = "classpath:application-unit-test.properties")
@PowerMockIgnore({ "javax.net.ssl.*" })
public class CoreNotificationIntegratorTest {
    /**
     * The Core notification integrator.
     */
    @InjectMocks
    protected CoreNotificationIntegrator coreNotificationIntegrator;
    /**
     * The Prop.
     */
    @Mock
    Properties prop;
    /**
     * The CloseableHttpClient.
     */
    @Mock
    CloseableHttpClient closeableHttpClient;
    @Mock
    HttpClients httpClients;
    /**
     * The Environment.
     */
    @MockBean
    Environment mockEnvironment;

  @Mock VaultProxy vaultProxy;
  /**
   * Sets up.
   *
   * @throws Exception the exception
   */
  @Before
  public void setUp() throws Exception {
    MockitoAnnotations.initMocks(this);
    coreNotificationIntegrator = new CoreNotificationIntegrator();
    coreNotificationIntegrator.mailSmtpHost = "smtp.gmail.com";
    coreNotificationIntegrator.mailSmtpPort = "465";
    coreNotificationIntegrator.mailSmtpAuth = "true";
    coreNotificationIntegrator.mailSmtpSocketFactoryPort = "465";
    coreNotificationIntegrator.mailSmtpSslCheckserveridentity = "true";
    coreNotificationIntegrator.startTls = "true";
    coreNotificationIntegrator.vaultProxy = vaultProxy;
  }

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {}

    /**
     * After.
     *
     * @throws Exception the exception
     */
    @After
    public void after() throws Exception {
    }

  /**
   * Method: sendEmail(String from, List<String> recipients, String subject, Object messageBody)
   *
   * @throws Exception the exception
   */
  @Test
  public void testSendEmail() throws Exception {
    List<String> recipients = new ArrayList<>();
    recipients.add("recipients1");
    recipients.add("recipients2");
    recipients.add("recipients3");
    PowerMockito.mockStatic(Transport.class);
    PowerMockito.doNothing().when(Transport.class, "send", any(Message.class));
    when(vaultProxy.fetchSecretFromVault(ArgumentMatchers.any()))
        .thenReturn(
            Map.of(
                Constants.EMAIL_USERNAME_KEY,
                "TEST USERNAME",
                Constants.EMAIL_PASSWORD_KEY,
                "TEST PASSWORD"));

    CoreNotificationResponseBean coreNotificationResponseBean =
        coreNotificationIntegrator.sendEmail("from", recipients, "subject", "messageBody");
    assertEquals("EMAIL", coreNotificationResponseBean.getType());
    assertEquals("SUCCESS", coreNotificationResponseBean.getStatus());
  }

  /**
   * Method: sendEmail(String from, List<String> recipients, String subject, Object messageBody)
   *
   * @throws Exception the exception
   */
  @Test
  public void testSendEmailForException() throws Exception {
    List<String> recipients = new ArrayList<>();
    recipients.add("recipients1");
    PowerMockito.mockStatic(Transport.class);
    PowerMockito.doThrow(new MessagingException("Error occurred"))
        .when(Transport.class, "send", any(Message.class));
    when(vaultProxy.fetchSecretFromVault(ArgumentMatchers.any()))
        .thenReturn(
            Map.of(
                Constants.EMAIL_USERNAME_KEY,
                "TEST USERNAME",
                Constants.EMAIL_PASSWORD_KEY,
                "TEST PASSWORD"));
    CoreNotificationResponseBean coreNotificationResponseBean =
        coreNotificationIntegrator.sendEmail("from", recipients, "subject", "messageBody");
    assertEquals("EMAIL", coreNotificationResponseBean.getType());
    assertEquals("FAILED", coreNotificationResponseBean.getStatus());
  }

  /**
   * Method: sendEmail(String from, null, String subject, Object messageBody)
   *
   * @throws Exception the exception
   */
  @Test
  public void testSendEmailForEmptyProperties() throws Exception {
    PowerMockito.mockStatic(Transport.class);
    PowerMockito.doNothing().when(Transport.class, "send", any(Message.class));
    when(vaultProxy.fetchSecretFromVault(any()))
        .thenReturn(
            Map.of(
                Constants.EMAIL_USERNAME_KEY,
                "TEST USERNAME",
                Constants.EMAIL_PASSWORD_KEY,
                "TEST PASSWORD"));
    CoreNotificationResponseBean coreNotificationResponseBean =
        coreNotificationIntegrator.sendEmail(null, null, null, null);
    assertEquals("FAILED", coreNotificationResponseBean.getStatus());
  }

    /**
     * Method: buildEmailProperties(Properties prop)
     *
     * @throws Exception the exception
     */
    @Test
    public void testBuildEmailProperties() throws Exception {
        when(prop.put(any(), any())).thenReturn(prop);
        coreNotificationIntegrator.buildEmailProperties(prop);
    }

    /**
     * Method: sendMessageToSlack(String urlSlackWebHook, String subject, Object
     * notificationRequestBeanMessage)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendMessageToSlack() throws Exception {
        when(closeableHttpClient.execute(any())).thenReturn(null);
        CoreNotificationResponseBean coreNotificationResponseBean =
                coreNotificationIntegrator.sendMessageToSlack(
                        "urlSlackWebHook", "subject", "notificationRequestBeanMessage");
        assertEquals("SLACK",coreNotificationResponseBean.getType());
        assertEquals("FAILED",coreNotificationResponseBean.getStatus());
    }

    /**
     * Method: sendMessageToSlack(String urlSlackWebHook, String subject, Object
     * notificationRequestBeanMessage)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendMessageToSlackForException() throws Exception {
        when(closeableHttpClient.execute(any())).thenReturn(null);
        CoreNotificationResponseBean coreNotificationResponseBean =
                coreNotificationIntegrator.sendMessageToSlack(
                "urlSlackWebHook", "subject", "notificationRequestBeanMessage");
        assertEquals("SLACK",coreNotificationResponseBean.getType());
        assertEquals("FAILED",coreNotificationResponseBean.getStatus());
    }

}
