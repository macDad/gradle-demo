package com.singtel5g.portal.notification.component;

import com.singtel5g.portal.core.enums.NotificationTypes;
import com.singtel5g.portal.core.exception.ValidationException;
import com.singtel5g.portal.core.utils.DateUtils;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import com.singtel5g.portal.notification.util.TestUtils;
import io.cucumber.java.an.Dada;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * The type Core notification validator derivator test.
 *
 * @author <B>MadukaJ@Singtel</B>
 * @version 1.0
 * @since <pre>Nov 5, 2020</pre> Description : This class {@link CoreNotificationValidatorDerivatorTest} CoreNotificationValidatorDerivator Tester.
 */
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class CoreNotificationValidatorDerivatorTest {

    /**
     * The Instance under test.
     */
    private final CoreNotificationValidatorDerivator instanceUnderTest =
            new CoreNotificationValidatorDerivator();


    /**
     * Method: validateNotificationBaseForm
     *
     */
    @Test
    @DisplayName("Test validate Notification Base Form For Valid Inputs")
    public void testValidateNotificationBaseFormForInvalidType() {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        List<String> recipients = new ArrayList<>();
        recipients.add("testb@gmail.com");
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                null,
                "5gsingnotification@gmail.com",
                recipients,
                "Mail Subject1",
                "Mail Test 1."));
        assertThatThrownBy(
                () -> instanceUnderTest.
                        validateNotificationBaseForm(notificationRequestBeanList
                                , new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);
    }

    /**
     * Method: validateNotificationBaseForm
     *
     */
    @Test
    @DisplayName("Test validate Notification Base Form For Empty Seq Number")
    public void testValidateNotificationBaseFormForEmptySeqNumber() {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        List<String> recipients = new ArrayList<>();
        recipients.add("testb@gmail.com");
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients,
                "Mail Subject1",
                "Mail Test 1."));
        assertThatCode(
                () -> instanceUnderTest.
                        validateNotificationBaseForm(notificationRequestBeanList
                                , new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }


    /**
     * Method: validateNotificationBaseForm
     *
     */
    @Test
    @DisplayName("Test validate Notification Base Form For Empty ISO date")
    public void testValidateNotificationBaseFormForEmptyISODate() {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        List<String> recipients = new ArrayList<>();
        recipients.add("testb@gmail.com");
        NotificationRequestBean notificationRequestBean = TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients,
                "Mail Subject1",
                "Mail Test 1.");
        notificationRequestBean.setSequenceNumber(1l);
        notificationRequestBeanList.add(notificationRequestBean);
        assertThatCode(
                () -> instanceUnderTest.
                        validateNotificationBaseForm(notificationRequestBeanList
                                , new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }

    /**
     * Method: validateNotificationBaseForm
     *
     */
    @Test
    @DisplayName("Test validate Notification Base Form For Valid Inputs")
    public void testValidateNotificationBaseFormWithValidInputs() {
        List<NotificationRequestBean> notificationRequestBeanList = TestUtils.
                buildAndReturnNotificationBeanList();
        assertThatCode(
                () -> instanceUnderTest.
                        validateNotificationBaseForm(notificationRequestBeanList
                                , new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }

    /**
     * Method: validateNotificationBaseForm(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    @DisplayName("Test validate Notification Base Form For InValid Inputs")
    public void testValidateNotificationBaseForm() throws Exception {
        assertThatThrownBy(
                () ->
                        instanceUnderTest.validateNotificationBaseForm(
                                new ArrayList<>(), new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);

        assertThatThrownBy(() -> instanceUnderTest.validateNotificationBaseForm(null, null))
                .isExactlyInstanceOf(ValidationException.class);
    }


    /**
     * Method: TestValidateNotificationBaseMessageForValidInputs()
     *
     */
    @Test
    @DisplayName("Test validate Notification Base Message For Valid Inputs")
    public void testValidateNotificationBaseMessageForValidInputs() throws Exception {
        assertThatCode(
                () -> instanceUnderTest.
                        validateNotificationBaseMessage(TestUtils.buildNotificationRequestBeansList()
                                , new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }

    /**
     * Method: validateNotificationBaseMessage(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    @DisplayName("Test validate Notification Base Message For InValid Inputs")
    public void testValidateNotificationBaseMessage() throws Exception {
        assertThatThrownBy(
                () ->
                        instanceUnderTest.validateNotificationBaseMessage(
                                new ArrayList<>(), new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);

        assertThatThrownBy(() -> instanceUnderTest.validateNotificationBaseMessage(null, null))
                .isExactlyInstanceOf(ValidationException.class);
    }

    /**
     * Method: ValidateEmailRecipientsForValidInputs
     */
    @Test
    @DisplayName("Test validate Notification Email Recipients For Valid Inputs")
    public void testValidateEmailRecipientsForValidInputs(){
        List<NotificationRequestBean> notificationRequestBeanList = TestUtils.
                buildAndReturnNotificationBeanList();
        assertThatCode(
                () ->
                        instanceUnderTest.validateEmailRecipients(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }

    /**
     * Method: TestValidateEmailRecipientsForInValidRecipientAddress
     */
    @Test
    @DisplayName("Test validate Notification Email Recipients For InValid Recipient Address")
    public void testValidateEmailRecipientsForInValidRecipientAddress() {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        List<String> recipients = new ArrayList<>();
        recipients.add("invalidRecipientAddress");
        recipients.add("testb@gmail.com");
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients,
                "Mail Subject1",
                "Mail Test 1."));
        assertThatThrownBy(
                () ->
                        instanceUnderTest.validateEmailRecipients(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);
    }

    /**
     * Method: TestValidateEmailRecipientsForEmptyRecipient
     */
    @Test
    @DisplayName("Test validate Notification Email Recipients For Empty Recipient Address")
    public void testValidateEmailRecipientsForEmptyRecipient()  {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                null,
                "Mail Subject1",
                "Mail Test 1."));
        assertThrows(
                Exception.class,
                () ->
                        instanceUnderTest.validateEmailRecipients(
                        notificationRequestBeanList, new NotificationResponseBean()));
    }



    /**
     * Method: isValidEmailAddress(String email)
     */
    @Test
    @DisplayName("Test validate Email Address For InValid Inputs")
    public void testIsValidEmailAddress(){

        assertThat(CoreNotificationValidatorDerivator.isValidEmailAddress("")).isFalse();

        assertThat(CoreNotificationValidatorDerivator.isValidEmailAddress(null)).isFalse();
    }

    /**
     * Method: testValidateEmailSenderForValidSender
     */
    @Test
    @DisplayName("Test validate Email Sender For valid Sender")
    public void testValidateEmailSenderForValidSender(){
        List<NotificationRequestBean> notificationRequestBeanList = TestUtils.
                buildAndReturnNotificationBeanList();
        assertThatCode(
                () ->
                        instanceUnderTest.validateEmailSender(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }

    /**
     * Method: testValidateEmailSenderForInvalidSender
     */
    @Test
    @DisplayName("Test validate Email Sender For Invalid Sender")
    public void testValidateEmailSenderForInvalidSender(){
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotificationInvalidSender",
                new ArrayList<>(),
                "Mail Subject1",
                "Mail Test 1."));
        assertThatThrownBy(
                () ->
                        instanceUnderTest.validateEmailSender(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);
    }

    /**
     * Method: testValidateEmailSenderForEmptySender
     *
     * @throws Exception the exception
     */
    @Test
    @DisplayName("Test validate Email Sender For Empty Sender")
    public void testValidateEmailSenderForEmptySender() throws Exception {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "",
                new ArrayList<>(),
                "Mail Subject1",
                "Mail Test 1."));
        assertThatThrownBy(
                () ->
                        instanceUnderTest.validateEmailSender(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);
    }

    /**
     * Method: testValidateSubjectForValidSubject
     */
    @Test
    @DisplayName("Test validate Email Sender For valid Subject")
    public void testValidateSubjectForValidSubject(){
        List<NotificationRequestBean> notificationRequestBeanList = TestUtils.
                buildAndReturnNotificationBeanList();
        assertThatCode(
                () ->
                        instanceUnderTest.validateSubject(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }
    /**
     * Method: TestValidateSubjectForEmptySubject
     *
     * @throws Exception the exception
     */
    @Test
    @DisplayName("Test validate Subject For Empty Subject")
    public void testValidateSubjectForEmptySubject() throws Exception {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                new ArrayList<>(),
                "",
                "Mail Test 1."));
        assertThatThrownBy(
                () ->
                        instanceUnderTest.validateSubject(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);
    }

    /**
     * Method: testValidateMessageForEmptyMessage
     */
    @Test
    @DisplayName("Test validate Email Sender For valid Message")
    public void testValidateMessageForValidMessage(){
        List<NotificationRequestBean> notificationRequestBeanList = TestUtils.
                buildAndReturnNotificationBeanList();
        assertThatCode(
                () ->
                        instanceUnderTest.validateMessage(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .doesNotThrowAnyException();
    }
    /**
     * Method: TestValidateMessageForEmptyMessage
     *
     * @throws Exception the exception
     */
    @Test
    @DisplayName("Test validate Message For EmptyMessage")
    public void testValidateMessageForEmptyMessage() throws Exception {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        notificationRequestBeanList.add(TestUtils.buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                new ArrayList<>(),
                "subject",
                ""));
        assertThatThrownBy(
                () ->
                        instanceUnderTest.validateMessage(
                                notificationRequestBeanList, new NotificationResponseBean()))
                .isExactlyInstanceOf(ValidationException.class);
    }
}
