package com.singtel5g.portal.notification.facade;

import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import com.singtel5g.portal.notification.component.CoreNotificationProcessor;
import com.singtel5g.portal.notification.component.CoreNotificationValidatorDerivator;
import com.singtel5g.portal.notification.util.TestUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

/**
 *
 * @author <B>MadukaJ@Singtel</B>
 * @version 1.0
 * @since <pre>Nov 5, 2020</pre>
 * Description : This class {@link CoreNotificationFacadeTest} The type CoreNotificationFacade Tester.
 */
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class CoreNotificationFacadeTest {
    /**
     * The Core validator.
     */
    @Mock
    CoreNotificationValidatorDerivator coreValidator;

    /**
     * The Core processor.
     */
    @Mock
    CoreNotificationProcessor coreProcessor;
    /**
     * The Facade.
     */
    @Mock
    CoreNotificationFacade facade;

    /**
     * Method: sendNotifications(List<NotificationRequestBean> notificationRequestBeans)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendNotifications() throws Exception {

        doNothing().when(coreValidator).validateEmailRecipients(any(), any());
        doNothing().when(coreValidator).validateEmailSender(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseForm(any(), any());
        doNothing().when(coreValidator).validateMessage(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseMessage(any(), any());
        doNothing().when(coreValidator).validateSubject(any(), any());
        doNothing().when(coreProcessor).sendEmails(any(), any());
        doNothing().when(coreProcessor).sendSlackMessages(any(), any());
        doNothing().when(coreProcessor).initiateResponseBean(any(), any());
        List<NotificationRequestBean> notificationRequestBeans =
                TestUtils.buildNotificationRequestBeansList();
        facade.sendNotifications(notificationRequestBeans);
        assertThatCode(() -> facade.sendNotifications(notificationRequestBeans))
                .doesNotThrowAnyException();
    }

    /**
     * Method: sendNotificationsValidationDerivation(List<NotificationRequestBean>
     * notificationRequestBeans, NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendNotificationsValidationDerivation() throws Exception {
        doNothing().when(coreValidator).validateEmailRecipients(any(), any());
        doNothing().when(coreValidator).validateEmailSender(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseForm(any(), any());
        doNothing().when(coreValidator).validateMessage(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseMessage(any(), any());
        doNothing().when(coreValidator).validateSubject(any(), any());
        doNothing().when(coreProcessor).sendEmails(any(), any());
        doNothing().when(coreProcessor).sendSlackMessages(any(), any());
        doNothing().when(coreProcessor).initiateResponseBean(any(), any());
        List<NotificationRequestBean> notificationRequestBeans =
                TestUtils.buildNotificationRequestBeansList();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        assertThatCode(
                () ->
                        facade.sendNotificationsValidationDerivation(
                                notificationRequestBeans, notificationResponseBean))
                .doesNotThrowAnyException();
    }

    /**
     * Method: additionalSendNotificationsValidationDerivation(List<NotificationRequestBean>
     * notificationRequestBeans, NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testAdditionalSendNotificationsValidationDerivation() throws Exception {
        doNothing().when(coreValidator).validateEmailRecipients(any(), any());
        doNothing().when(coreValidator).validateEmailSender(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseForm(any(), any());
        doNothing().when(coreValidator).validateMessage(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseMessage(any(), any());
        doNothing().when(coreValidator).validateSubject(any(), any());
        doNothing().when(coreProcessor).sendEmails(any(), any());
        doNothing().when(coreProcessor).sendSlackMessages(any(), any());
        doNothing().when(coreProcessor).initiateResponseBean(any(), any());
        List<NotificationRequestBean> notificationRequestBeans =
                TestUtils.buildNotificationRequestBeansList();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        assertThatCode(
                () ->
                        facade.additionalSendNotificationsValidationDerivation(
                                notificationRequestBeans, notificationResponseBean))
                .doesNotThrowAnyException();
    }

    /**
     * Method: sendNotificationsProcessing(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendNotificationsProcessing() throws Exception {
        doNothing().when(coreValidator).validateEmailRecipients(any(), any());
        doNothing().when(coreValidator).validateEmailSender(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseForm(any(), any());
        doNothing().when(coreValidator).validateMessage(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseMessage(any(), any());
        doNothing().when(coreValidator).validateSubject(any(), any());
        doNothing().when(coreProcessor).sendEmails(any(), any());
        doNothing().when(coreProcessor).sendSlackMessages(any(), any());
        doNothing().when(coreProcessor).initiateResponseBean(any(), any());
        List<NotificationRequestBean> notificationRequestBeans =
                TestUtils.buildNotificationRequestBeansList();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        assertThatCode(
                () ->
                        facade.sendNotificationsProcessing(
                                notificationRequestBeans, notificationResponseBean))
                .doesNotThrowAnyException();
    }

    /**
     * Method: additionalSendNotificationsProcessing(List<NotificationRequestBean>
     * notificationRequestBeans, NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testAdditionalSendNotificationsProcessing() throws Exception {
        doNothing().when(coreValidator).validateEmailRecipients(any(), any());
        doNothing().when(coreValidator).validateEmailSender(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseForm(any(), any());
        doNothing().when(coreValidator).validateMessage(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseMessage(any(), any());
        doNothing().when(coreValidator).validateSubject(any(), any());
        doNothing().when(coreProcessor).sendEmails(any(), any());
        doNothing().when(coreProcessor).sendSlackMessages(any(), any());
        doNothing().when(coreProcessor).initiateResponseBean(any(), any());
        List<NotificationRequestBean> notificationRequestBeans =
                TestUtils.buildNotificationRequestBeansList();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        assertThatCode(
                () ->
                        facade.additionalSendNotificationsProcessing(
                                notificationRequestBeans, notificationResponseBean))
                .doesNotThrowAnyException();
    }

    /**
     * Method: sendNotificationsIntegration(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendNotificationsIntegration() throws Exception {
        doNothing().when(coreValidator).validateEmailRecipients(any(), any());
        doNothing().when(coreValidator).validateEmailSender(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseForm(any(), any());
        doNothing().when(coreValidator).validateMessage(any(), any());
        doNothing().when(coreValidator).validateNotificationBaseMessage(any(), any());
        doNothing().when(coreValidator).validateSubject(any(), any());
        doNothing().when(coreProcessor).sendEmails(any(), any());
        doNothing().when(coreProcessor).sendSlackMessages(any(), any());
        doNothing().when(coreProcessor).initiateResponseBean(any(), any());
        List<NotificationRequestBean> notificationRequestBeans =
                TestUtils.buildNotificationRequestBeansList();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        assertThatCode(
                () ->
                        facade.sendNotificationsIntegration(
                                notificationRequestBeans, notificationResponseBean))
                .doesNotThrowAnyException();
    }
}
