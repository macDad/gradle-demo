package com.singtel5g.portal.notification.component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.singtel5g.portal.core.utils.JsonUtils;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.CoreNotificationResponseBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import com.singtel5g.portal.notification.util.TestUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionService;
import java.util.concurrent.Future;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * The type Core notification processor test.
 *
 * @author <B>MadukaJ@Singtel</B>
 * @version 1.0
 * @since <pre>Nov 5, 2020</pre> Description : This class {@link CoreNotificationProcessorTest} CoreNotificationProcessor Tester.
 */
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(
        classes = {CoreNotificationProcessor.class, JsonUtils.class, ObjectMapper.class})
public class CoreNotificationProcessorTest {
    /**
     * The Core notification processor.
     */
    @InjectMocks
    protected CoreNotificationProcessor coreNotificationProcessor;
    /**
     * The Completion service.
     */
    @Mock
    CompletionService<CoreNotificationResponseBean> completionService;
    /**
     * The Result future.
     */
    @Mock
    Future<CoreNotificationResponseBean> resultFuture;
    @MockBean
    private CoreNotificationIntegrator coreNotificationIntegrator;

    /**
     * Sets up.
     *
     * @throws Exception the exception
     */
    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        PodamFactory podam = new PodamFactoryImpl();
        CoreNotificationResponseBean notificationResponseBeans =
                podam.manufacturePojoWithFullData(CoreNotificationResponseBean.class);
        when(coreNotificationIntegrator.sendMessageToSlack(any(), any(), any()))
                .thenReturn(notificationResponseBeans);
    }

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
    }

    /**
     * After.
     *
     * @throws Exception the exception
     */
    @After
    public void after() throws Exception {
    }

    /**
     * Method: sendEmails(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendEmails() throws Exception {
        PodamFactory podam = new PodamFactoryImpl();
        List<NotificationRequestBean> notificationRequestBeans =
                podam.manufacturePojo(ArrayList.class, NotificationRequestBean.class);
        NotificationResponseBean notificationResponseBean = new NotificationResponseBean();
        notificationResponseBean.setResultCode(HttpStatus.OK);
        CoreNotificationResponseBean notificationResponseBeans =
                podam.manufacturePojoWithFullData(CoreNotificationResponseBean.class);
        when(completionService.take())
                .thenReturn(CompletableFuture.completedFuture(notificationResponseBeans));
        CoreNotificationProcessor spy = spy(coreNotificationProcessor);
        doNothing().when(spy).buildResponse(any(), any(), any());
        spy.sendEmails(notificationRequestBeans, notificationResponseBean);
        assertEquals(HttpStatus.OK, notificationResponseBean.getResultCode());
    }

    /**
     * Method: buildResponse(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean,
     * CompletionService<CoreNotificationResponseBean> completionService)
     *
     * @throws Exception the exception
     */
    @Test
    public void testBuildResponse() throws Exception {
        PodamFactory podam = new PodamFactoryImpl();
        List<NotificationRequestBean> notificationRequestBeans =
                podam.manufacturePojo(ArrayList.class, NotificationRequestBean.class);
        CoreNotificationResponseBean result = new CoreNotificationResponseBean();
        List<CoreNotificationResponseBean> resultLit = new ArrayList<>();
        NotificationResponseBean notificationResponseBean = new NotificationResponseBean();
        notificationResponseBean.setResult(resultLit);
        when(completionService.take()).thenReturn(resultFuture);
        when(resultFuture.get()).thenReturn(result);
        coreNotificationProcessor.buildResponse(
                notificationRequestBeans, notificationResponseBean, completionService);
    }

    /**
     * Method: sendSlackMessages(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testSendSlackMessages() throws Exception {
        PodamFactory podam = new PodamFactoryImpl();
        List<NotificationRequestBean> notificationRequestBeans =
                podam.manufacturePojo(ArrayList.class, NotificationRequestBean.class);
        NotificationResponseBean notificationResponseBean = new NotificationResponseBean();
        notificationResponseBean.setResultCode(HttpStatus.OK);
        CoreNotificationResponseBean notificationResponseBeans =
                podam.manufacturePojoWithFullData(CoreNotificationResponseBean.class);

        when(completionService.take())
                .thenReturn(CompletableFuture.completedFuture(notificationResponseBeans));
        CoreNotificationProcessor spy = spy(coreNotificationProcessor);
        doNothing().when(spy).buildResponse(any(), any(), any());
        spy.sendSlackMessages(notificationRequestBeans, notificationResponseBean);
        assertEquals(HttpStatus.OK, notificationResponseBean.getResultCode());
    }

    /**
     * Method: testBuildResponseForValidInputs
     */
    @Test
    public void testBuildResponseForValidInputs() throws Exception {
        PodamFactory podam = new PodamFactoryImpl();
        List<NotificationRequestBean> notificationRequestBeans = TestUtils.buildNotificationRequestBeansList();
        NotificationResponseBean notificationResponseBean = new NotificationResponseBean();
        notificationResponseBean.setResultCode(HttpStatus.OK);
        CoreNotificationResponseBean notificationResponseBeans =
                podam.manufacturePojoWithFullData(CoreNotificationResponseBean.class);

        when(completionService.take())
                .thenReturn(CompletableFuture.completedFuture(notificationResponseBeans));
        coreNotificationProcessor.buildResponse(notificationRequestBeans,notificationResponseBean,completionService);

/*        CoreNotificationProcessor spy = spy(coreNotificationProcessor);
        spy.buildResponse(notificationRequestBeans,notificationResponseBean,completionService);*/
        assertEquals(HttpStatus.OK, notificationResponseBean.getResultCode());
    }

    /**
     * Method: initiateResponseBean(List<NotificationRequestBean> notificationRequestBeans,
     * NotificationResponseBean notificationResponseBean)
     *
     * @throws Exception the exception
     */
    @Test
    public void testInitiateResponseBean() throws Exception {

        PodamFactory podam = new PodamFactoryImpl();
        List<NotificationRequestBean> notificationRequestBeans =
                podam.manufacturePojo(ArrayList.class, NotificationRequestBean.class);

        NotificationResponseBean notificationResponseBean = new NotificationResponseBean();
        coreNotificationProcessor.initiateResponseBean(
                notificationRequestBeans, notificationResponseBean);
        assertEquals(HttpStatus.OK, notificationResponseBean.getResultCode());
        assertThat(notificationResponseBean.getResult()).isNotNull();
        assertThat(notificationResponseBean.getResult()).isInstanceOf(List.class);
    }
}
