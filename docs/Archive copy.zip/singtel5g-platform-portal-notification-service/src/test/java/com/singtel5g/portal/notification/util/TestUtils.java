// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.notification.util;

import com.singtel5g.portal.core.enums.NotificationTypes;
import com.singtel5g.portal.core.utils.DateUtils;
import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.CoreNotificationResponseBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Create by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 8/11/2020<br>
 * Project : <B>singtel5g-platform-portal-notification-service </B><br>
 * Since : version 1.0 <br>
 * Description : This class {@link TestUtils} The type Test utils.
 */
public class TestUtils {
    /**
     * Build notification request bean map map.
     *
     * @return the map
     */
    public static Map<String, List<NotificationRequestBean>> buildNotificationRequestBeanMap() {
        Map<String, List<NotificationRequestBean>> notificationRequestBeanMap = new HashMap<>();
        List<NotificationRequestBean> emailList = new ArrayList<>();
        notificationRequestBeanMap.put("EMAIL", emailList);

        List<String> recipients = new ArrayList<>();
        recipients.add("testa@gmail.com");
        recipients.add("testb@gmail.com");
        buildNotificationBean(
                emailList,
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients,
                "Mail Subject1",
                "Mail Test 1.");

        List<String> recipients2 = new ArrayList<>();
        recipients2.add("testc@gmail.com");
        recipients2.add("testd@gmail.com");
        buildNotificationBean(
                emailList,
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients2,
                "Mail Subject2",
                "Mail Test 1.");

        List<NotificationRequestBean> slackList = new ArrayList<>();
        notificationRequestBeanMap.put("SLACK", slackList);

        List<String> recipients3 = new ArrayList<>();
        recipients3.add("_SLACK_WEBHOOK_1_URL_HERE_");
        recipients3.add("_SLACK_WEBHOOK_4_URL_HERE_");
        buildNotificationBean(
                slackList, NotificationTypes.SLACK, "", recipients3, "SLACK  Subject1", "SLACK Test 1.");

        return notificationRequestBeanMap;
    }

    /**
     * Build notification bean.
     *
     * @param slackList         the slack list
     * @param notificationTypes the notification types
     * @param from              the from
     * @param recipients        the recipients
     * @param subject           the subject
     * @param message           the message
     */
    public static void buildNotificationBean(
            List<NotificationRequestBean> slackList,
            NotificationTypes notificationTypes,
            String from,
            List<String> recipients,
            String subject,
            String message) {
        NotificationRequestBean notificationRequestBean3 = new NotificationRequestBean();
        notificationRequestBean3.setType(notificationTypes);
        notificationRequestBean3.setFrom(from);
        notificationRequestBean3.setRecipients(recipients);
        notificationRequestBean3.setSubject(subject);
        notificationRequestBean3.setMessage(message);
        slackList.add(notificationRequestBean3);
    }

    /**
     * Build notification bean.
     *
     * @param notificationTypes the notification types
     * @param from              the from
     * @param recipients        the recipients
     * @param subject           the subject
     * @param message           the message
     */
    public static NotificationRequestBean buildAndReturnNotificationBean(
            NotificationTypes notificationTypes,
            String from,
            List<String> recipients,
            String subject,
            String message) {
        NotificationRequestBean notificationRequestBean = new NotificationRequestBean();
        notificationRequestBean.setType(notificationTypes);
        notificationRequestBean.setFrom(from);
        notificationRequestBean.setRecipients(recipients);
        notificationRequestBean.setSubject(subject);
        notificationRequestBean.setMessage(message);
        return notificationRequestBean;
    }

    /**
     * Build notification bean List.
     *
     */
    public static List<NotificationRequestBean> buildAndReturnNotificationBeanList() {
        List<NotificationRequestBean> notificationRequestBeanList = new ArrayList<>();
        List<String> recipients = new ArrayList<>();
        recipients.add("testb@gmail.com");
        NotificationRequestBean notificationRequestBean = buildAndReturnNotificationBean(
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients,
                "Mail Subject1",
                "Mail Test 1.");
        notificationRequestBean.setCurrentISODate(DateUtils.currentISODateFormat());
        notificationRequestBean.setSequenceNumber(1l);
        notificationRequestBeanList.add(notificationRequestBean);
        return notificationRequestBeanList;
    }

    /**
     * Build notification response bean notification response bean.
     *
     * @return the notification response bean
     */
    public static NotificationResponseBean buildNotificationResponseBean() {
        NotificationResponseBean notificationResponseBean = new NotificationResponseBean();

        List<CoreNotificationResponseBean> result = new ArrayList<>();
        result.add(buildResult("EMAIL", "SUCCESS", "Email sent with subject: Mail Subject"));
        result.add(buildResult("EMAIL", "SUCCESS", "Email sent with subject: Mail Subject"));
        notificationResponseBean.setResult(result);
        notificationResponseBean.setResultCode(HttpStatus.OK);
        return notificationResponseBean;
    }

    private static CoreNotificationResponseBean buildResult(
            String email, String success, String result) {
        return new CoreNotificationResponseBean(email, success, result);
    }

    /**
     * Build notification request beans list list.
     *
     * @return the list
     */
    public static List<NotificationRequestBean> buildNotificationRequestBeansList() {
        List<NotificationRequestBean> emailList = new ArrayList<>();

        List<String> recipients = new ArrayList<>();
        recipients.add("testa@gmail.com");
        recipients.add("testb@gmail.com");
        buildNotificationBean(
                emailList,
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients,
                "Mail Subject1",
                "Mail Test 1.");

        List<String> recipients2 = new ArrayList<>();
        recipients2.add("testc@gmail.com");
        recipients2.add("testd@gmail.com");
        buildNotificationBean(
                emailList,
                NotificationTypes.EMAIL,
                "5gsingnotification@gmail.com",
                recipients2,
                "Mail Subject2",
                "Mail Test 1.");
        return emailList;
    }
}
