package com.singtel5g.portal.notification.controller;

import com.singtel5g.portal.notification.bean.request.NotificationRequestBean;
import com.singtel5g.portal.notification.bean.response.NotificationResponseBean;
import com.singtel5g.portal.notification.facade.EmailNotificationFacade;
import com.singtel5g.portal.notification.facade.NotificationFacadeFactory;
import com.singtel5g.portal.notification.util.TestUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 *
 * @author <B>MadukaJ@Singtel</B>
 * @version 1.0
 * @since <pre>Nov 5, 2020</pre>
 * Description : This class {@link NotificationManagementControllerTest} The type NotificationManagementController Tester.
 */
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class NotificationManagementControllerTest {

    /**
     * The constant TEST_HEADER.
     */
    protected static final String TEST_HEADER = "TEST_HEADER";
    /**
     * The Facade factory.
     */
    @Mock
    NotificationFacadeFactory facadeFactory;

    /**
     * The Email notification facade.
     */
    @Mock
    EmailNotificationFacade emailNotificationFacade;
    /**
     * The Notification management controller.
     */
    @InjectMocks
    NotificationManagementController notificationManagementController;

    /**
     * Before.
     *
     * @throws Exception the exception
     */
    @Before
    public void before() throws Exception {
    }

    /**
     * After.
     *
     * @throws Exception the exception
     */
    @After
    public void after() throws Exception {
    }

    /**
     * Method: sendNotification(@Valid @RequestBody Map<String, List<NotificationRequestBean>>
     * notificationRequestBeanMap)
     *
     * @throws Exception the exception
     */
    @Test
    @DisplayName(
            "Testing if send Notifications returns ResponseEntity object correctly for successful inputs.")
    public void testSendNotification() throws Exception {
        Map<String, List<NotificationRequestBean>> notificationRequestBeanMap =
                TestUtils.buildNotificationRequestBeanMap();
        List<NotificationResponseBean> notificationResponseBeans = new ArrayList<>();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        when(facadeFactory.getFacade(any(), any())).thenReturn(emailNotificationFacade);
        when(emailNotificationFacade.sendNotifications(any())).thenReturn(notificationResponseBean);
        ResponseEntity<?> responseEntity =
                notificationManagementController.sendNotification(notificationRequestBeanMap);
        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }

    /**
     * Method: sendNotification(@Valid @RequestBody Map<String, List<NotificationRequestBean>>
     * notificationRequestBeanMap)
     *
     * @throws Exception the exception
     */
    @Test
    @DisplayName(
            "Testing if send Notifications returns ResponseEntity object correctly for successful inputs.")
    public void testSendNotificationForEmptyNtfFacade() throws Exception {
        Map<String, List<NotificationRequestBean>> notificationRequestBeanMap =
                TestUtils.buildNotificationRequestBeanMap();
        List<NotificationResponseBean> notificationResponseBeans = new ArrayList<>();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        when(facadeFactory.getFacade(any(), any())).thenReturn(null);
        when(emailNotificationFacade.sendNotifications(any())).thenReturn(notificationResponseBean);
        ResponseEntity<?> responseEntity =
                notificationManagementController.sendNotification(notificationRequestBeanMap);
        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }

    /**
     * Method: testSendNotificationForThrowingException
     */
    @Test
    @DisplayName(
            "Testing if send Notifications returns ResponseEntity object correctly for Throwing Exception.")
    public void testSendNotificationForThrowingException() throws Exception {
        Map<String, List<NotificationRequestBean>> notificationRequestBeanMap =
                TestUtils.buildNotificationRequestBeanMap();
        List<NotificationResponseBean> notificationResponseBeans = new ArrayList<>();
        NotificationResponseBean notificationResponseBean = TestUtils.buildNotificationResponseBean();
        when(facadeFactory.getFacade(any(), any())).thenReturn(null);
        when(emailNotificationFacade.sendNotifications(any())).thenReturn(notificationResponseBean);
        ResponseEntity<?> responseEntity =
                notificationManagementController.sendNotification(notificationRequestBeanMap);
        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }
}
