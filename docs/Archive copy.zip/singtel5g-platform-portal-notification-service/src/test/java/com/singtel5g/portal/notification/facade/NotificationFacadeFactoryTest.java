package com.singtel5g.portal.notification.facade;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/**
 *
 * @author <B>MadukaJ@Singtel</B>
 * @version 1.0
 * @since <pre>Nov 5, 2020</pre>
 * Description : This class {@link NotificationFacadeFactoryTest} The type NotificationFacadeFactory Tester.
 */
@SpringBootTest
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class NotificationFacadeFactoryTest {

    /**
     * The Facade.
     */
    @InjectMocks
    NotificationFacadeFactory facade;
    @Mock
    private EmailNotificationFacade emailNotificationFacade;
    /**
     * The Slack notification facade.
     */
    @Mock
    private SlackNotificationFacade slackNotificationFacade;

    /**
     * Method: getFacade(String type, String signature)
     *
     * @throws Exception the exception
     */
    @Test
    public void testGetFacade() throws Exception {

        assertThat(facade.getFacade("EMAIL", null)).isInstanceOf(EmailNotificationFacade.class);
        assertThat(facade.getFacade("EMAIL", "SOME TEXT")).isInstanceOf(EmailNotificationFacade.class);
        assertThat(facade.getFacade("SLACK", null)).isInstanceOf(SlackNotificationFacade.class);
        assertThat(facade.getFacade("SLACK", "SOME TEXT")).isInstanceOf(SlackNotificationFacade.class);
        assertThat(facade.getFacade("SMS", "SOME TEXT")).isNull();
        assertThatThrownBy(() -> facade.getFacade(null, null))
                .isExactlyInstanceOf(NullPointerException.class);
    }

    /**
     * Method: getEmailNotificationFacadeInstance()
     *
     * @throws Exception the exception
     */
    @Test
    public void testGetEmailNotificationFacadeInstance() throws Exception {
        assertThat(facade.getEmailNotificationFacadeInstance())
                .isInstanceOf(EmailNotificationFacade.class);
    }

    /**
     * Method: getSlackNotificationFacadeInstance()
     *
     * @throws Exception the exception
     */
    @Test
    public void testGetSlackNotificationFacadeInstance() throws Exception {
        assertThat(facade.getSlackNotificationFacadeInstance())
                .isInstanceOf(SlackNotificationFacade.class);
    }
}
