package com.singtel5g.portal.notification.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ApiDocControllerTest {

    @InjectMocks
    ApiDocController apiDocController;

    @BeforeEach
    void setUp() {
    }

    @Test
    @DisplayName("getApiConfig")
    void testGetApiConfig() {
        assertEquals("apiSpec",apiDocController.getApiConfig());
    }
}