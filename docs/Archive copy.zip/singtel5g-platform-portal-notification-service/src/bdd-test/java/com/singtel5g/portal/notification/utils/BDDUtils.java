/*
 *  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************
 */

package com.singtel5g.portal.notification.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;
import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

/**
 * Created by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 5/10/2020 <br>
 * Project : <B> singtel5g-platform-portal-notification-service </B><br>
 * Since : version 1.0 <br>
 * Description : This class {@link BDDUtils} The type Bdd util.
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class BDDUtils {

    /**
     * The constant mapper.
     */
    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * The constant validationCheckWithServer.
     */
    private static boolean validationCheckWithServer = true;
    /**
     * The constant variables.
     */
    private static final EnvironmentVariables variables =
            SystemEnvironmentVariables.createEnvironmentVariables();

    /**
     * Is validation check with server boolean.
     *
     * @return the boolean
     */
    public static boolean isValidationCheckWithServer() {
        return validationCheckWithServer;
    }

    /**
     * Init. If the running environment is local or default following system property will be set to
     * bypass feign clients if there is any.
     */
    public static void init() {
        String externalServiceEndpoint =
                EnvironmentSpecificConfiguration.from(getVariables())
                        .getProperty("external.service.endpoint");
        String validationCheckWithServerValue =
                EnvironmentSpecificConfiguration.from(getVariables())
                        .getProperty("validation.check.with.server");
        if (StringUtils.isNotEmpty(externalServiceEndpoint)) {
            externalServiceEndpoint = "";
        }
        if (StringUtils.isNotEmpty(validationCheckWithServerValue)) {
            validationCheckWithServer = Boolean.parseBoolean(validationCheckWithServerValue);
        }
        System.setProperty("external.service.endpoint", externalServiceEndpoint);
    }

    /**
     * Gets variables.
     *
     * @return the variables
     */
    public static EnvironmentVariables getVariables() {
        return variables;
    }

    /**
     * Gets object mapper.
     *
     * @return the object mapper
     */
    public static ObjectMapper getObjectMapper() {
        return mapper;
    }

    /**
     * Gets resource file as string.
     *
     * @param fileName the file name
     * @return the resource file as string
     */
    public static String getResourceFileAsString(String fileName) {
        InputStream is = getResourceFileAsInputStream(fileName);
        if (is != null) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            return reader.lines().collect(Collectors.joining(System.lineSeparator()));
        } else {
            log.error("resource not found");
            return "";
        }
    }

    /**
     * Gets resource file as input stream.
     *
     * @param fileName the file name
     * @return the resource file as input stream
     */
    public static InputStream getResourceFileAsInputStream(String fileName) {
        ClassLoader classLoader = BDDUtils.class.getClassLoader();
        return classLoader.getResourceAsStream(fileName);
    }
}
