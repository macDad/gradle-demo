/*
 *  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************
 */

package com.singtel5g.portal.notification.bdd.config;

import com.singtel5g.portal.notification.utils.BDDUtils;
import io.cucumber.java.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 5/10/2020 <br>
 * Project : <B> singtel5g-platform-portal-notification-service </B><br>
 * Since : version 1.0 <br>
 * Description : This class {@link SpringContextConfiguration} The type Spring context
 * configuration.
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@Ignore
public class SpringContextConfiguration {

    /** Inject spring properties into system properties before spring context starts */
    static {
        BDDUtils.init();
    }

    /**
     * Spring context hook for serenity when test run on local .
     */
    @Before
    public void setup() {
        // Spring context hook for serenity when test run on local
    }
}
