/*
 *  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************
 */

package com.singtel5g.portal.notification.steps;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.singtel5g.portal.notification.utils.BDDUtils;
import io.cucumber.java.Before;
import io.restassured.RestAssured;
import lombok.extern.slf4j.Slf4j;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

import static io.restassured.RestAssured.DEFAULT_URI;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Created by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 5/10/2020 <br>
 * Project : <B> singtel5g-platform-portal-notification-service </B><br>
 * Since : version 1.0 <br>
 * Description : This class {@link CommonSteps} The type Common steps.
 */
@Slf4j
public class CommonSteps {

    /**
     * Sets up.
     */
    @Before
    public void setUp() {
        if (DEFAULT_URI.equals(RestAssured.baseURI)) {
            RestAssured.baseURI =
                    EnvironmentSpecificConfiguration.from(BDDUtils.getVariables())
                            .getProperty("service.endpoint");
            log.info("BaseURI: {}", RestAssured.baseURI);
        }
    }

    /**
     * Should get error detail.
     *
     * @param errorDetail the error detail
     * @throws JsonProcessingException the json processing exception
     */
    public void iShouldGetErrorDetail(String errorDetail) throws JsonProcessingException {
        String actualResult = SerenityRest.lastResponse().getBody().asString();
        final ArrayNode node = BDDUtils.getObjectMapper().readValue(actualResult, ArrayNode.class);
        assertEquals(errorDetail, node.get(0).get("detail").get(0).asText());
    }

    /**
     * Should get response with expected output.
     *
     * @param responseCode the response code
     * @param filePath     the file path
     * @throws JsonProcessingException the json processing exception
     */
    @Step("Get response containing expected output")
    public void shouldGetResponseWithExpectedOutput(String responseCode, String filePath)
            throws JsonProcessingException {
        String actualResult = SerenityRest.lastResponse().getBody().asString();
        final ArrayNode actualNode =
                BDDUtils.getObjectMapper().readValue(actualResult, ArrayNode.class);
        final ArrayNode expectedNode =
                BDDUtils.getObjectMapper()
                        .readValue(BDDUtils.getResourceFileAsString(filePath), ArrayNode.class);
        for (int i = 0; i < actualNode.size(); i++) {
            assertEquals(responseCode, actualNode.get(i).get("resultCode").asText());
        }
        assertEquals(expectedNode, actualNode);
    }
}
