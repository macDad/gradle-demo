/*
 *  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************
 */

package com.singtel5g.portal.notification.bdd.config;

import com.github.tomakehurst.wiremock.WireMockServer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

import static com.github.tomakehurst.wiremock.client.WireMock.configureFor;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

/**
 * Created by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 5/10/2020 <br>
 * Project : <B> singtel5g-platform-portal-notification-service </B><br>
 * Since : version 1.0 <br>
 * Description : This class  {@link BDDConfiguration} The type Bdd configuration.
 */
@Configuration
class BDDConfiguration {
    /**
     * The Port number.
     */
    @Value("${mock.service.port.number}")
    int portNumber;

    /**
     * Sets stubs.
     */
    @PostConstruct
    public void setupStubs() {
        WireMockServer wireMockServer =
                new WireMockServer(options().port(portNumber).usingFilesUnderClasspath("stubs"));
        wireMockServer.start();
        configureFor("localhost", portNumber);
    }
}
