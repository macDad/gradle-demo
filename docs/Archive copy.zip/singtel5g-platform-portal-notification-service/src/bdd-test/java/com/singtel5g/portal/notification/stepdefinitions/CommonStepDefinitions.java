/*
 *  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************
 */

package com.singtel5g.portal.notification.stepdefinitions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.singtel5g.portal.notification.steps.StepComponent;
import io.cucumber.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import net.thucydides.core.annotations.Steps;

/**
 * Created by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 5/10/2020 <br>
 * Project : <B> singtel5g-platform-portal-notification-service </B><br>
 * Since : version 1.0 <br>
 * Description : This class {@link CommonStepDefinitions} The type Common step definitions.
 */
@Slf4j
public class CommonStepDefinitions {

    /**
     * The Common steps.
     */
    @Steps
    StepComponent commonSteps;

    /**
     * Get the response code and the result is equal to.
     *
     * @param responseCode the response code
     * @param filePath     the file path
     * @throws JsonProcessingException the json processing exception
     */
    @Then("I get the response code {string} and the result is equal to {string}")
    public void iGetTheResponseCodeAndTheResultIsEqualTo(String responseCode, String filePath)
            throws JsonProcessingException {
        commonSteps.shouldGetResponseWithExpectedOutput(responseCode, filePath);
    }

    /**
     * Get the response code is equal to.
     *
     * @param responseCode the response code
     * @throws JsonProcessingException the json processing exception
     */
    @Then("I get the response code {string}")
    public void iGetTheResponseCodeIsEqualTo(String responseCode)
            throws JsonProcessingException {
        commonSteps.shouldGetResponseWithExpectedResponse(responseCode);
    }


}
