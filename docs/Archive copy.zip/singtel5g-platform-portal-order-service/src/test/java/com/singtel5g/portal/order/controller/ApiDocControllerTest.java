package com.singtel5g.portal.order.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 19/2/2021<br>
 * Project      : <B>singtel5g-platform-portal-order-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link  ApiDocControllerTest} use for
 */

class ApiDocControllerTest {
    ApiDocController apiDocController= new ApiDocController();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    void testGetApiConfig(){
        String result = apiDocController.getApiConfig();
        Assertions.assertEquals("apiSpec", result);
    }
}