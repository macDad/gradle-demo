package com.singtel5g.portal.order.facade;

import com.singtel5g.portal.order.bean.request.*;
import com.singtel5g.portal.order.bean.response.*;
import com.singtel5g.portal.order.common.OrderType;
import com.singtel5g.portal.order.component.OrderManagementProcessor;
import com.singtel5g.portal.order.component.OrderManagementValidatorDerivator;
import com.singtel5g.portal.order.util.TestUtil;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.Mockito.*;
/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 7/4/2021<br>
 * Project      : <B>singtel5g-platform-portal-order-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link  OrderManagementFacadeTest} use for
 */

class OrderManagementFacadeTest {
    @Mock
    OrderManagementValidatorDerivator validator;
    @Mock
    OrderManagementProcessor processor;
    @InjectMocks
    OrderManagementFacade orderManagementFacade;
    /**
     * The constant TEST_HEADER.
     */
    protected static final String TEST_HEADER = "TEST_HEADER";
    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }



    @Test
  @DisplayName(
      "Testing search orders facade does not throw any exception when provided with a valid input")
  public void testSearchOrders() {
    SearchOrderFormRequestBean searchOrderFormRequestBean =
        TestUtil.searchOrderFormRequestBean("1", "ORG1", "10");
    PrivilegesResponse retrievedUserDetails = new PrivilegesResponse();

    SearchOrderResponseBean searchOrderResponseBean = new SearchOrderResponseBean();
    doNothing().when(validator).validateSearchOrderForm(any());
    doNothing().when(processor).performSearchOrder(any(), any());
    doNothing().when(processor).performAuditLogForOrderInquiry(any(), any());
    assertThatCode(() -> orderManagementFacade.searchOrders(searchOrderFormRequestBean))
        .doesNotThrowAnyException();
    }

    /**
     * Test Process search orders facade.
     */
    @Test
  @DisplayName(
      "Testing if search orders facade does not throw any exception when provided with a valid Inputs")
  public void testProcessSearchOrders() {
    SearchOrderFormRequestBean searchOrderFormRequestBean =
        TestUtil.searchOrderFormRequestBean("1", "ORG1", "10");
    SearchOrderResponseBean searchOrderResponseBean = new SearchOrderResponseBean();
    doNothing().when(processor).performSearchOrder(any(), any());
    doNothing().when(processor).performAuditLogForOrderInquiry(any(), any());
    assertThatCode(
            () ->
                orderManagementFacade.processSearchOrderInput(
                    searchOrderFormRequestBean, searchOrderResponseBean))
        .doesNotThrowAnyException();
    }

    /**
     * Test save orders facade.
     */
    @Test
  @DisplayName(
      "Testing if save order facade does not throw any exception when provided with a valid inputs")
  public void testSaveOrders() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeanList = TestUtil.createOrderFormBean();
    doNothing().when(validator).validateSaveOrderForm(any(), any());
    doNothing().when(processor).performSaveOrder(any(),any(), any());
    doNothing().when(processor).performAuditLogForSaveOrder(any(), any());
    assertThatCode(() -> orderManagementFacade.saveOrders(TEST_HEADER, saveOrderFormRequestBeanList))
        .doesNotThrowAnyException();
    }

    /**
     * Test validate save orders facade.
     */
    @Test
  @DisplayName(
      "Testing if validate save order facade does not throw any exception when provided with a valid inputs")
  public void testValidateSaveOrders() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeanList = TestUtil.createOrderFormBean();
    SaveOrderResponseBean saveOrderResponseBean = new SaveOrderResponseBean();
    doNothing().when(validator).validateSaveOrderForm(any(), any());
    assertThatCode(
            () ->
        orderManagementFacade.validationSaveOrderInput(
                    saveOrderFormRequestBeanList, saveOrderResponseBean))
        .doesNotThrowAnyException();
    }

    /**
     * Test process save orders facade.
     */
    @Test
  @DisplayName("Testing validate save order facade throw any exception when provided valid inputs")
  public void testProcessSaveOrder() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeanList = TestUtil.createOrderFormBean();
    SaveOrderResponseBean saveOrderResponseBean = new SaveOrderResponseBean();
    doNothing().when(processor).performSaveOrder(any(), any(), any());
    doNothing().when(processor).performAuditLogForSaveOrder(any(), any());
    assertThatCode(
            () ->
                orderManagementFacade.processSaveOrderInput(TEST_HEADER,
                    saveOrderFormRequestBeanList, saveOrderResponseBean))
        .doesNotThrowAnyException();
    }

    /**
     * Test delete orders facade.
     */
    @Test
  @DisplayName(
      "Testing if delete order facade does not throw any exception when provided with a valid inputs")
  public void testDeleteOrder() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans =
        TestUtil.createValidDeleteOrderFormRequestBean();
    doNothing().when(validator).validateDeleteOrderForm(any(), any());
    doNothing().when(processor).performDeleteOrder(any(), any());
    doNothing().when(processor).performAuditLogForSaveOrder(any(), any());
    assertThatCode(() -> orderManagementFacade.deleteOrder(deleteOrderFormRequestBeans))
        .doesNotThrowAnyException();
    }

    /**
     * Test validate delete orders facade.
     */
    @Test
  @DisplayName(
      "Testing validate delete order facade does not throw any exception when provided with a valid inputs")
  public void testValidateDeleteOrder() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans =
        TestUtil.createValidDeleteOrderFormRequestBean();
    DeleteOrderResponseBean deleteOrderResponseBean = new DeleteOrderResponseBean();
    doNothing().when(validator).validateDeleteOrderForm(any(), any());
    assertThatCode(
            () ->
                orderManagementFacade.validationDeleteOrderInput(
                    deleteOrderFormRequestBeans, deleteOrderResponseBean))
        .doesNotThrowAnyException();
    }

    /**
     * Test process delete orders facade.
     */
    @Test
  @DisplayName(
      "Testing process delete order facade does not throw any exception when provided with a valid inputs")
  public void testProcessDeleteOrder() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans =
        TestUtil.createValidDeleteOrderFormRequestBean();
    DeleteOrderResponseBean deleteOrderResponseBean = new DeleteOrderResponseBean();
    doNothing().when(processor).performDeleteOrder(any(), any());
    doNothing().when(processor).performAuditLogForSaveOrder(any(), any());
    assertThatCode(
            () ->
                orderManagementFacade.processDeleteOrderInput(
                    deleteOrderFormRequestBeans, deleteOrderResponseBean))
        .doesNotThrowAnyException();
    }
}
