package com.singtel5g.portal.order.component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.singtel5g.portal.audit.component.AuditWriter;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.common.Constant;
import com.singtel5g.portal.order.util.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.Mockito.*;
/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 7/4/2021<br>
 * Project      : <B>singtel5g-platform-portal-order-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link  AuditLogProcessorTest} use for
 */
class AuditLogProcessorTest {
    @Mock
    AuditWriter auditWriter;
    @InjectMocks
    AuditLogProcessor auditLogProcessor;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Value("${audit.table.name}")
    private String AUDIT_TABLE_NAME;

    @org.junit.Test
    @DisplayName("Testing if auditLog functions correctly.")
    public void testAuditLog2() {
        SaveOrderFormRequestBean saveOrderFormRequestBean = TestUtil.createSingleOrderFormRequestBean();
        ObjectMapper oMapper = new ObjectMapper();
        Map<String, Object> payLoad = oMapper.convertValue(saveOrderFormRequestBean, Map.class);
        doNothing().when(auditWriter).perform(AUDIT_TABLE_NAME, "TEST", payLoad);
        assertThatCode(
                () ->
                        auditLogProcessor.auditLog(
                                Constant.StringConstant.AUDIT_FUNCTION_CODE_CREATE.value(), payLoad))
                .doesNotThrowAnyException();
    }
}

