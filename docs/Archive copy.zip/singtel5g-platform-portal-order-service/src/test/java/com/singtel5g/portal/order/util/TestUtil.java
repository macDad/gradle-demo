// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.util;

import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.OrganizationResponseBean;
import com.singtel5g.portal.order.bean.response.ProfileResponse;
import com.singtel5g.portal.order.bean.response.SearchOrderResponseBean;
import com.singtel5g.portal.order.model.OrderDoc;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.http.HttpStatus;

import java.util.*;
import java.util.stream.Collectors;
/**
 * Create by: Kasun Silva
 *
 * <p>Date: 14/9/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: Version 2.0
 * Description: Shared methods across different test classes related to this microservice should be added
 * here.
 */
public class TestUtil {

    /**
     * Create & Return valid single order form object List
     *
     * @return the add order form request beans list
     */
    public static List<SaveOrderFormRequestBean> createOrderFormBean() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeanList = new ArrayList<>();
    saveOrderFormRequestBeanList.add(createSingleOrderFormRequestBean());
    return saveOrderFormRequestBeanList;
  }

    /**
     * Create & Return valid single order form object
     *
     * @return the order form request bean
     */
    public static SaveOrderFormRequestBean createSingleOrderFormRequestBean() {
    SaveOrderFormRequestBean saveOrderFormRequestBean = new SaveOrderFormRequestBean();
    saveOrderFormRequestBean.setOrderID("1");
    saveOrderFormRequestBean.setUserOrgCode("ORG1");
    saveOrderFormRequestBean.setOrderType("ADD_DEVICE");
    saveOrderFormRequestBean.setUserAccountID("10");
    saveOrderFormRequestBean.setStatus("PLANNED");
    return saveOrderFormRequestBean;
  }

    /**
     * Create & Return valid delete order form object
     *
     * @param orderID       the order id
     * @param userOrgCode   the user org code
     * @param orderType     the order type
     * @param userAccountID the user account id
     * @param status        the status
     * @return the delete order form request bean
     */
    public static DeleteOrderFormRequestBean createDeleteOrderFormRequestBean(
      String orderID, String userOrgCode, String orderType, String userAccountID, String status) {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans = new DeleteOrderFormRequestBean();
    deleteOrderFormRequestBeans.setId(orderID);
    deleteOrderFormRequestBeans.setOrderID(orderID);
    deleteOrderFormRequestBeans.setUserOrgCode(userOrgCode);
    deleteOrderFormRequestBeans.setStatus(status);
    return deleteOrderFormRequestBeans;
  }

    /**
     * Create & Return valid single delete order form object
     *
     * @return the delete order form request bean
     */
    public static DeleteOrderFormRequestBean createValidDeleteOrderFormRequestBean() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans = new DeleteOrderFormRequestBean();
    deleteOrderFormRequestBeans.setId("1");
    deleteOrderFormRequestBeans.setOrderID("10");
    deleteOrderFormRequestBeans.setUserOrgCode("ORG1");
    deleteOrderFormRequestBeans.setOrderType("ADD_DEVICE");
    deleteOrderFormRequestBeans.setStatus("PLANNED");
    return deleteOrderFormRequestBeans;
  }

    /**
     * Create & Return valid single search order form object and
     *
     * @param orderID       the order id
     * @param userOrgCode   the user org code
     * @param userAccountID the user account id
     * @return search order form request bean
     */
    public static SearchOrderFormRequestBean searchOrderFormRequestBean(
      String orderID, String userOrgCode, String userAccountID) {
    SearchOrderFormRequestBean searchOrderFormRequestBean = new SearchOrderFormRequestBean();
    searchOrderFormRequestBean.setUserOrgCode(userOrgCode);
    searchOrderFormRequestBean.setOrderID(orderID);
    searchOrderFormRequestBean.setUserAccountID(userAccountID);
    return searchOrderFormRequestBean;
  }

    /**
     * Create & Return valid single order form request object
     *
     * @return the search order form request bean
     */
    public static SearchOrderFormRequestBean createValidSearchOrderFormRequestBean() {
    SearchOrderFormRequestBean searchOrderFormRequestBean = new SearchOrderFormRequestBean();
    searchOrderFormRequestBean.setUserOrgCode("ORG1");
    searchOrderFormRequestBean.setOrderID("1");
    searchOrderFormRequestBean.setUserAccountID("10");
    return searchOrderFormRequestBean;
  }

    /**
     * Create & Return valid single order form request object
     *
     * @return the search order form request bean
     */
    public static SearchOrderResponseBean getSearchOrderResponseBean() {
    SearchOrderResponseBean searchOrderResponseBean = new SearchOrderResponseBean();
    searchOrderResponseBean.setResultCode(HttpStatus.OK);
    Map<String, List> map = new HashMap<>();
    map.put("orderList", getOrderList());
    searchOrderResponseBean.setResult(map);
    return  searchOrderResponseBean;
  }

    /**
     * Get order list list.
     *
     * @return the list
     */
    public static List<OrderDoc> getOrderList(){
    List<OrderDoc> orderDocList = new ArrayList<>();
    OrderDoc orderDoc = new OrderDoc();
    orderDoc.setOrderID("1");
    orderDocList.add(orderDoc);
    return  orderDocList;
  }

    /**
     * Get valid order doc bean order doc.
     *
     * @return the order doc
     */
    public static OrderDoc getValidOrderDocBean(){
    OrderDoc orderDoc = new OrderDoc();
    orderDoc.setOrderID("1");
    orderDoc.setOrderType("NA");
    orderDoc.setUserAccountID("10");
    orderDoc.setUserOrgCode("SGT");
    orderDoc.setStatus("PLANNED");
    return orderDoc;
  }

    /**
     * Get profile response list list.
     *
     * @return the list
     */
    public static  List<ProfileResponse> getProfileResponseList(){
    List<ProfileResponse> profileResponseList = new ArrayList<>();
    ProfileResponse profileResponse = new ProfileResponse();
    profileResponse.setId("10");
    profileResponse.setStatus("OK");
    profileResponse.setFirstName("FirstName");
    profileResponse.setLastName("LastName");
    profileResponse.setUsername("Username");
    profileResponseList.add(profileResponse);
    return  profileResponseList;
  }

    /**
     * Gets random alpha numeric string.
     *
     * @param length the length
     * @return the random alpha numeric string
     */
    public static String getRandomAlphaNumericString(int length) {
    return RandomStringUtils.randomAlphanumeric(length).toLowerCase();
  }

    /**
     * Convert string to map map.
     *
     * @param value the value
     * @return the map
     */
    public static Map<String, String> convertStringToMap(String value) {
    value = value.substring(1, value.length() - 1); // remove curly brackets
    String[] keyValuePairs = value.split(","); // split the string to creat key-value pairs
    Map<String, String> map = Arrays.stream(keyValuePairs)
            .map(pair -> pair.split("="))
            .collect(Collectors.toMap(entry -> entry[0].trim(), entry -> entry[1].trim(), (a, b) -> b));
    return map;
  }

  /**
   * Get Organization Response Bean List.
   *
   * @return the Set of Organization Response Bean
   */
  public static Set<OrganizationResponseBean> getOrganizationResponseBean(){
    Set<OrganizationResponseBean> organizationResponseBeans = new HashSet<>();

    OrganizationResponseBean singtelBean = new OrganizationResponseBean();
    singtelBean.setOrganizationName("Singtel");
    singtelBean.setOrganizationCode("singtel");

    OrganizationResponseBean singtel2Bean = new OrganizationResponseBean();
    singtel2Bean.setOrganizationName("Singtel2");
    singtel2Bean.setOrganizationCode("singtel");

    organizationResponseBeans.add(singtelBean);
    organizationResponseBeans.add(singtel2Bean);
    return organizationResponseBeans;
  }

  /**
   * Get Organization Response Bean List.
   *
   * @return the Set of Organization Response Bean
   */
  public static PrivilegesResponse getPrivilegesResponse(){
    PrivilegesResponse retrievedUserDetails = new PrivilegesResponse();

    Set<String> privileges = new HashSet<>();
    privileges.add("/order/add");
    privileges.add("/order/view");
    privileges.add("/user/paragon/systemuser");

    retrievedUserDetails.setUsername("User 1");
    retrievedUserDetails.setOrganizationCode("org1");
    retrievedUserDetails.setOrganizationName("Org 1");
    retrievedUserDetails.setPrivileges(privileges);

    return retrievedUserDetails;
  }


}
