package com.singtel5g.portal.order.controller;

import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

/**
 * Created by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 19/2/2021<br>
 * Project : <B>singtel5g-platform-portal-order-service </B><br>
 * Since : version 1.0 <br>
 * Description : This class {@link OrderManagementHelperTest} use for
 */
class OrderManagementHelperTest {
    OrderManagementHelper orderManagementHelper = new OrderManagementController();

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testCanViewOrders() {
        Assertions.assertThrows(
                NullPointerException.class,
                () ->
                        orderManagementHelper.canViewOrders(
                                true,
                                new SearchOrderFormRequestBean(
                                        "userOrgCode", "Singtel", "userDepCode", "userAccountID", "orderID", "fromDate", "toDate", "externalID", ""),
                                null));
        Assertions.assertTrue(orderManagementHelper.canViewOrders(
                false,
                new SearchOrderFormRequestBean(
                        "userOrgCode", "Singtel", "userDepCode", "userAccountID", "orderID", "fromDate", "toDate", "externalId", ""),
                null));
    }

    @Test
    void testCheckSearchParam() {
        boolean result = orderManagementHelper.checkSearchParam("searchParam", "userParam");
        Assertions.assertEquals(false, result);
    }
}
