// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.component;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.DeleteOrderResponseBean;
import com.singtel5g.portal.order.bean.response.SaveOrderResponseBean;
import com.singtel5g.portal.order.common.Constant;
import com.singtel5g.portal.order.util.TestUtil;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;
import com.singtel5g.portal.security.component.AuthCheck;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 7/4/2021<br>
 * Project      : <B>singtel5g-platform-portal-order-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link  OrderManagementValidatorDerivatorTest} use for
 */

class OrderManagementValidatorDerivatorTest {
    /**
     * Inject Mock OrderManagementValidatorDerivator
     */
    @InjectMocks
    OrderManagementValidatorDerivator orderManagementValidatorDerivator;
    @Mock
    AuthCheck authCheck;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }
    @Test
  @DisplayName(
      "Testing if validate SearchOrderForm does not throw any exception when provided with a valid single SearchOrderForm.")
  public void testValidateSearchOrderForm() {
    SearchOrderFormRequestBean searchOrderFormRequestBean =
        TestUtil.createValidSearchOrderFormRequestBean();
      PrivilegesResponse retrievedUserDetails = new PrivilegesResponse();
    when(authCheck.hasPermission(any(), any())).thenReturn(true);

    assertThatCode(
            () ->
                orderManagementValidatorDerivator.validateSearchOrderForm(searchOrderFormRequestBean))
        .doesNotThrowAnyException();

    when(authCheck.hasPermission(any(), any())).thenReturn(false);
    assertThrows(
        Exception.class,
        () ->
            orderManagementValidatorDerivator.validateSearchOrderForm(searchOrderFormRequestBean));

    searchOrderFormRequestBean.addContext(Constant.ORGANIZATION_CODE, searchOrderFormRequestBean.getUserOrgCode());
    searchOrderFormRequestBean.setUserSearchOrgCode("ORG1");
    assertThatCode(
        () ->
            orderManagementValidatorDerivator.validateSearchOrderForm(searchOrderFormRequestBean))
        .doesNotThrowAnyException();
    }

  /**
   * Test validate save order form for valid single order.
   */
    @Test
  @DisplayName(
      "Testing if validateSaveOrderForm does not throw any exception when provided with a valid save order form.")
  public void testValidateSaveOrderForm() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeans = TestUtil.createOrderFormBean();
    SaveOrderResponseBean saveOrderResponseBean = new SaveOrderResponseBean();
    assertThatCode(
            () ->
                orderManagementValidatorDerivator.validateSaveOrderForm(
                    saveOrderFormRequestBeans, saveOrderResponseBean))
        .doesNotThrowAnyException();
    }

  /**
   * Test validate save order form for Invalid order.
   */
    @Test
  @DisplayName(
      "Testing if validateSaveOrderForm throw any exception when provided a invalid save order form.")
  public void testValidateSaveOrderFormInvalidOrderForm() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeans = new ArrayList<>();
    SaveOrderResponseBean saveOrderResponseBean = new SaveOrderResponseBean();
    assertThrows(
        Exception.class,
        () ->
            orderManagementValidatorDerivator.validateSaveOrderForm(
                saveOrderFormRequestBeans, saveOrderResponseBean));
    }

  /**
   * Test validate save order form for Null order.
   */
    @Test
  @DisplayName(
      "Testing if validateSaveOrderForm throw any exception when provided a null save order form.")
  public void testValidateSaveOrderFormNullOrderForm() {
    SaveOrderResponseBean saveOrderResponseBean = new SaveOrderResponseBean();
    assertThrows(
        Exception.class,
        () -> orderManagementValidatorDerivator.validateSaveOrderForm(null, saveOrderResponseBean));
    }

  /**
   * Test validate delete order form valid delete order form.
   */
    @Test
  @DisplayName(
      "Testing if validateDeleteOrderForm does not throw any exception when provided with a valid delete order form.")
  public void testValidateDeleteOrderForm() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans =
        TestUtil.createValidDeleteOrderFormRequestBean();
    DeleteOrderResponseBean deleteOrderResponseBean = new DeleteOrderResponseBean();
    assertThatCode(
            () ->
                orderManagementValidatorDerivator.validateDeleteOrderForm(
                    deleteOrderFormRequestBeans, deleteOrderResponseBean))
        .doesNotThrowAnyException();
  }

  /**
   * Test validate delete order form valid delete order form.
   */
  @Test
  @DisplayName(
      "Testing if validateDeleteOrderForm does not throw any exception when provided with a invalid delete order form.")
  public void testValidateDeleteOrderFormForInvalidDeleteOrder() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans =
        TestUtil.createDeleteOrderFormRequestBean(null, null, null, null, "PLANNED");
    DeleteOrderResponseBean deleteOrderResponseBean = new DeleteOrderResponseBean();
    assertThrows(
        Exception.class,
        () ->
            orderManagementValidatorDerivator.validateDeleteOrderForm(
                deleteOrderFormRequestBeans, deleteOrderResponseBean));
  }

  /**
   * Test validate delete order form valid delete order form.
   */
  @Test
  @DisplayName(
      "Testing if validateDeleteOrderForm does not throw any exception when provided with a null delete order form.")
  public void testValidateDeleteOrderFormForNullDeleteOrder() {
    DeleteOrderResponseBean deleteOrderResponseBean = new DeleteOrderResponseBean();
    assertThrows(
        Exception.class,
        () ->
            orderManagementValidatorDerivator.validateDeleteOrderForm(
                null, deleteOrderResponseBean));
    }

  /**
   * Test validate request form for valid status and field name.
   */
    @Test
  @DisplayName(
      "Testing if validateRequestForm does not throw any exception when provided valid status and field name.")
  public void testValidateRequestForm() {
    String status = "TEST";
    String fieldName = "TEST_FIELD";
    assertThatCode(() -> orderManagementValidatorDerivator.validateRequestForm(status, fieldName))
        .doesNotThrowAnyException();
  }

  /**
   * Test validate request form for null values.
   */
  @Test
  @DisplayName(
      "Testing if validateRequestForm does not throw any exception when provided valid status and field name.")
  public void testValidateRequestFormForNullValues() {
    assertThrows(
        Exception.class, () -> orderManagementValidatorDerivator.validateRequestForm(null, null));
    }
}
