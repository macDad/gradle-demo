// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.mapper;

import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.model.OrderDoc;
import com.singtel5g.portal.order.util.TestUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
/**
 * Create by: Kasun Silva
 *
 * <p>Date: 14/9/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: Version 2.0
 * Description: The type Order mapper impl test.
 */
public class OrderMapperImplTest {

  /**
   * The Order mapper.
   */
  @InjectMocks OrderMapperImpl orderMapper = new OrderMapperImpl();

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
  }
  /**
   * Test to save order form request bean.
   */
  @Test
  @DisplayName("Test OrderDoc to Save Order Form Request Mapper.")
  public void testToSaveOrderFormRequestBean() {
    SaveOrderFormRequestBean saveOrderFormRequestBean =
        orderMapper.toSaveOrderFormRequestBean(TestUtil.getValidOrderDocBean());

    assertEquals("1", saveOrderFormRequestBean.getOrderID());
  }

  /**
   * Test save order form request to order doc.
   */
  @Test
  @DisplayName("Test Save Order Form Request to OrderDoc Mapper.")
  void testSaveOrderFormRequestToOrderDoc() {
    OrderDoc orderdoc = orderMapper.toOrderDoc(TestUtil.createSingleOrderFormRequestBean());
    assertEquals("1", orderdoc.getOrderID());
  }

  /**
   * Test delete order form request to order doc.
   */
  @Test
  @DisplayName("Test Delete Order Form Request to OrderDoc Mapper.")
  void testDeleteOrderFormRequestToOrderDoc() {
    OrderDoc orderdoc = orderMapper.toOrderDoc(TestUtil.createValidDeleteOrderFormRequestBean());
    assertEquals("10", orderdoc.getOrderID());
  }
}
