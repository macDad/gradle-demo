package com.singtel5g.portal.order.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.OrderCountRequest;
import com.singtel5g.portal.order.bean.request.OrderTypeItem;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.DeleteOrderResponseBean;
import com.singtel5g.portal.order.bean.response.MECSearchOrderResponseBean;
import com.singtel5g.portal.order.bean.response.OrderCountResponse;
import com.singtel5g.portal.order.bean.response.SaveOrderResponseBean;
import com.singtel5g.portal.order.bean.response.SearchOrderResponseBean;
import com.singtel5g.portal.order.common.OrderType;
import com.singtel5g.portal.order.facade.OrderManagementFacade;
import com.singtel5g.portal.order.util.TestUtil;
import com.singtel5g.portal.security.component.AuthCheck;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;
import java.util.List;
import net.minidev.json.JSONObject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import uk.co.jemos.podam.api.PodamFactory;
import uk.co.jemos.podam.api.PodamFactoryImpl;

/**
 * Create by: Kasun Silva
 *
 * <p>Date: 14/9/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service Since: Version 2.0 Description: The
 * Order Management Controller Test Class.
 */
public class OrderManagementControllerTest {
    /**
     * The constant TEST_HEADER.
     */
    protected static final String TEST_HEADER = "TEST_HEADER";
    /**
     * Mock Management Controller.
     */
    @Mock
    OrderManagementFacade orderManagementFacade;
    /**
     * Mock AuthCheck.
     */
    @Mock
    AuthCheck authCheck;
    /**
     * Inject Mock Order Management Controller.
     */
    @InjectMocks
    OrderManagementController orderManagementController;
    PodamFactory factory;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        factory = new PodamFactoryImpl();
    }

    /**
     * Test search order controller by passing valid inputs.
     */
    @Test
    @DisplayName(
            "Testing if search order returns ResponseEntity object correctly for successful inputs.")
    public void testSearchOrder() {
        SearchOrderFormRequestBean searchOrderFormRequestBean =
                TestUtil.createValidSearchOrderFormRequestBean();
        SearchOrderResponseBean searchOrderResponseBean = TestUtil.getSearchOrderResponseBean();
        when(orderManagementFacade.searchOrders(any())).thenReturn(searchOrderResponseBean);
        when(authCheck.hasPermission(any(), any())).thenReturn(true);
        when(authCheck.retreiveUserDetails(any())).thenReturn(TestUtil.getPrivilegesResponse());

        ResponseEntity<?> responseEntity =
                orderManagementController.searchOrder(TEST_HEADER, searchOrderFormRequestBean);

        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }

    @Test
    void testSearchOrderMEC() {

        MECSearchOrderResponseBean.MECJob mecJob =
                factory.manufacturePojoWithFullData(MECSearchOrderResponseBean.MECJob.class);
        MECSearchOrderResponseBean.MECError mecError =
                factory.manufacturePojoWithFullData(MECSearchOrderResponseBean.MECError.class);
        when(orderManagementFacade.searchOrdersMec(any()))
                .thenReturn(
                        new MECSearchOrderResponseBean(
                                Arrays.asList(mecJob),
                                Arrays.asList(mecError)));
        when(authCheck.retreiveUserDetails(any())).thenReturn(TestUtil.getPrivilegesResponse());
        ResponseEntity<?> result =
                orderManagementController.searchOrderMEC("",
                        new SearchOrderFormRequestBean(
                                "userOrgCode", "Singtel", "userDepCode", "userAccountID", "orderID", "fromDate", "toDate", "externalID", ""));
        assertNotNull(result);
    }

    /**
     * Test save order controller by passing valid inputs.
     */
    @Test
    @DisplayName(
            "Testing if save order returns ResponseEntity object correctly for successful adding of order bean.")
    public void testSaveOrder() {
        List<SaveOrderFormRequestBean> saveOrderFormRequestBeanList = TestUtil.createOrderFormBean();
        when(orderManagementFacade.saveOrders(any(), any())).thenReturn(new SaveOrderResponseBean());
        when(authCheck.hasPermission(any(), any())).thenReturn(true);
        ResponseEntity<?> responseEntity =
                orderManagementController.saveOrder(TEST_HEADER, saveOrderFormRequestBeanList);

        assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
        assertEquals(HttpStatus.CREATED.value(), responseEntity.getStatusCodeValue());
    }

    /**
     * Test delete order controller by passing valid inputs.
     */
    @Test
    @DisplayName(
            "Testing if delete order returns ResponseEntity object correctly for successful inputs.")
    public void deleteOrder() {
        DeleteOrderFormRequestBean deleteOrderFormRequestBean =
                TestUtil.createValidDeleteOrderFormRequestBean();
        when(orderManagementFacade.deleteOrder(any())).thenReturn(new DeleteOrderResponseBean());
        when(authCheck.hasPermission(any(), any())).thenReturn(true);
        ResponseEntity<?> responseEntity =
                orderManagementController.deleteOrder(TEST_HEADER, deleteOrderFormRequestBean);

        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }

    /**
     * Test get order ID controller by passing valid inputs.
     */
    @Test
    @DisplayName("Testing if get order ID returns ResponseEntity object correctly.")
    public void getOrderId() {
        ResponseEntity<?> responseEntity = orderManagementController.getOrderId();

        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }

    /**
     * Test generateOrderID() controller by passing valid inputs.
     */
    @Test
    @DisplayName("Testing if generateOrderID returns ResponseEntity object correctly.")
    void testGenerateOrderID() {
        JSONObject jsonObject = orderManagementController.generateOrderID("10");
        assertEquals("10", jsonObject.get("orderId"));
    }

    /**
     * Test flowOneOrderId() controller by passing valid inputs.
     */
    @Test
    @DisplayName("Testing if flowOneOrderId returns ResponseEntity object correctly.")
    public void testFlowOneOrderId() {
        ResponseEntity<?> responseEntity = orderManagementController.flowOneOrderId();

        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }

    /**
     * Test mecOrderId() controller by passing valid inputs.
     */
    @Test
    @DisplayName("Testing if mecOrderId returns ResponseEntity object correctly.")
    public void testMecOrderId() {
        ResponseEntity<?> responseEntity = orderManagementController.mecOrderId();

        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
        assertEquals(HttpStatus.OK.value(), responseEntity.getStatusCodeValue());
    }

    /**
     * Test orderIdForVendor() controller by passing valid inputs.
     */
    @Test
    @DisplayName("Testing if orderIdForVendor returns ResponseEntity object correctly.")
    public void testOrderIdForVendor() {
        String testVendorCode = "VE001";
        ResponseEntity<?> responseEntity = orderManagementController.orderIdForVendor(testVendorCode);
        assertEquals(MediaType.APPLICATION_JSON, responseEntity.getHeaders().getContentType());
        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    }

    @Test
    void testCountOrder() {
        when(orderManagementFacade.countOrders(any()))
                .thenReturn(
                        new OrderCountResponse(
                                Arrays.asList(
                                        new OrderTypeItem(
                                                OrderType.ADD_NETWORK, "orderItemKey", "orderItemValue", Long.valueOf(1))),
                                "orderStatus",
                                LocalDate.of(2021, Month.FEBRUARY, 19),
                                LocalDate.of(2021, Month.FEBRUARY, 19)));

        ResponseEntity<?> result =
                orderManagementController.countOrder("userDetailsHeader", new OrderCountRequest());
        assertNotNull(result);
    }

    @Test
    void testCanViewOrders() {
        Assertions.assertThrows(
                NullPointerException.class,
                () -> orderManagementController.canViewOrders(
                        true,
                        new SearchOrderFormRequestBean(
                                "userOrgCode", "Singtel", "userDepCode", "userAccountID", "orderID", "fromDate", "toDate", "externalId", ""),
                        null));
    }

    @Test
    void testCheckSearchParam() {
        Assertions.assertNotNull(orderManagementController.checkSearchParam("searchParam", "userParam"));
    }
}
