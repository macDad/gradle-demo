package com.singtel5g.portal.order.component;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyMap;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.DeleteOrderResponseBean;
import com.singtel5g.portal.order.bean.response.ProfileResponse;
import com.singtel5g.portal.order.bean.response.SaveOrderResponseBean;
import com.singtel5g.portal.order.bean.response.SearchOrderResponseBean;
import com.singtel5g.portal.order.common.Constant;
import com.singtel5g.portal.order.model.OrderDoc;
import com.singtel5g.portal.order.proxy.AdminProxy;
import com.singtel5g.portal.order.proxy.UserDetailsProxy;
import com.singtel5g.portal.order.repositories.OrderRepository;
import com.singtel5g.portal.order.util.TestUtil;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 7/4/2021<br>
 * Project      : <B>singtel5g-platform-portal-order-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link  OrderManagementProcessorTest} use for
 */

class OrderManagementProcessorTest {
    @Mock
    AuditLogProcessor auditLogProcessor;
    @Mock
    OrderRepository orderRepository;
    @Mock
    UserDetailsProxy userDetailsProxy;
    @Mock
    AdminProxy adminProxy;
    @InjectMocks
    OrderManagementProcessor orderManagementProcessor;
  /**
   * The constant TEST_HEADER.
   */
  protected static final String TEST_HEADER = "TEST_HEADER";
    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }
  /**
   * Test Perform search order by passing OrderID and UserAccountID and UserOrgCode.
   */
    @Test
  @DisplayName("Test Perform Search Order with valid inputs.")
  public void testPerformSearchOrder() {
    SearchOrderFormRequestBean searchOrderFormRequestBean =
        TestUtil.createValidSearchOrderFormRequestBean();
    SearchOrderResponseBean searchOrderResponseBean = new SearchOrderResponseBean();
    List<OrderDoc> orderDocList = TestUtil.getOrderList();
    when(orderRepository.findByUserOrgCodeAndUserAccountIDAndOrderID(any(), any(), any()))
        .thenReturn(orderDocList);
    when(orderRepository.findByUserOrgCodeAndUserAccountID(any(), any())).thenReturn(orderDocList);
    orderManagementProcessor.performSearchOrder(
        searchOrderFormRequestBean, searchOrderResponseBean);
    assertEquals(HttpStatus.OK, searchOrderResponseBean.getResultCode());
    }

  /**
   * Test Perform search order by passing OrderID and UserAccountID.
   */
    @Test
  @DisplayName("Test Perform Search Order by passing OrderID and UserAccountID.")
  public void testPerformSearchOrderByOrderIDAndAccountID() {
    SearchOrderFormRequestBean searchOrderFormRequestBean =
        TestUtil.searchOrderFormRequestBean("1", null, "10");
    SearchOrderResponseBean searchOrderResponseBean = new SearchOrderResponseBean();
    List<OrderDoc> orderDocList = TestUtil.getOrderList();
    when(orderRepository.findByUserOrgCodeAndUserAccountID(any(), any())).thenReturn(orderDocList);
    orderManagementProcessor.performSearchOrder(
        searchOrderFormRequestBean, searchOrderResponseBean);
    when(adminProxy.fetchOrganizations(any())).thenReturn(TestUtil.getOrganizationResponseBean());

    assertEquals(HttpStatus.OK, searchOrderResponseBean.getResultCode());
    }

  /**
   * Test Perform save order with valid save order form request.
   */
    @Test
  @DisplayName("Test Perform Save Order with valid inputs")
  public void testPerformSaveOrder() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeanList = TestUtil.createOrderFormBean();
    List<ProfileResponse> profileResponseList = TestUtil.getProfileResponseList();
    SaveOrderResponseBean saveOrderResponseBean = new SaveOrderResponseBean();
    when(userDetailsProxy.fetchProfiles(any(), any())).thenReturn(profileResponseList);
//    when(orderRepository.saveAll(any())).thenReturn(any());
    orderManagementProcessor.performSaveOrder(TEST_HEADER, saveOrderFormRequestBeanList, saveOrderResponseBean);
    assertEquals(HttpStatus.CREATED, saveOrderResponseBean.getResultCode());
    }

  /**
   * Test Perform delete order with valid delete order form request.
   */
    @Test
  @DisplayName("Test Perform Delete Order.")
  public void testPerformDeleteOrder() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans =
        TestUtil.createValidDeleteOrderFormRequestBean();
    DeleteOrderResponseBean deleteOrderResponseBean = new DeleteOrderResponseBean();
    doNothing().when(orderRepository).delete(any());
    orderManagementProcessor.performDeleteOrder(
        deleteOrderFormRequestBeans, deleteOrderResponseBean);
    assertEquals(HttpStatus.OK, deleteOrderResponseBean.getResultCode());
    }

  /**
   * Test perform audit log for order inquiry.
   */
    @Test
  @DisplayName("Test Perform Audit Log For Order Inquiry.")
  public void testPerformAuditLogForOrderInquiry() {
    SearchOrderFormRequestBean searchOrderFormRequestBean =
        TestUtil.createValidSearchOrderFormRequestBean();
    doNothing().when(auditLogProcessor).auditLog(any(), anyMap());
    assertThatCode(
            () ->
                orderManagementProcessor.performAuditLogForOrderInquiry(
                    Constant.StringConstant.AUDIT_FUNCTION_CODE_INQUIRY.value(),
                    searchOrderFormRequestBean))
        .doesNotThrowAnyException();
    }

  /**
   * Test perform audit log for save order.
   */
    @Test
  public void testPerformAuditLogForSaveOrder() {
    List<SaveOrderFormRequestBean> saveOrderFormRequestBeansList = TestUtil.createOrderFormBean();
    assertThatCode(
            () ->
                orderManagementProcessor.performAuditLogForSaveOrder(
                    Constant.StringConstant.AUDIT_FUNCTION_CODE_CREATE.value(),
                    saveOrderFormRequestBeansList))
        .doesNotThrowAnyException();
    }

  /**
   * Test perform audit log for delete order.
   */
    @Test
  public void testPerformAuditLogForDeleteOrder() {
    DeleteOrderFormRequestBean deleteOrderFormRequestBeans =
        TestUtil.createValidDeleteOrderFormRequestBean();
    assertThatCode(
            () ->
                orderManagementProcessor.performAuditLogForDeleteOrder(
                    Constant.StringConstant.AUDIT_FUNCTION_CODE_DELETED.value(),
                    deleteOrderFormRequestBeans))
        .doesNotThrowAnyException();
    }
}
