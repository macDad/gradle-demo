// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.repositories;

import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.order.model.OrderDoc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.data.mongodb.core.query.Criteria.where;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 4/8/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: Order Repository Implementation
 */
public class OrderRepositoryImpl implements OrderRepositoryCustom {
  private final MongoTemplate mongoTemplate;

  @Value("${search.result.max.size:0}")
  private int maxSize;

    /**
     * Instantiates a new Order repository.
     *
     * @param mongoTemplate the mongo template
     */
    @Autowired
  public OrderRepositoryImpl(MongoTemplate mongoTemplate) {
    this.mongoTemplate = mongoTemplate;
  }

  @Override
  public List<OrderDoc> query(DynamicQuery dynamicQuery) {
    final Query query = new Query();
    final List<Criteria> criteria = new ArrayList<>();
    if (!ObjectUtils.isNullOrEmpty(dynamicQuery.getUserOrgCode())) {
      criteria.add(Criteria.where("userOrgCode").is(dynamicQuery.getUserOrgCode()));
    }
    if (!ObjectUtils.isNullOrEmpty(dynamicQuery.getUserDepCode())) {
      criteria.add(Criteria.where("userDetails.userDepCode").is(dynamicQuery.getUserDepCode()));
    }
    if (!ObjectUtils.isNullOrEmpty(dynamicQuery.getToDate())) {
      criteria.add(where("creationDate").lte(dynamicQuery.getToDate()));
    }
    if (!ObjectUtils.isNullOrEmpty(dynamicQuery.getFromDate())) {
      criteria.add(where("creationDate").gte(dynamicQuery.getFromDate()));
    }
    if (!ObjectUtils.isNullOrEmpty(dynamicQuery.getUserAccountID())) {
      criteria.add(Criteria.where("userAccountID").is(dynamicQuery.getUserAccountID()));
    }
    if (!ObjectUtils.isNullOrEmpty(dynamicQuery.getOrderID())) {
      criteria.add(Criteria.where("orderID").is(dynamicQuery.getOrderID()));
    }
    if (!ObjectUtils.isNullOrEmpty(dynamicQuery.getExternalID())) {
      criteria.add(Criteria.where("externalID").is(dynamicQuery.getExternalID()));
    }
    if (!criteria.isEmpty()) {
      query.addCriteria(
              new Criteria().andOperator(criteria.toArray(new Criteria[criteria.size()])));
    }

    if (maxSize > 0){
      query.with(Sort.by(Sort.Direction.DESC, "creationDate"));
      query.limit(maxSize);
    }

    return mongoTemplate.find(query, OrderDoc.class);
  }
}
