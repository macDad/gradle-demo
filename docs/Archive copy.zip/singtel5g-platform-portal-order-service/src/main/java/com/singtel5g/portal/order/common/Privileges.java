// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.common;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 13/7/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service Since: version 1.0 Description: The enum
 * privileges
 */
public enum Privileges {
  /** Add order privileges. */
  ADD_ORDER("/order/add"),
  /** Update order privileges. */
  UPDATE_ORDER("/order/upate"),
  /** Delete order privileges. */
  DELETE_ORDER("/order/delete"),
  /** View order privileges. */
  VIEW_ORDER("/order/view"),
  /** Manage orgs privileges. */
  MANAGE_ORGS("/organization/add"),

  /** Admin org privileges. */
  ADMIN_ORG("/organization/admin"),

  /** Admin departments privileges. */
  ADMIN_DEPARTMENTS("/organization/department/add"),
  /** Manage departments privileges. */
  MANAGE_DEPARTMENTS("/organization/department/add"),
  /** system user privileges. */
  SYSTEM_USER("/user/paragon/systemuser"),
  /** Super admin privileges. */
  SUPER_ADMIN("/user/paragon/systemuser");
    private final String value;

    Privileges(String value) {
        this.value = value;
    }

  /**
   * Value string.
   *
   * @return the string
   */
  public String value() {
        return value;
    }
}
