// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.repositories;

import com.singtel5g.portal.order.model.OrderDoc;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 11/6/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: Order Repository interface
 */
public interface OrderRepository extends MongoRepository<OrderDoc, Long>, OrderRepositoryCustom {
    /**
     * Find first by device doc device doc.
     *
     * @param orderID the device id
     * @return the device doc
     */
    List<OrderDoc> findFirstByOrderID(String orderID);

    /**
     * Find by device doc and applicationstatus device doc.
     *
     * @param orderID the device id
     * @param status  the applicationstatus
     * @return the device doc
     */
    List<OrderDoc> findByOrderIDAndStatus(String orderID, String status);

    /**
     * Find by user account id and device id device doc.
     *
     * @param userOrgCode   the user org code
     * @param userAccountID the user account id
     * @param orderID       the device id
     * @return the device doc
     */
    List<OrderDoc> findByUserOrgCodeAndUserAccountIDAndOrderID(
          String userOrgCode, String userAccountID, String orderID);

    /**
     * Find by user account id and device id device doc.
     *
     * @param userOrgCode   the user org code
     * @param userAccountID the user account id
     * @return the device doc
     */
    List<OrderDoc> findByUserOrgCodeAndUserAccountID(String userOrgCode, String userAccountID);

    /**
     * Find by user account id device doc.
     *
     * @param userOrgCode the user org code
     * @return the device doc
     */
    List<OrderDoc> findByUserOrgCode(String userOrgCode);

    /**
     * Find custom by device doc device doc.
     *
     * @param orderID the device id
     * @return the device doc
     */
// Supports native JSON query string
  @Query("{orderID:'?0'}")
  List<OrderDoc> findCustomByOrderID(String orderID);

    /**
     * Find custom by ordering period list.
     *
     * @param userOrgCode   the user org code
     * @param userAccountID the user account id
     * @param fromDate      the from date
     * @param toDate        the to date
     * @return the list
     */
    @Query(
          "{$and:[{userOrgCode : '?0'},{userAccountID : '?1'},{'creationDate' : { $gte: '?2', $lte: '?3' } }]}")
  List<OrderDoc> findCustomByOrderingPeriod(
          String userOrgCode, String userAccountID, String fromDate, String toDate);

    /**
     * Find custom by ordering period list.
     *
     * @param userOrgCode the user org code
     * @param fromDate    the from date
     * @param toDate      the to date
     * @return the list
     */
    @Query("{$and:[{userOrgCode : '?0'},{'creationDate' : { $gte: '?1', $lte: '?2' } }]}")
  List<OrderDoc> findCustomByOrderingPeriod(String userOrgCode, String fromDate, String toDate);

    /**
     * Find custom by reg ex device doc list.
     *
     * @param orderID the device id
     * @return the list
     */
    @Query("{orderID: { $regex: ?0 } })")
  List<OrderDoc> findCustomByRegExOrderID(String orderID);

    Long countByUserOrgCodeAndOrderTypeAndStatusAndCreationDateBetween(String userOrgCode, String orderType, String status, String fromDate, String toDate);

    @Query(value = "{$and : [{'userOrgCode' : '?0'}, {'orderType' : '?1'}, {'status' : '?2'}, {'orderItems.networkType' : '?3'}, {'creationDate' : { $gte: '?4', $lte: '?5' } }]}", count = true)
    Long countDocumentsByOrderTypeAndOrderItem(String userOrgCode, String orderType, String status, String orderItem, String fromDate, String toDate);
}
