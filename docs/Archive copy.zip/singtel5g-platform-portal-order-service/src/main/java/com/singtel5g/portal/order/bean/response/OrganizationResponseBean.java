package com.singtel5g.portal.order.bean.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Organization response.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrganizationResponseBean extends OrderResponseBean  {
    private String organizationCode;
    private String organizationName;
}
