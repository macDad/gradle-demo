// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

package com.singtel5g.portal.order.component;

import com.singtel5g.portal.core.exception.ErrorCodes;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.core.utils.OrderManagementUtils;
import com.singtel5g.portal.core.utils.StringUtils;
import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.OrderCountRequest;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.DeleteOrderResponseBean;
import com.singtel5g.portal.order.bean.response.SaveOrderResponseBean;
import com.singtel5g.portal.order.common.Constant;
import com.singtel5g.portal.order.common.Privileges;
import com.singtel5g.portal.security.component.AuthCheck;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 13/7/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description:  The type Order management validator derivator.
 */
@Component
public class OrderManagementValidatorDerivator {
    /**
     * The constant REQUEST_FORM.
     */
    private static final String REQUEST_FORM = "Request form";
    /**
     * The constant ORG_CODE.
     */
    private static final String ORG_CODE = "Org CODE";
    /**
     * The constant ORG_CODE.
     */
    private static final String FROM_DATE = "From Date";

    /**
     * The constant NULL_OR_EMPTY_CONSTANT.
     */
    private static final String NULL_OR_EMPTY_CONSTANT = " cannot be null or empty.";
    /**
     * The Application name.
     */
    @Value("${spring.application.name}")
    public String APPLICATION_NAME;
    /** The Application name. */

    /**
     * auth check interceptor
     */
    @Autowired
    AuthCheck authCheck;

    /**
     * Validate search device form.
     *
     * @param searchOrderFormRequestBean the search device form
     * @return
     */
    public void validateSearchOrderForm(SearchOrderFormRequestBean searchOrderFormRequestBean) {
        validateRequestForm(ObjectUtils.isNullOrEmpty(searchOrderFormRequestBean), REQUEST_FORM);

        boolean isSuperAdmin = authCheck.hasPermission(searchOrderFormRequestBean.getContext().get(Constant.X_USER_DETAILS),
            Privileges.SYSTEM_USER.value());

        searchOrderFormRequestBean.addContext(Constant.IS_SUPER_ADMIN, String.valueOf(isSuperAdmin));

        if(!isSuperAdmin){
            validateOrganizationCode(searchOrderFormRequestBean.getUserOrgCode(),
                    searchOrderFormRequestBean.getUserSearchOrgCode());
        }
    }

    /**
     * Validate count order request
     *
     * @param orderCountRequest the count order request
     * @return
     */
    public void validateOrderCountRequest(
            OrderCountRequest orderCountRequest) {
        validateRequestForm(ObjectUtils.isNullOrEmpty(orderCountRequest), REQUEST_FORM);
        validateRequestForm(orderCountRequest.getFromDate(), FROM_DATE);
    }

    /**
     * Validate request form.
     *
     * @param nullOrEmpty the null or empty
     * @param requestForm the request form
     */
    protected void validateRequestForm(boolean nullOrEmpty, String requestForm) {
        if (nullOrEmpty) {
            throw ExceptionUtils.newValidationException(
                    APPLICATION_NAME,
                    ErrorCodes.VALIDATION_PARSE_ERROR,
                    requestForm + NULL_OR_EMPTY_CONSTANT);
        }
    }

    /**
     * Validate request form.
     *
     * @param status    the status
     * @param fieldName the field name
     */
    protected void validateRequestForm(String status, String fieldName) {
        validateRequestForm(StringUtils.isNullOrBlank(status), fieldName);
    }

    /**
     * Validate save order form.
     *
     * @param saveOrderFormRequestBeans the save order form request beans
     * @param saveOrderResponseBean     the save order response bean
     */
    public void validateSaveOrderForm(
            @Valid List<SaveOrderFormRequestBean> saveOrderFormRequestBeans,
            SaveOrderResponseBean saveOrderResponseBean) {
        validateRequestForm(ObjectUtils.isNullOrEmpty(saveOrderFormRequestBeans), REQUEST_FORM);
        saveOrderFormRequestBeans.forEach(
                saveOrderFormRequestBean -> {
                    validateRequestFormOrderId(saveOrderFormRequestBean, "Order ID");
                    validateRequestForm(saveOrderFormRequestBean.getUserOrgCode(), ORG_CODE);
                    validateRequestForm(saveOrderFormRequestBean.getOrderType(), "Order type");
                    validateRequestForm(saveOrderFormRequestBean.getStatus(), "Status");
                });
    }

    /**
     * Validate delete order form.
     *
     * @param deleteOrderFormRequestBeans the delete order form request beans
     * @param deleteOrderResponseBean     the delete order response bean
     */
    public void validateDeleteOrderForm(
            DeleteOrderFormRequestBean deleteOrderFormRequestBeans,
            DeleteOrderResponseBean deleteOrderResponseBean) {
        validateRequestForm(ObjectUtils.isNullOrEmpty(deleteOrderFormRequestBeans), REQUEST_FORM);
        validateRequestFormOrderId(deleteOrderFormRequestBeans, "Order ID");
        validateRequestForm(deleteOrderFormRequestBeans.getUserOrgCode(), ORG_CODE);
    }

    private void validateRequestFormOrderId(SaveOrderFormRequestBean status, String order_id) {
        if (StringUtils.isNullOrBlank(status.getOrderID())) {
            status.setOrderID(OrderManagementUtils.generateOrderId("PARG"));
        }
    }

    private void validateRequestFormOrderId(DeleteOrderFormRequestBean status, String order_id) {
        if (StringUtils.isNullOrBlank(status.getOrderID())) {
            status.setOrderID(OrderManagementUtils.generateOrderId("PARG"));
        }
    }

    private void validateOrganizationCode(String inputOrganizationCode, String userOrganizationCode){
        validateRequestForm(inputOrganizationCode, ORG_CODE);

        if(!userOrganizationCode.equals(inputOrganizationCode)){
            throw ExceptionUtils.newValidationException(
                APPLICATION_NAME,
                ErrorCodes.VALIDATION_PARSE_ERROR,
                "Please provide a valid user organization code.");
        }

    }
}
