// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.bean.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Create by    : <B>JanithK@Singtel</B>
 *
 * <p>Date      : 23/11/2020<br>
 * Project      : <B>singtel5g-platform-portal-order-service </B><br>
 * Since        : version 4.2 <br></p>
 * Description  : Order count request type
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderCountRequest extends SearchOrderFormRequestBean {

    @Schema(description = "Order type with order item")
    List<OrderTypeItem> orderTypes;

    @Schema(description = "Order status for the search", example = "COMPLETED")
    String orderStatus;

}
