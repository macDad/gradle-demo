// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
/**
 * Create by: P1329406@Singtel
 *
 * <p>Description:
 */
package com.singtel5g.portal.order.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.singtel5g.portal.core.annotation.LogEnabled;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.core.utils.OrderManagementUtils;
import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.OrderCountRequest;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.DeleteOrderResponseBean;
import com.singtel5g.portal.order.bean.response.MECSearchOrderResponseBean;
import com.singtel5g.portal.order.bean.response.OrderCountResponse;
import com.singtel5g.portal.order.bean.response.SaveOrderResponseBean;
import com.singtel5g.portal.order.bean.response.SearchOrderResponseBean;
import com.singtel5g.portal.order.common.Constant;
import com.singtel5g.portal.order.common.Privileges;
import com.singtel5g.portal.order.facade.OrderManagementFacade;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;
import com.singtel5g.portal.security.component.AuthCheck;
import io.micrometer.core.annotation.Timed;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.List;
import javax.validation.Valid;
import net.minidev.json.JSONObject;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 6/5/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: The type Order management controller.
 */
@LogEnabled
@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping("/api/v1/order")
@Tag(name = "OrderManagementController", description = "Order Management API")
public class OrderManagementController implements OrderManagementHelper {

    /**
     * The constant SEARCH_ORDER.
     */
  protected static final String SEARCH_ORDER = "/search";

    /**
     * The constant SEARCH_ORDER_MEC.
     */
  protected static final String SEARCH_ORDER_MEC = "/search/mec";

    /**
     * The constant SAVE_ORDER.
     */
  protected static final String SAVE_ORDER = "/save";

    /**
     * The constant DELETE_ORDER.
     */
  protected static final String DELETE_ORDER = "/delete";

    /**
     * The constant FLOWONE_ORDER_ID.
     */
  protected static final String FLOWONE_ORDER_ID = "/order-id/flowone";

    /**
     * The constant MEC_ORDER_ID.
     */
  protected static final String MEC_ORDER_ID = "/order-id/mec";

    /**
     * The constant ORDER_ID.
     */
  protected static final String ORDER_ID = "/order-id";

    /**
     * The constant ORDER_ID_VENDOR.
     */
  protected static final String ORDER_ID_VENDOR = "/order-id/vendor/{vendor}";

    /**
     * The constant COUNT_ORDER.
     */
  protected static final String COUNT_ORDER = "/count";

    /**
     * The constant EXCEPTION_WHILE_SEARCH_ORDER.
     */
  protected static final String EXCEPTION_WHILE_SEARCH_ORDER = "Exception while Search Order.";

    /**
     * The constant RETURN_PAYLOAD.
     */
  protected static final String RETURN_PAYLOAD = "return payload : {}. ";

    /**
     * The Order Management component.
     */
  @Autowired OrderManagementFacade orderManagementFacade;

    /**
     * auth check interceptor
     */
  @Autowired AuthCheck authCheck;

  /**
   * Search single/bulk device serviceRequestBean.
   *
   * @param userDetailsHeader the user details header
   * @param searchOrderFormRequestBean the serach device form request bean
   * @return the response entity
   */
  @Operation(
      summary = "Returns collection of Orders for given search criteria s",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @PostMapping(SEARCH_ORDER)
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  @Timed(value = "ddd")
  public ResponseEntity<?> searchOrder(
      @RequestHeader(name = Constant.X_USER_DETAILS, required = false) String userDetailsHeader,
      @Valid @RequestBody SearchOrderFormRequestBean searchOrderFormRequestBean) {
    try {
      PrivilegesResponse retrievedUserDetails = authCheck.retreiveUserDetails(userDetailsHeader);
      searchOrderFormRequestBean.setUserAccountID(retrievedUserDetails.getUsername());
      searchOrderFormRequestBean.setUserOrgCode(retrievedUserDetails.getOrganizationCode());
      if (!canViewOrders(
          authCheck.isAuthCheckEnabled(), searchOrderFormRequestBean, retrievedUserDetails) ||
              !authorizedSearch(searchOrderFormRequestBean, retrievedUserDetails)) {
        LogUtils.INFO(
            this.getClass(),
            "authCheck()",
            "result :"
                + Constant.StringConstant.UNAUTH_MESSAGE.value()
                + "[service:order][action:searchOrder][type:unauthorized]");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
      }
      searchOrderFormRequestBean.addContext(Constant.X_USER_DETAILS, userDetailsHeader);
      searchOrderFormRequestBean.addContext(Constant.USERNAME, retrievedUserDetails.getUsername());
      searchOrderFormRequestBean.addContext(Constant.ORGANIZATION_CODE, retrievedUserDetails.getOrganizationCode());
      searchOrderFormRequestBean.addContext(Constant.ORGANIZATION_NAME, retrievedUserDetails.getOrganizationName());

      SearchOrderResponseBean searchOrderResponseBean =
          orderManagementFacade.searchOrders(searchOrderFormRequestBean);
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(searchOrderResponseBean, headers, HttpStatus.OK);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * Search single/bulk device serviceRequestBean For MEC.
   *
   * @param userDetailsHeader the user details header
   * @param searchOrderFormRequestBean the search device form request bean
   * @return the response entity
   */
  @Operation(
      summary = "Returns collection of Orders for given search criteria s",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @PostMapping(SEARCH_ORDER_MEC)
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  public ResponseEntity<?> searchOrderMEC(
      @RequestHeader(name = Constant.X_USER_DETAILS, required = false) String userDetailsHeader,
      @Valid @RequestBody SearchOrderFormRequestBean searchOrderFormRequestBean) {
    try {
      PrivilegesResponse retrievedUserDetails = authCheck.retreiveUserDetails(userDetailsHeader);
      searchOrderFormRequestBean.addContext(Constant.X_USER_DETAILS, userDetailsHeader);
      searchOrderFormRequestBean.addContext(Constant.USERNAME, retrievedUserDetails.getUsername());
      searchOrderFormRequestBean.addContext(Constant.ORGANIZATION_CODE, retrievedUserDetails.getOrganizationCode());
      searchOrderFormRequestBean.addContext(Constant.ORGANIZATION_NAME, retrievedUserDetails.getOrganizationName());

      MECSearchOrderResponseBean searchOrderResponseBean =
          orderManagementFacade.searchOrdersMec(searchOrderFormRequestBean);
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(searchOrderResponseBean, headers, HttpStatus.OK);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * Save (Insert or update) Order details to database.
   *
   * @param userDetailsHeader the user details header
   * @param saveOrderFormRequestBean the save order form request bean
   * @return the response entity
   */
  @Operation(
      summary = " Save (Insert or update) Order details to database",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "201",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @PostMapping(SAVE_ORDER)
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  public ResponseEntity<?> saveOrder(
      @RequestHeader(name = Constant.X_USER_DETAILS, required = false) String userDetailsHeader,
      @Valid @RequestBody List<SaveOrderFormRequestBean> saveOrderFormRequestBean) {
    try {
      if (!authCheck.hasPermission(userDetailsHeader, Privileges.ADD_ORDER.value())
          && !authCheck.hasPermission(userDetailsHeader, Privileges.SYSTEM_USER.value())) {
        LogUtils.INFO(
            this.getClass(),
            "authCheck()",
            "result :"
                + Constant.StringConstant.UNAUTH_MESSAGE.value()
                + "[service:order][action:saveOrder][type:unauthorized]");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
      }
      SaveOrderResponseBean saveOrderResponseBean =
          orderManagementFacade.saveOrders(userDetailsHeader, saveOrderFormRequestBean);
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(saveOrderResponseBean, headers, HttpStatus.CREATED);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * Delete Order details to database.
   *
   * @param userDetailsHeader the user details header
   * @param deleteOrderFormRequestBeans the delete order form request beans
   * @return the response entity
   */
  @Operation(
      summary = "Delete Order details to database",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @PostMapping(DELETE_ORDER)
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  public ResponseEntity<?> deleteOrder(
      @RequestHeader(name = Constant.X_USER_DETAILS, required = false) String userDetailsHeader,
      @Valid @RequestBody DeleteOrderFormRequestBean deleteOrderFormRequestBeans) {
    try {
      if (!authCheck.hasPermission(userDetailsHeader, Privileges.DELETE_ORDER.value())
          && !authCheck.hasPermission(userDetailsHeader, Privileges.SYSTEM_USER.value())) {
        LogUtils.INFO(
            this.getClass(),
            "authCheck()",
            "result :"
                + Constant.StringConstant.UNAUTH_MESSAGE.value()
                + "[service:order][action:deleteOrder][type:unauthorized]");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
      }
      DeleteOrderResponseBean deleteOrderResponseBean =
          orderManagementFacade.deleteOrder(deleteOrderFormRequestBeans);
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(deleteOrderResponseBean, headers, HttpStatus.OK);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * order id response entity.
   *
   * @return the response entity
   */
  @Operation(
      summary = "Returns generated Order ID",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @GetMapping(ORDER_ID)
  public ResponseEntity<?> getOrderId() {
    try {
      JSONObject json = generateOrderID(OrderManagementUtils.generateOrderId());
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(json, headers, HttpStatus.OK);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * Generate order id json object.
   *
   * @param orderId the order id
   * @return the json object
   */
  @NotNull
  protected JSONObject generateOrderID(String orderId) {
    JSONObject json = new JSONObject();
    json.put("orderId", orderId);
    return json;
  }

  /**
   * Flow one order id response entity.
   *
   * @return the response entity
   */
  @Operation(
      summary = "Returns generated Flow one Order ID",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @GetMapping(FLOWONE_ORDER_ID)
  public ResponseEntity<?> flowOneOrderId() {
    try {
      JSONObject json = generateOrderID(OrderManagementUtils.generateFlowOneOrderId());
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(json, headers, HttpStatus.OK);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * MEC order id response entity.
   *
   * @return the response entity
   */
  @Operation(
      summary = "Returns generated MEC Order ID",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @GetMapping(MEC_ORDER_ID)
  public ResponseEntity<?> mecOrderId() {
    try {
      JSONObject json = generateOrderID(OrderManagementUtils.generateMECOrderId());
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(json, headers, HttpStatus.OK);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * Flow one order id response entity.
   *
   * @param vendor the vendor
   * @return the response entity
   */
  @Operation(
      summary = "Returns generated Order ID",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @GetMapping(ORDER_ID_VENDOR)
  public ResponseEntity<?> orderIdForVendor(@PathVariable String vendor) {
    try {
      JSONObject json = generateOrderID(OrderManagementUtils.generateOrderId(vendor));

      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      return new ResponseEntity<>(json, headers, HttpStatus.OK);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }

  /**
   * Count orders
   *
   * @param userDetailsHeader the user details header
   * @param orderCountRequest the order count request bean
   * @return the response entity
   */
  @Operation(
      summary = "Returns order count for given count criteria s",
      description = "",
      tags = {"OrderManagementController"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "successful operation",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Search Order API not found",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Failure",
            content = @Content(schema = @Schema(implementation = SearchOrderResponseBean.class)))
      })
  @PostMapping(
      value = COUNT_ORDER,
      produces = {APPLICATION_JSON_VALUE},
      consumes = {APPLICATION_JSON_VALUE})
  @Transactional(propagation = Propagation.NOT_SUPPORTED)
  public ResponseEntity<?> countOrder(
      @RequestHeader(name = Constant.X_USER_DETAILS, required = false) String userDetailsHeader,
      @Valid @RequestBody OrderCountRequest orderCountRequest) {
    try {
      PrivilegesResponse retrievedUserDetails = authCheck.retreiveUserDetails(userDetailsHeader);
      if (!canViewOrders(authCheck.isAuthCheckEnabled(), orderCountRequest, retrievedUserDetails)) {
        LogUtils.INFO(
            this.getClass(),
            "authCheck()",
            "result :"
                + Constant.StringConstant.UNAUTH_MESSAGE.value()
                + "[service:order][action:countOrder][type:unauthorized]");
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
      }
      OrderCountResponse orderCountResponse = orderManagementFacade.countOrders(orderCountRequest);
      return ResponseEntity.ok(orderCountResponse);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
          .body(ExceptionUtils.formatExceptionMessage(e));
    }
  }
}
