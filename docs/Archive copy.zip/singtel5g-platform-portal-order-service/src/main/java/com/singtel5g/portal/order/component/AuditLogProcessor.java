// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
/**
 * Create by: P1329406@Singtel
 *
 * <p>Description:
 */
package com.singtel5g.portal.order.component;

import com.singtel5g.portal.audit.component.AuditWriter;
import com.singtel5g.portal.core.utils.LogUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 13/7/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description:  The audit log processor
 */
@Component
public class AuditLogProcessor {

    /**
     * The Audit writer.
     */
    @Autowired
    AuditWriter auditWriter;

    @Value("${audit.table.name}")
    private String AUDIT_TABLE_NAME;

    /**
     * Perform audit log with necessary parameters
     *
     * @param function the function
     * @param payload  the payload
     */
    public void auditLog(String function, Map<String, Object> payload) {
        LogUtils.INFO(this.getClass(), "auditLog :" + function, "payload :" + payload);
        auditWriter.perform(AUDIT_TABLE_NAME, function, payload);
    }
}
