// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.controller;

import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.common.Privileges;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;

import static com.singtel5g.portal.core.utils.ObjectUtils.isNullOrEmpty;
import static com.singtel5g.portal.core.utils.StringUtils.isNullOrBlank;

/**
 * Create by : <B>MadukaJ@Singtel</B>
 *
 * <p>Date : 16/9/2020<br>
 * Project : <B>singtel5g-platform-portal-order-service </B><br>
 * Since : version 1.0 <br>
 * Description : The interface Order Management helper. {@code OrderManagementHelper} This interface
 * is to provide common functionality for controller classes
 */
public interface OrderManagementHelper {

  /**
   * Can view orders boolean.
   *
   * @param authCheckEnabled the auth check enabled
   * @param searchOrderFormRequestBean the search order form request bean
   * @param retrievedUserDetails the retrieved user details
   * @return boolean boolean
   */
  default boolean canViewOrders(
      boolean authCheckEnabled,
      SearchOrderFormRequestBean searchOrderFormRequestBean,
      PrivilegesResponse retrievedUserDetails) {
        if (!authCheckEnabled) {
            return true;
        } else if (!isNullOrEmpty(searchOrderFormRequestBean)) {
            if (isSystemUser(retrievedUserDetails)) {
                return true;
            }else if (isOrganisationAdmin(retrievedUserDetails)) {
                return searchParamsForOrgAdmin(searchOrderFormRequestBean, retrievedUserDetails);
            } else if (isDepartmentAdmin(retrievedUserDetails)) {
                return searchParamsForDepartmentAdmin(searchOrderFormRequestBean, retrievedUserDetails);
            } else if (!isNullOrBlank(searchOrderFormRequestBean.getUserAccountID())) {
                return checkSearchParam(
                        searchOrderFormRequestBean.getUserAccountID(), retrievedUserDetails.getUsername());
            }
        }
        return false;
    }

    /**
     * To check if user is authorized to view orders from different organisations
     *
     * @param searchOrderFormRequestBean the search order form request bean
     * @param retrievedUserDetails the retrieved user details
     * @return boolean boolean
     */
    default boolean authorizedSearch( SearchOrderFormRequestBean searchOrderFormRequestBean,
            PrivilegesResponse retrievedUserDetails){
        String userOrganisationCode = searchOrderFormRequestBean.getUserOrgCode();
        String inputOrganisationCode = searchOrderFormRequestBean.getUserSearchOrgCode();
        if(!isSuperAdmin(retrievedUserDetails)){
            return userOrganisationCode.equals(inputOrganisationCode);
        }
        return true;
    }


    /**
   * Is super admin boolean.
   *
   * @param retrievedUserDetails the retrieved user details
   * @return the boolean
   */
  private boolean isSuperAdmin(PrivilegesResponse retrievedUserDetails) {
      return !isNullOrEmpty(retrievedUserDetails)
              && retrievedUserDetails.getPrivileges().contains(Privileges.SUPER_ADMIN.value());
  }

    /**
     * Is System User boolean.
     *
     * @param retrievedUserDetails the retrieved user details
     * @return the boolean
     */
    private boolean isSystemUser(PrivilegesResponse retrievedUserDetails) {
        return !isNullOrEmpty(retrievedUserDetails)
                && retrievedUserDetails.getPrivileges().contains(Privileges.SYSTEM_USER.value());
    }
    /**
     * Is organisation admin boolean.
     *
     * @param retrievedUserDetails the retrieved user details
     * @return the boolean
     */
    private boolean isOrganisationAdmin(PrivilegesResponse retrievedUserDetails) {
        return !isNullOrEmpty(retrievedUserDetails)
                && retrievedUserDetails.getPrivileges().contains(Privileges.VIEW_ORDER.value())
                && (retrievedUserDetails.getPrivileges().contains(Privileges.MANAGE_DEPARTMENTS.value())
                || retrievedUserDetails.getPrivileges().contains(Privileges.ADMIN_ORG.value()));
    }

    /**
     * Search params for org admin boolean.
     *
     * @param searchOrderFormRequestBean the search order form request bean
     * @param retrievedUserDetails       the retrieved user details
     * @return the boolean
     */
    private boolean searchParamsForOrgAdmin(
            SearchOrderFormRequestBean searchOrderFormRequestBean,
            PrivilegesResponse retrievedUserDetails) {
        if (!isNullOrBlank(searchOrderFormRequestBean.getUserOrgCode()))
            return checkSearchParam(
                    searchOrderFormRequestBean.getUserOrgCode(), retrievedUserDetails.getOrganizationCode());
        if (!isNullOrBlank(searchOrderFormRequestBean.getUserDepCode())) {
            return checkSearchParam(
                    searchOrderFormRequestBean.getUserDepCode(), retrievedUserDetails.getDepartmentCode());
        }
        if (!isNullOrBlank(searchOrderFormRequestBean.getUserAccountID()))
            return checkSearchParam(
                    searchOrderFormRequestBean.getUserAccountID(), retrievedUserDetails.getId());
        return false;
    }

    /**
     * Id department admin boolean.
     *
     * @param retrievedUserDetails the retrieved user details
     * @return the boolean
     */
    private boolean isDepartmentAdmin(PrivilegesResponse retrievedUserDetails) {
        return !isNullOrEmpty(retrievedUserDetails)
                && retrievedUserDetails.getPrivileges().contains(Privileges.VIEW_ORDER.value())
                && retrievedUserDetails.getPrivileges().contains(Privileges.ADMIN_DEPARTMENTS.value());
    }

    /**
     * Search params for department admin boolean.
     *
     * @param searchOrderFormRequestBean the search order form request bean
     * @param retrievedUserDetails       the retrieved user details
     * @return the boolean
     */
    private boolean searchParamsForDepartmentAdmin(
            SearchOrderFormRequestBean searchOrderFormRequestBean,
            PrivilegesResponse retrievedUserDetails) {
        return !isNullOrBlank(searchOrderFormRequestBean.getUserDepCode())
                ? checkSearchParam(
                searchOrderFormRequestBean.getUserDepCode(), retrievedUserDetails.getDepartmentCode())
                : !isNullOrBlank(searchOrderFormRequestBean.getUserAccountID())
                && checkSearchParam(
                searchOrderFormRequestBean.getUserAccountID(), retrievedUserDetails.getId());
    }

  /**
   * Check search param boolean.
   *
   * @param searchParam the search param
   * @param userParam the user param
   * @return the boolean
   */
  default boolean checkSearchParam(String searchParam, String userParam) {
        return searchParam.equalsIgnoreCase(userParam);
    }
}
