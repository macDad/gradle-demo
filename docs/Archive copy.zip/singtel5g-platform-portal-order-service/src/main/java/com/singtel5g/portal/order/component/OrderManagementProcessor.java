// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.component;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.singtel5g.portal.core.exception.ErrorCodes;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.core.utils.JsonUtils;
import com.singtel5g.portal.core.utils.LazyBeanUtils;
import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.core.utils.StringUtils;
import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.OrderCountRequest;
import com.singtel5g.portal.order.bean.request.OrderTypeItem;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.DeleteOrderResponseBean;
import com.singtel5g.portal.order.bean.response.OrderBean;
import com.singtel5g.portal.order.bean.response.OrderCountResponse;
import com.singtel5g.portal.order.bean.response.OrganizationResponseBean;
import com.singtel5g.portal.order.bean.response.ProfileResponse;
import com.singtel5g.portal.order.bean.response.SaveOrderResponseBean;
import com.singtel5g.portal.order.bean.response.SearchOrderResponseBean;
import com.singtel5g.portal.order.common.Constant;
import com.singtel5g.portal.order.mapper.OrderMapper;
import com.singtel5g.portal.order.model.OrderDoc;
import com.singtel5g.portal.order.proxy.AdminProxy;
import com.singtel5g.portal.order.proxy.UserDetailsProxy;
import com.singtel5g.portal.order.repositories.DynamicQuery;
import com.singtel5g.portal.order.repositories.OrderRepository;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Valid;
import lombok.val;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 13/7/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description:  The type order management processor
 */
@Component
public class OrderManagementProcessor {

    /**
     * The constant START_AUDIT_FUNCTION.
     */
    protected static final String START_AUDIT_FUNCTION = "Start Audit function";

    /**
     * The constant END_AUDIT_FUNCTION.
     */
    protected static final String END_AUDIT_FUNCTION = "End Audit function";
    /**
     * The Audit log processor.
     */
    @Autowired
    protected AuditLogProcessor auditLogProcessor;

    /**
     * The Order repository.
     */
    @Autowired
    private OrderRepository orderRepository;

    /**
     * The User details proxy.
     */
    @Autowired
    UserDetailsProxy userDetailsProxy;

    /**
     * The Admin proxy.
     */
    @Autowired
    AdminProxy adminProxy;

    /**
     * The Object Mapper.
     */
    @Autowired
    ObjectMapper mapper;

    @Value("${search.result.max.size:0}")
    private int maxResultSize;

    /**
     * Perform search device.
     *
     * @param searchOrderFormRequestBean the search device form
     * @param searchOrderResponseBean    the search device response bean
     * @return
     */
    public void performSearchOrder(
            SearchOrderFormRequestBean searchOrderFormRequestBean,
            SearchOrderResponseBean searchOrderResponseBean) {
        DynamicQuery dynamicQuery = null;
        try {
            boolean isSuperAdmin = Boolean.valueOf(searchOrderFormRequestBean.getContext().get(Constant.IS_SUPER_ADMIN));
            if(isSuperAdmin){
                searchOrderFormRequestBean.setUserAccountID("");
                searchOrderFormRequestBean.setUserOrgCode(searchOrderFormRequestBean.getUserSearchOrgCode());
            }
            dynamicQuery =
                    (DynamicQuery) LazyBeanUtils.copyBean(DynamicQuery.class, searchOrderFormRequestBean);
            var orders = orderRepository.query(dynamicQuery);

            Map<String, String> organizationMap = new HashMap<>();


            if(isSuperAdmin){
                //Retrieve All Organization Details
                var organizationList = adminProxy.fetchOrganizations(
                    searchOrderFormRequestBean.getContext().get(Constant.X_USER_DETAILS)
                );

                for(OrganizationResponseBean organizationResponseBean : organizationList){
                    if(!organizationMap.containsKey(organizationResponseBean.getOrganizationCode())){
                        organizationMap.put(organizationResponseBean.getOrganizationCode(), organizationResponseBean.getOrganizationName());
                    }
                }
            }else{
                organizationMap.put(searchOrderFormRequestBean.getContext().get(Constant.ORGANIZATION_CODE),
                    searchOrderFormRequestBean.getContext().get(Constant.ORGANIZATION_NAME));
            }

            List<OrderBean> orderBeanList = new ArrayList<>();
            JsonUtils jsonUtils = new JsonUtils();

            for(OrderDoc orderDoc : orders){
                var orderBean = mapper.readValue(jsonUtils.toJson(orderDoc), OrderBean.class);
                orderBean.setUserOrgName(organizationMap.get(orderBean.getUserOrgCode()));
                orderBeanList.add(orderBean);
            }

            addResults(searchOrderResponseBean, orderBeanList);
            searchOrderResponseBean.setResultCode(HttpStatus.OK);
            searchOrderResponseBean.setMaxResultSize(maxResultSize);
        } catch (IllegalAccessException
                | InstantiationException
                | InvocationTargetException
                | NoSuchMethodException
                | JsonProcessingException e) {
            throw ExceptionUtils.newValidationException(
                    "OrderManagement Service", ErrorCodes.API_GENERIC_ERROR, "Internal server error.");
        }
    }

    /**
     * Add results.
     *
     * @param searchOrderResponseBean the search order response bean
     * @param orders                  the orders
     */
    protected void addResults(
            SearchOrderResponseBean searchOrderResponseBean, List<OrderBean> orders) {
        orders.sort(comparing(OrderBean::getCreationDate));
        searchOrderResponseBean.setResult(orders);
    }

    /**
     * Perform save order.
     *
     * @param userDetailsHeader         the user details header
     * @param saveOrderFormRequestBeans the save order form request beans
     * @param saveOrderResponseBean     the save order response bean
     */
    public void performSaveOrder(
            String userDetailsHeader, @Valid List<SaveOrderFormRequestBean> saveOrderFormRequestBeans,
            SaveOrderResponseBean saveOrderResponseBean) {
        val userIds = saveOrderFormRequestBeans.stream()
                .map(SaveOrderFormRequestBean::getUserAccountID)
                .collect(toList());
        var profileResponseList = userDetailsProxy.fetchProfiles(userDetailsHeader, userIds);
        Map<String, ProfileResponse> profileResponseMap = profileResponseList.stream()
                .collect(toMap(profileResponse -> profileResponse.getId(), userProfile -> userProfile, (a, b) -> b));
        List<OrderDoc> orderDocs =
                saveOrderFormRequestBeans.stream()
                        .map(saveOrderFormRequestBean -> buildOrderDoc(profileResponseMap, saveOrderFormRequestBean))
                        .collect(toList());
        orderRepository.saveAll(orderDocs);
        List<String> orderIdsList = orderDocs.stream().map(OrderDoc::getOrderID).collect(toList());
        saveOrderResponseBean.setResult(orderIdsList);
        saveOrderResponseBean.setResultCode(HttpStatus.CREATED);
    }

    /**
     * Build order doc order doc.
     *
     * @param profileResponseMap       the profile response map
     * @param saveOrderFormRequestBean the save order form request bean
     * @return the order doc
     */
    protected OrderDoc buildOrderDoc(
            Map<String, ProfileResponse> profileResponseMap,
            SaveOrderFormRequestBean saveOrderFormRequestBean) {
        final var profileResponse = profileResponseMap.get(saveOrderFormRequestBean.getUserAccountID());
        OrderDoc orderDoc = OrderMapper.INSTANCE.toOrderDoc(saveOrderFormRequestBean);
        addUserDetailsToOrderDoc(profileResponse, orderDoc);
        return orderDoc;
    }

    /**
     * Add user details to order doc.
     *
     * @param profileResponse the profile response
     * @param orderDoc        the order doc
     */
    protected void addUserDetailsToOrderDoc(ProfileResponse profileResponse, OrderDoc orderDoc) {
        Map<String, Object> userDetails = new HashMap<>();
        if(profileResponse != null) {
	        userDetails.put("firstName", profileResponse.getFirstName());
	        userDetails.put("lastName", profileResponse.getLastName());
	        if (!ObjectUtils.isNullOrEmpty(profileResponse.getDepartment()))
	            userDetails.put("userDepCode", profileResponse.getDepartment().getCode());
	        if (!ObjectUtils.isNullOrEmpty(profileResponse.getCompany()))
	            userDetails.put("userOrgCode", profileResponse.getCompany().getCode());
	        userDetails.put("username", profileResponse.getUsername());
        }
        orderDoc.setUserDetails(userDetails);
    }

    /**
     * Perform delete order.
     *
     * @param deleteOrderFormRequestBeans the delete order form request beans
     * @param deleteOrderResponseBean     the delete order response bean
     */
    public void performDeleteOrder(
            DeleteOrderFormRequestBean deleteOrderFormRequestBeans,
            DeleteOrderResponseBean deleteOrderResponseBean) {
        OrderDoc orderDoc = OrderMapper.INSTANCE.toOrderDoc(deleteOrderFormRequestBeans);
        orderRepository.delete(orderDoc);

        deleteOrderResponseBean.setResult("Order Delete success. OrderId : " + orderDoc.getOrderID());
        deleteOrderResponseBean.setResultCode(HttpStatus.OK);
    }

    /**
     * Perform count order.
     *
     * @param orderCountRequest the count order form
     * @param orderCountResponse the count order response bean
     * @return
     */
    public void performOrderCount(
            OrderCountRequest orderCountRequest,
            OrderCountResponse orderCountResponse) {

        try {
            if(CollectionUtils.isEmpty(orderCountRequest.getOrderTypes())) {
                return;
            }

            orderCountResponse.setOrderTypes(new ArrayList<>());
            orderCountRequest.getOrderTypes().forEach(
                    orderType -> {
                        Long orderTypeCount = 0L;
                        OrderTypeItem orderTypeItem = null;
                        if(StringUtils.isNullOrBlank(orderType.getOrderItemKey())) {
                            orderTypeCount = countByOrderType(orderType, orderCountRequest);
                            orderTypeItem = OrderTypeItem.builder()
                                    .orderType(orderType.getOrderType())
                                    .orderCount(orderTypeCount)
                                    .build();
                        } else {
                            orderTypeCount = countByOrderTypeAndItemType(orderType, orderCountRequest);
                            orderTypeItem = OrderTypeItem.builder()
                                    .orderType(orderType.getOrderType())
                                    .orderItemKey(orderType.getOrderItemKey())
                                    .orderItemValue(orderType.getOrderItemValue())
                                    .orderCount(orderTypeCount).build();
                        }
                        orderCountResponse.getOrderTypes().add(orderTypeItem);
                    }
            );
        } catch (Exception e) {
            throw ExceptionUtils.newValidationException(
                    "OrderManagement Service", ErrorCodes.API_GENERIC_ERROR, "Internal server error.");
        }
    }

    private Long countByOrderType(OrderTypeItem orderType, OrderCountRequest orderCountRequest) {
        return orderRepository.countByUserOrgCodeAndOrderTypeAndStatusAndCreationDateBetween(
                orderCountRequest.getUserOrgCode(),
                orderType.getOrderType().name(),
                orderCountRequest.getOrderStatus(),
                orderCountRequest.getFromDate(),
                orderCountRequest.getToDate()
        );
    }

    private Long countByOrderTypeAndItemType(OrderTypeItem orderType, OrderCountRequest orderCountRequest) {
        return orderRepository.countDocumentsByOrderTypeAndOrderItem(
                orderCountRequest.getUserOrgCode(),
                orderType.getOrderType().name(),
                orderCountRequest.getOrderStatus(),
                orderType.getOrderItemValue(),
                orderCountRequest.getFromDate(),
                orderCountRequest.getToDate()
        );
    }

    /**
     * Perform audit log.
     *
     * @param auditFunction              the audit function
     * @param searchOrderFormRequestBean the search device form
     * @return
     */
    public void performAuditLogForOrderInquiry(
            String auditFunction, SearchOrderFormRequestBean searchOrderFormRequestBean) {
        ObjectMapper oMapper = new ObjectMapper();
        Map<String, Object> payLoad = oMapper.convertValue(searchOrderFormRequestBean, Map.class);
        performAuditLog(auditFunction, payLoad);
    }

    /**
     * Perform audit log.
     *
     * @param auditFunction              the audit function
     * @param orderCountRequest the Order Count request
     * @return
     */
    public void performAuditLogForOrderCount(
            String auditFunction, OrderCountRequest orderCountRequest) {
        ObjectMapper oMapper = new ObjectMapper();
        Map<String, Object> payLoad = oMapper.convertValue(orderCountRequest, Map.class);
        performAuditLog(auditFunction, payLoad);
    }

    /**
     * Perform audit log.
     *
     * @param auditFunction the audit function
     * @param payLoad       the pay load
     */
    private void performAuditLog(String auditFunction, Map<String, Object> payLoad) {
        if (Constant.StringConstant.AUDIT_FUNCTION_CODE_INQUIRY.value().equals(auditFunction)) {
            auditLogProcessor.auditLog(
                    Constant.StringConstant.AUDIT_FUNCTION_CODE_INQUIRY.value(), payLoad);
        } else if (Constant.StringConstant.AUDIT_FUNCTION_CODE_CREATE.value().equals(auditFunction)) {
            auditLogProcessor.auditLog(
                    Constant.StringConstant.AUDIT_FUNCTION_CODE_CREATE.value(), payLoad);
        } else if (Constant.StringConstant.AUDIT_FUNCTION_CODE_DELETED.value().equals(auditFunction)) {
            auditLogProcessor.auditLog(
                    Constant.StringConstant.AUDIT_FUNCTION_CODE_DELETED.value(), payLoad);
        }
    }

    /**
     * Perform audit log for save order.
     *
     * @param auditFunction             the audit function
     * @param saveOrderFormRequestBeans the save order form request beans
     */
    public void performAuditLogForSaveOrder(
      String auditFunction, @Valid List<SaveOrderFormRequestBean> saveOrderFormRequestBeans) {
    ObjectMapper oMapper = new ObjectMapper();
    Map<String, Object> payLoad =
        saveOrderFormRequestBeans.stream()
            .collect(
                toMap(
                    SaveOrderFormRequestBean::getOrderID,
                    saveOrderFormRequestBean ->
                        oMapper.convertValue(saveOrderFormRequestBean, Map.class)));
    LogUtils.INFO(
        this.getClass(), "performAuditLogForSaveOrder ()", "payload : " + payLoad.toString());
    performAuditLog(auditFunction, payLoad);
  }

    /**
     * Perform audit log for delete order.
     *
     * @param auditFunction               the audit function
     * @param deleteOrderFormRequestBeans the delete order form request beans
     */
    public void performAuditLogForDeleteOrder(
            String auditFunction, DeleteOrderFormRequestBean deleteOrderFormRequestBeans) {
        ObjectMapper oMapper = new ObjectMapper();
        Map<String, Object> payLoad = oMapper.convertValue(deleteOrderFormRequestBeans, Map.class);
        performAuditLog(auditFunction, payLoad);
    }
}
