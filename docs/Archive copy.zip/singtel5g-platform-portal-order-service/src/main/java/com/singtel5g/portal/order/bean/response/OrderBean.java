// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.bean.response;

import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by   : <B>yongsheng.kng@Singtel</B>
 * <p>Date      : 20/10/2021<br>
 * Project      : <B>order-service </B>
 * <br> Since   : version 1.0 <br></p>
 * Description  : OrderBean
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrderBean {
    private String id;
    private String orderID;
    private String externalID;
    private String userAccountID;
    private String userOrgCode;
    private String userOrgName;
    private Map<String, Object> userDetails;
    private String orderType;
    private String vendorCode;
    private Map<String, Object> orderItems;
    private String status;
    private String creationDate;
    private String updateDate;
    private String message;
}
