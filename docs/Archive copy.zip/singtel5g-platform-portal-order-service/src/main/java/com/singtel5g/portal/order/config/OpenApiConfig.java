// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 7/5/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: OpenApiConfiguration
 */
@Configuration
public class OpenApiConfig {
    /**
     * The constant DEFAULT_CONTACT.
     */
    public static final Contact DEFAULT_CONTACT =
            new Contact()
                    .name("Singtel 5G Platform Portal")
                    .email("http://www.singtel5gplatform.com")
                    .url("info@singtel5gplatform.com");

    /**
     * The constant LICENSE.
     */
    public static final License LICENSE =
            new License().name("Apache 2.0").url("http://www.apache.org/licenses/LICENSE-2.0.html");

    private static final Set<String> DEFAULT_PRODUCES_AND_CONSUMES =
            new HashSet<>(Arrays.asList("application/json", "application/xml"));
    /**
     * The Api controller package.
     */
    @Value("${api-package}")
    public String API_CONTROLLER_PACKAGE;
    /**
     * The Application name.
     */
    @Value("${application.name}")
    public String APPLICATION_NAME;
    /**
     * The Application description.
     */
    @Value("${application.description}")
    public String APPLICATION_DESCRIPTION;

    /**
     * Custom open api open api.
     *
     * @return the open api
     */
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI().components(new Components()).info(apiEndPointsInfo());
    }

    private Info apiEndPointsInfo() {
        return new Info()
                .title(APPLICATION_NAME)
                .description(APPLICATION_DESCRIPTION)
                .contact(DEFAULT_CONTACT)
                .license(LICENSE)
                .version("1.0.0");
    }
}
