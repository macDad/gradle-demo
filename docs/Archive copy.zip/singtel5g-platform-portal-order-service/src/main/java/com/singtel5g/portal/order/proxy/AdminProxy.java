// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.proxy;

import com.singtel5g.portal.order.bean.response.OrganizationResponseBean;
import com.singtel5g.portal.order.common.Constant;
import java.util.Set;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

/**
 * Created by   : <B>yongsheng.kng@Singtel</B>
 * <p>Date      : 21/10/2021<br>
 * Project      : <B>network-orchestrator-service </B>
 * <br> Since   : version 1.0 <br></p>
 * Description  : AdminProxy
 */
@FeignClient(name = "singtel5g-platform-portal-admin-service", url = "${external.service.endpoint:}")
@RibbonClient(name = "singtel5g-platform-portal-admin-service")
public interface AdminProxy {

  /**
   * Retrieve All Organizations Code.
   *
   * @param userDetailsHeader      the user details header
   * @return the search organization response bean
   */
  @GetMapping("/api/v1/organization")
  Set<OrganizationResponseBean> fetchOrganizations(
      @RequestHeader(name = Constant.X_USER_DETAILS, required = false) String userDetailsHeader);
}
