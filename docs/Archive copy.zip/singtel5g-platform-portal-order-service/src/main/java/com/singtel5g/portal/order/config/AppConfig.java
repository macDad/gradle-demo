// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.config;

import com.singtel5g.portal.core.aop.LoggingAspect;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;

import java.util.Arrays;
import java.util.HashSet;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 11/6/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: App Configurations : Mongo and Logging Aspect
 */
@Configuration
public class AppConfig {
    /**
     * The Mongo url.
     */
    @Value("${spring.data.mongodb.uri}")
    public String MONGO_URL;

    /**
     * Transaction manager mongo transaction manager.
     *
     * @param dbFactory the db factory
     * @return the mongo transaction manager
     */
    @Bean
    MongoTransactionManager transactionManager(MongoDatabaseFactory dbFactory) {
        return new MongoTransactionManager(dbFactory);
    }

    /**
     * LoggingAspect.
     *
     * @return LoggingAspect logging aspect
     */
    @Bean
    public LoggingAspect loggingAspect() {
        LoggingAspect aspect = new LoggingAspect();
        aspect.setEnableDataScrubbing(true);
        aspect.setDefaultScrubbedValue("*******");
        aspect.setParamBlacklistRegex("private.*");
        aspect.setCustomParamBlacklist(new HashSet<>(Arrays.asList("securityProtocol")));
        return aspect;
    }
}
