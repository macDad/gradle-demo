// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.bean.request;

import com.singtel5g.portal.core.beans.CoreRequestBean;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 3/7/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: Search Order Form Request Bean
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SearchOrderFormRequestBean extends CoreRequestBean implements Serializable {

    @Schema(description = "Org Code for User.", example = "ORG1", required = false)
    @NotEmpty(message = "Please provide a user Org Code")
    private String userOrgCode;

    @Schema(description = "Search Code for User.", example = "ORG1", required = true)
    @NotEmpty(message = "Please provide a Org Search Code")
    private String userSearchOrgCode;

    @Schema(description = "Department Code for User.", example = "DEP1", required = false)
    @NotEmpty(message = "Please provide a user Department Code")
    private String userDepCode;

    @Schema(description = "userAccountID.", example = "6", required = false)
    private String userAccountID;

    @Schema(description = "Incremental id per item.", example = "userAccountID", required = false)
    private String orderID;

    @Schema(description = "Orders from Date.", example = "2020-07-03T08:28:29.567Z", required = false)
    private String fromDate;

    @Schema(description = "Orders to Date.", example = "2020-08-03T08:28:29.567Z", required = false)
    private String toDate;

    @Schema(description = "External Id", example = "56eb197a-0852-490c-9a62-de6c32877c2d", required = false)
    private String externalID;

    @Schema(description = "Message", example = "Reason for failure ", required = false)
    private String message;
}
