// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.proxy;

import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.core.utils.SoapClientUtils;
import com.singtel5g.portal.core.utils.XmlUtils;
import com.singtel5g.portal.order.common.template.SoapTemplate;
import okhttp3.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 13/7/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: NSA Search Order Proxy -> performs fetch order status
 */
@Component
public class NSASearchOrderProxy {
    /**
     * The constant APPLICATION_XML.
     */
    protected static final String APPLICATION_XML = "application/xml";
    /**
     * The constant ORDER_MANAGEMENT_URL.
     */
    @Value("${order.management.url.nsa}")
    private String ORDER_MANAGEMENT_URL;
    /**
     * The Flowone api uname.
     */
    @Value("${flowone.api.soap.uname}")
    private String FLOWONE_API_UNAME;
    /**
     * The Flowone api pwd.
     */
    @Value("${flowone.api.soap.pword}")
    private String FLOWONE_API_PWD;

    /**
     * Fetch order status string.
     *
     * @param orderId the order id
     * @return the string
     *
     * @throws ParserConfigurationException the parser configuration exception
     * @throws SAXException                 the sax exception
     * @throws IOException                  the io exception
     */
    public String fetchOrderStatus(final String orderId)
            throws ParserConfigurationException, SAXException, IOException {
        OkHttpClient client = SoapClientUtils.getUnsafeOkHttpClient();
        MediaType mediaType = MediaType.get(APPLICATION_XML);
        RequestBody body =
                RequestBody.Companion.create(
                        SoapTemplate.getOrderManagementTemplate(orderId, FLOWONE_API_UNAME, FLOWONE_API_PWD),
                        mediaType);
        Request request =
                new Request.Builder()
                        .url(ORDER_MANAGEMENT_URL)
                        .post(body)
                        .addHeader("Content-Type", APPLICATION_XML)
                        .build();

        Response response = client.newCall(request).execute();
        /** for some reason this successfully prints out the response* */
        String results = response.body().string();
        if (!response.isSuccessful()) {
            LogUtils.INFO(
                    this.getClass(), "fetchOrderStatus ()", "Response code" + " " + response.code());
        } else {
            LogUtils.INFO(
                    this.getClass(), "fetchOrderStatus ()", "Response code" + " " + response.code());
            List<String> output = XmlUtils.getValueByTagNameFromXml(results, "orderStatus");
            String[] strarray = new String[output.size()];
            output.toArray(strarray);
            LogUtils.INFO(
                    this.getClass(),
                    "fetchOrderStatus ()",
                    "Response Array " + " " + Arrays.toString(strarray));
            return Arrays.toString(strarray)
                    .replace(",", "") // remove the commas
                    .replace("[", "") // remove the right bracket
                    .replace("]", "") // remove the left bracket
                    .trim();
        }
        return "";
    }
}
