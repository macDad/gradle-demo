// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.bean.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 3/7/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: MEC Search Order Response Bean
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MECSearchOrderResponseBean {
    /**
     * The Jobs.
     */
    List<MECJob> jobs;

    /**
     * The Error.
     */
    List<MECError> error;

    /**
     * The type Mec job.
     */
    @Data
    @AllArgsConstructor
    public static class MECJob {
        @JsonProperty("application_id")
        @SerializedName("application_id")
        private String applicationId;

        @JsonProperty("job_id")
        @SerializedName("job_id")
        private String jobId;

        private String action;
        private String progress;
        private String state;

        private Map<String, Object> orderItems;

        @JsonProperty("datacenter_id")
        @SerializedName("datacenter_id")
        private String dataCenterId;

        private String timestamp;
    }

    /**
     * The type Mec error.
     */
    @Data
    @AllArgsConstructor
    public static class MECError {
        private String id;
        private String errorCode;
    }
}
