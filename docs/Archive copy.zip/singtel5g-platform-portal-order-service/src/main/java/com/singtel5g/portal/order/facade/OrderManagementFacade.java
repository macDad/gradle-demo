// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.facade;

import com.singtel5g.portal.core.function.ErrorHandlingType;
import com.singtel5g.portal.core.function.GenericServiceFunction;
import com.singtel5g.portal.core.function.Orchestrator;
import com.singtel5g.portal.core.function.TransactionType;
import com.singtel5g.portal.order.bean.request.DeleteOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.OrderCountRequest;
import com.singtel5g.portal.order.bean.request.SaveOrderFormRequestBean;
import com.singtel5g.portal.order.bean.request.SearchOrderFormRequestBean;
import com.singtel5g.portal.order.bean.response.DeleteOrderResponseBean;
import com.singtel5g.portal.order.bean.response.MECSearchOrderResponseBean;
import com.singtel5g.portal.order.bean.response.OrderBean;
import com.singtel5g.portal.order.bean.response.OrderCountResponse;
import com.singtel5g.portal.order.bean.response.SaveOrderResponseBean;
import com.singtel5g.portal.order.bean.response.SearchOrderResponseBean;
import com.singtel5g.portal.order.common.Constant;
import com.singtel5g.portal.order.component.OrderManagementProcessor;
import com.singtel5g.portal.order.component.OrderManagementValidatorDerivator;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 6/5/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: The type Order management facade.
 */
@Component
public class OrderManagementFacade {
    /**
     * The Constant STARTED.
     */
    protected static final String STARTED = "started {}...";
    /**
     * The Constant ENDED_TIMETAKEN_MS.
     */
    protected static final String ENDED_TIME_TAKEN_MS = "ended {}... time taken: {} ms";
    /**
     * The Validator.
     */
    @Autowired
  OrderManagementValidatorDerivator validator;

    /**
     * The Processor.
     */
    @Autowired
  OrderManagementProcessor processor;

  /* ==============================search Orders===================================*/

    /**
     * Search device for given critiras.
     *
     * @param searchOrderFormRequestBean Request form for creating new device.
     * @return create device response bean
     */
    public SearchOrderResponseBean searchOrders(
          SearchOrderFormRequestBean searchOrderFormRequestBean) {
    SearchOrderResponseBean searchOrderResponseBean = new SearchOrderResponseBean();
    validationSearchOrderInput(searchOrderFormRequestBean);
    processSearchOrderInput(searchOrderFormRequestBean, searchOrderResponseBean);
    return searchOrderResponseBean;
  }

    /**
     * Validation search order input.
     *
     * @param searchOrderFormRequestBean the search order form request bean
     */
    protected void validationSearchOrderInput(
          SearchOrderFormRequestBean searchOrderFormRequestBean) {
    GenericServiceFunction[] func = {
            () -> validator.validateSearchOrderForm(searchOrderFormRequestBean)
    };
    Orchestrator.execute("Search Order", TransactionType.SUPPORT, ErrorHandlingType.GROUP, func);
  }

    /**
     * Process search order input.
     *
     * @param searchOrderFormRequestBean the search order form request bean
     * @param searchOrderResponseBean    the search order response bean
     */
    protected void processSearchOrderInput(
          SearchOrderFormRequestBean searchOrderFormRequestBean,
          SearchOrderResponseBean searchOrderResponseBean) {
    GenericServiceFunction[] func = {
            () -> this.processor.performSearchOrder(searchOrderFormRequestBean, searchOrderResponseBean),
            () ->
                    this.processor.performAuditLogForOrderInquiry(
                            Constant.StringConstant.AUDIT_FUNCTION_CODE_INQUIRY.value(),
                            searchOrderFormRequestBean)
    };
    Orchestrator.execute("Search Order", TransactionType.SUPPORT, ErrorHandlingType.SINGLE, func);
  }

  /* ==============================Count Orders===================================*/

  /**
   * Count orders
   *
   * @param orderCountRequest Request form for counting orders
   * @return create order count response
   */
  public OrderCountResponse countOrders(
          OrderCountRequest orderCountRequest) {
    OrderCountResponse orderCountResponse = new OrderCountResponse();
    validateCountOrderInput(orderCountRequest);
    processCountOrderInput(orderCountRequest, orderCountResponse);
    return orderCountResponse;
  }

  /**
   * Validation count order input.
   *
   * @param orderCountRequest the count order request
   */
  protected void validateCountOrderInput(
          OrderCountRequest orderCountRequest) {
    GenericServiceFunction[] func = {
            () -> validator.validateOrderCountRequest(orderCountRequest)
    };
    Orchestrator.execute("Count Order", TransactionType.SUPPORT, ErrorHandlingType.GROUP, func);
  }

  /**
   * Process search order input.
   *
   * @param orderCountRequest the order count request bean
   * @param orderCountResponse    the order count response bean
   */
  protected void processCountOrderInput(
          OrderCountRequest orderCountRequest,
          OrderCountResponse orderCountResponse) {
    GenericServiceFunction[] func = {
            () -> this.processor.performOrderCount(orderCountRequest, orderCountResponse),
            () ->
                    this.processor.performAuditLogForOrderCount(
                            Constant.StringConstant.AUDIT_FUNCTION_CODE_INQUIRY.value(),
                            orderCountRequest)
    };
    Orchestrator.execute("Count Order", TransactionType.SUPPORT, ErrorHandlingType.SINGLE, func);
  }


  /* ==============================Save Orders===================================*/

    /**
     * Save orders save order response bean.
     *
     * @param userDetailsHeader        the user details header
     * @param saveOrderFormRequestBean the save order form request bean
     * @return the save order response bean
     */
    public SaveOrderResponseBean saveOrders(
          String userDetailsHeader, @Valid List<SaveOrderFormRequestBean> saveOrderFormRequestBean) {
    SaveOrderResponseBean saveOrderResponseBean = new SaveOrderResponseBean();
    validationSaveOrderInput(saveOrderFormRequestBean, saveOrderResponseBean);
    processSaveOrderInput(userDetailsHeader,saveOrderFormRequestBean, saveOrderResponseBean);
    return saveOrderResponseBean;
  }

    /**
     * Validation save order input.
     *
     * @param saveOrderFormRequestBean the save order form request bean
     * @param saveOrderResponseBean    the save order response bean
     */
    protected void validationSaveOrderInput(
          @Valid List<SaveOrderFormRequestBean> saveOrderFormRequestBean,
          SaveOrderResponseBean saveOrderResponseBean) {
    GenericServiceFunction[] func = {
            () -> validator.validateSaveOrderForm(saveOrderFormRequestBean, saveOrderResponseBean)
    };
    Orchestrator.execute("Save Order", TransactionType.SUPPORT, ErrorHandlingType.GROUP, func);
  }

    /**
     * Process save order input.
     *
     * @param userDetailsHeader        the user details header
     * @param saveOrderFormRequestBean the save order form request bean
     * @param saveOrderResponseBean    the save order response bean
     */
    protected void processSaveOrderInput(
          String userDetailsHeader, @Valid List<SaveOrderFormRequestBean> saveOrderFormRequestBean,
          SaveOrderResponseBean saveOrderResponseBean) {
    GenericServiceFunction[] func = {
            () -> this.processor.performSaveOrder(userDetailsHeader,saveOrderFormRequestBean, saveOrderResponseBean),
            () ->
                    this.processor.performAuditLogForSaveOrder(
                            Constant.StringConstant.AUDIT_FUNCTION_CODE_CREATE.value(), saveOrderFormRequestBean)
    };
    Orchestrator.execute("Save Order", TransactionType.SUPPORT, ErrorHandlingType.SINGLE, func);
  }

  /* ==============================Delete Orders===================================*/

    /**
     * Delete order delete order response bean.
     *
     * @param deleteOrderFormRequestBeans the delete order form request beans
     * @return the delete order response bean
     */
    public DeleteOrderResponseBean deleteOrder(
          DeleteOrderFormRequestBean deleteOrderFormRequestBeans) {
    DeleteOrderResponseBean deleteOrderResponseBean = new DeleteOrderResponseBean();
    validationDeleteOrderInput(deleteOrderFormRequestBeans, deleteOrderResponseBean);
    processDeleteOrderInput(deleteOrderFormRequestBeans, deleteOrderResponseBean);
    return deleteOrderResponseBean;
  }

    /**
     * Validation delete order input.
     *
     * @param deleteOrderFormRequestBeans the delete order form request beans
     * @param deleteOrderResponseBean     the delete order response bean
     */
    protected void validationDeleteOrderInput(
          DeleteOrderFormRequestBean deleteOrderFormRequestBeans,
          DeleteOrderResponseBean deleteOrderResponseBean) {
    GenericServiceFunction[] func = {
            () -> validator.validateDeleteOrderForm(deleteOrderFormRequestBeans, deleteOrderResponseBean)
    };
    Orchestrator.execute("Delete Order", TransactionType.SUPPORT, ErrorHandlingType.GROUP, func);
  }

    /**
     * Process delete order input.
     *
     * @param deleteOrderFormRequestBeans the delete order form request beans
     * @param deleteOrderResponseBean     the delete order response bean
     */
    protected void processDeleteOrderInput(
          DeleteOrderFormRequestBean deleteOrderFormRequestBeans,
          DeleteOrderResponseBean deleteOrderResponseBean) {
    GenericServiceFunction[] func = {
            () -> this.processor.performDeleteOrder(deleteOrderFormRequestBeans, deleteOrderResponseBean),
            () ->
                    this.processor.performAuditLogForDeleteOrder(
                            Constant.StringConstant.AUDIT_FUNCTION_CODE_DELETED.value(),
                            deleteOrderFormRequestBeans)
    };
    Orchestrator.execute("Delete Order", TransactionType.SUPPORT, ErrorHandlingType.SINGLE, func);
  }

  /* ==============================search Orders MEC ===================================*/

    /**
     * Search device for given critiras.
     *
     * @param searchOrderFormRequestBean Request form for creating new device.
     * @return create device response bean
     */
    public MECSearchOrderResponseBean searchOrdersMec(
          SearchOrderFormRequestBean searchOrderFormRequestBean) {
    SearchOrderResponseBean searchOrderResponseBean = new SearchOrderResponseBean();
    validationSearchOrderInput(searchOrderFormRequestBean);
    processSearchOrderInput(searchOrderFormRequestBean, searchOrderResponseBean);
    MECSearchOrderResponseBean mecSearchOrderResponseBean = new MECSearchOrderResponseBean();
    additionalProcessSearchOrderInput(searchOrderResponseBean, mecSearchOrderResponseBean);
    return mecSearchOrderResponseBean;
  }

    /**
     * Additional process search order input.
     *
     * @param searchOrderResponseBean    the search order response bean
     * @param mecSearchOrderResponseBean the mec search order response bean
     */
    protected void additionalProcessSearchOrderInput(
          SearchOrderResponseBean searchOrderResponseBean,
          MECSearchOrderResponseBean mecSearchOrderResponseBean) {
    List<MECSearchOrderResponseBean.MECError> errors = new ArrayList<>();
    try {
      List<OrderBean> orderBeans = (List<OrderBean>) searchOrderResponseBean.getResult();
      List<MECSearchOrderResponseBean.MECJob> jobs =
              orderBeans.stream()
                      .map(
                              orderBean ->
                                      new MECSearchOrderResponseBean.MECJob(
                                              orderBean.getExternalID(),
                                              orderBean.getOrderID(),
                                              orderBean.getOrderType(),
                                              "",
                                              orderBean.getStatus(),
                                              orderBean.getOrderItems(),
                                              "",
                                              orderBean.getUpdateDate()))
                      .collect(Collectors.toList());
      mecSearchOrderResponseBean.setJobs(jobs);
    } catch (Exception e) {
      errors.add(new MECSearchOrderResponseBean.MECError("", e.getMessage()));
      mecSearchOrderResponseBean.setError(errors);
    }
  }
}
