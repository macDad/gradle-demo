// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.common.template;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.jetbrains.annotations.NotNull;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 13/7/2020<br>
 *     Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description:  SOAP Template use to get Order Details From Flowone
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class SoapTemplate {
    /**
     * Gets order management template.
     *
     * @param orderId  the order id
     * @param username the username
     * @param password the password
     * @return the order management template
     */
    @NotNull
    public static String getOrderManagementTemplate(
            String orderId, final String username, final String password) {
        return String.format(
                "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:ord=\"http://xml.comptel.com/2011/09/ordermanagement\">\n"
                        + "   <soap:Header>\n"
                        + "      <wsse:Security soap:mustUnderstand=\"true\" xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">\n"
                        + "         <wsse:UsernameToken wsu:Id=\"SOAI_req_SOAI\">\n"
                        + "            <wsse:Username>%s</wsse:Username>\n"
                        + "            <wsse:Password Type=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText\">%s</wsse:Password>\n"
                        + "         </wsse:UsernameToken>\n"
                        + "      </wsse:Security>\n"
                        + "   </soap:Header>\n"
                        + "   <soap:Body>\n"
                        + "      <ord:getOrderDetails>\n"
                        + "         <ord:orderIdentification>\n"
                        + "            <!--You may enter the following 2 items in any order-->\n"
                        + "            <!--Optional:-->\n"
                        + "             <!--Optional:-->\n"
                        + "            <ord:orderNo>%%s</ord:orderNo>\n"
                        + "         </ord:orderIdentification>\n"
                        + "      </ord:getOrderDetails>\n"
                        + "   </soap:Body>\n"
                        + "</soap:Envelope>",
                username, password, orderId);
    }
}
