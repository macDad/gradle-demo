// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.proxy;

import com.singtel5g.portal.order.bean.response.ProfileResponse;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.List;

/**
 * Create by    : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 17/9/2020<br>
 * Project      : <B>singtel5g-platform-portal-order-service </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : Fetch profiles list
 */
@FeignClient(name = "singtel5g-platform-portal-auth-service")
@RibbonClient(name = "singtel5g-platform-portal-auth-service")
public interface UserDetailsProxy {
    /**
     * Fetch profiles list.
     *
     * @param userDetailsHeader the user details header
     * @param userIds           the user ids
     * @return the list
     */
    @PostMapping("/api/v1/user/search")
    List<ProfileResponse> fetchProfiles(
            @RequestHeader(name = "X-User-Details", required = false) String userDetailsHeader,
            @RequestBody List<String> userIds);
}
