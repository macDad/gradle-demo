// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.bean.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.util.Map;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 9/7/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: Save Order Form Request Bean
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaveOrderFormRequestBean {

    private String id;

    @Schema(
            description = "order ID.",
            example = "sin5gom-fl1od-jsrvjyd3-200709133857000",
            required = true)
    @NotEmpty(message = "Please provide order ID.")
    private String orderID;

    private String externalID;

    private String userAccountID;

    @Schema(description = "User Organization Code.", example = "ORG1", required = true)
    @NotEmpty(message = "Please User Organization Code.")
    private String userOrgCode;

    private Map<String, Object> userDetails;

    @Schema(description = "Order Type.", example = "ADD_NETWORK | ADD_DEVICE", required = true)
    @NotEmpty(message = "Please Order Type.")
    private String orderType;

    private String vendorCode;

    private Map<String, Object> orderItems;

    @Schema(description = "status.", example = "PLANNED", required = true)
    @NotEmpty(message = "Please provide status.")
    private String status;

    private String creationDate;
    private String updateDate;
}
