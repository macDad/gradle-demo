// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.order.common;

/**
 * Create by: P1329406@Singtel
 *
 * <p>Date: 13/7/2020<br>
 * Project: singtel5g-platform-portal-flowone-order-service
 * Since: version 1.0
 * Description: Constant class that can be used to create new {@code Constant}
 * configurations using {@code Constant.}.
 * <p>Usage:
 * <pre>  *      Constant.AUDIT_FUNCTION_CODE_INQUIRY </pre>
 */
public class Constant {

    private Constant() {
        throw new AssertionError();
    }

    /**
     * The constant X_USER_DETAILS.
     */
    public static final String X_USER_DETAILS = "X-User-Details";

    /**
     * The constant USERNAME.
     */
    public static final String USERNAME = "username";

    /**
     * The constant ORGANIZATION_CODE.
     */
    public static final String ORGANIZATION_CODE = "organizationCode";

    /**
     * The constant ORGANIZATION_NAME.
     */
    public static final String ORGANIZATION_NAME = "organizationName";

    /**
     * The constant IS_SUPER_ADMIN.
     */
    public static final String IS_SUPER_ADMIN = "isSuperAdmin";

    /**
     * The enum String constant.
     */
    public enum StringConstant implements ConstantType {
        /**
         * Audit function code create string constant.
         */
        AUDIT_FUNCTION_CODE_CREATE("create"),
        /**
         * The constant AUDIT_FUNCTION_CODE_INQUIRY.
         */
        AUDIT_FUNCTION_CODE_INQUIRY("inquiry"),
        /**
         * The constant AUDIT_FUNCTION_CODE_DELETED.
         */
        AUDIT_FUNCTION_CODE_DELETED("DELETE"),
        /**
         * Unauthorized message.
         */
        UNAUTH_MESSAGE("Unauthorized API call");

        private final String value;

        StringConstant(String value) {
            this.value = value;
        }

        /**
         * Value string.
         *
         * @return the string
         */
        public String value() {
            return value;
        }
    }

    /**
     * The interface Constant type.
     */
    public interface ConstantType {
    }
}
