/**************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 * ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 **************************************************************************************************/
package com.singtel5g.portal.core.beans;

import com.singtel5g.portal.core.enums.NotificationTypes;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 5/10/2020<br>
 * Project      : <B>5g-platform-portal-core-modules </B><br>
 * Since        : version 1.0 <br></p>
 * Description  :
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public abstract class CoreNotificationBean implements Serializable {
    @Schema(description = "Notification type.", example = "EMAIL / SLACK", required = true)
    @NotEmpty(message = "Please provide a Notification type.")
    private NotificationTypes type;
    private Object source;
    private long sequenceNumber;
    @Schema(description = "Joda Current ISO Date. Leave this empty to use default time stamp", example = "yyyy-MM-dd'T'HH:mm:ssZ", required = false)
    private String currentISODate;
    private String from;
    @Schema(description = "List of recipients.", required = true)
    @NotEmpty(message = "Please provide recipients.")
    private List<String> recipients;
    @Schema(description = "Notification subject.", example = "Mail Subject ", required = false)
    @NotEmpty(message = "Please provide a Notification subject.")
    private String subject;
    @Schema(description = "Notification message.", example = "This is paragon email for rest password ", required = true)
    @NotEmpty(message = "Please provide a Notification message.")
    private Object message;
    private Map<Object, Object> properties;
}
