package com.singtel5g.portal.core.beans;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 25/7/2020<br>
 * Description:
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PlatformResponseBean {
    private Object result;
    private Object orderNo;
    private HttpStatus resultCode;
    private String category;
    private String description;
    private String externalId;
    private Object externalReference;
    private Object note;
    private String state;
}
