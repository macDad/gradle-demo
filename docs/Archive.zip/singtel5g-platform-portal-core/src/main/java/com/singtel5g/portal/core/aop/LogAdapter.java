package com.singtel5g.portal.core.aop;

import com.singtel5g.portal.core.utils.JsonUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 28/8/2020<br>
 * Description: This interface for add all the core functions for logging aspect.
 */
public interface LogAdapter {
    /**
     * This pointcut is for joinpoint corresponding to all public methods in controller
     */
    void allPublicControllerMethodsPointcut();

    /**
     * Method or class logging enabled pointcut.
     */
    void methodOrClassLoggingEnabledPointcut();

    /**
     * Method logging not disabled pointcut.
     */
    void methodLoggingNotDisabledPointcut();

    /**
     * Log object.
     *
     * @param proceedingJoinPoint the proceeding join point
     * @return the object
     *
     * @throws Throwable the throwable
     */
    @Nullable
    Object log(@Nonnull ProceedingJoinPoint proceedingJoinPoint) throws Throwable;

    /**
     * Logs following data on INFO level about executing method -
     *
     * <ul>
     *   <li>Method name
     *   <li>Method argument name-value pair
     *   <li>Request details including referrer, HTTP method, URI and username
     * </ul>
     *
     * @param proceedingJoinPoint  the joinpoint object representing the target method
     * @param methodRequestMapping the method request mapping
     */
    void logPreExecutionData(
            @Nonnull ProceedingJoinPoint proceedingJoinPoint,
            @Nullable RequestMapping methodRequestMapping);

    /**
     * Logs following data on INFO level about executed method -
     *
     * <ul>
     *   <li>Execution time of method in milliseconds
     * </ul>
     * <p>
     * Logs following data on DEBUG level about executed method -
     *
     * <ul>
     *   <li>JSON representation of object returned by method
     * </ul>
     *
     * @param proceedingJoinPoint  the jointpoint denoting the executed method
     * @param timer                {@link StopWatch} object containing execution time of method
     * @param result               the object returned by executed method
     * @param returnType           class name of object returned by executed method
     * @param methodRequestMapping the method request mapping
     * @param classRequestMapping  the class request mapping
     */
    void logPostExecutionData(
            @Nonnull ProceedingJoinPoint proceedingJoinPoint,
            @Nonnull StopWatch timer,
            @Nullable Object result,
            @Nonnull String returnType,
            @Nullable RequestMapping methodRequestMapping,
            @Nullable RequestMapping classRequestMapping);

    /**
     * Logs any exception thrown by method. This aspect is executed <b>AFTER</b> the exception has
     * been thrown, so one cannot swallow it over here.
     *
     * @param joinPoint the join point
     * @param t         the t
     */
    void onException(@Nonnull JoinPoint joinPoint, @Nonnull Throwable t);

    /**
     * Converts given object to its JSON representation via {@link JsonUtils}. The serialized JSON to
     * then appended to passed {@link StringBuilder} instance.
     *
     * <p>Some exceptional cases -
     *
     * <ol>
     *   <li>For objects of file type the file size in bytes is printed.
     *   <li>Mocked objects are not serialized. Instead a message is printed indicating that the
     *       object is a mocked object. Mocked objects are detected by presence of 'mock' substring in
     *       their class name.
     * </ol>
     *
     * @param object       the object to serialize
     * @param objClassName object's class name.
     * @param logMessage   {@link StringBuilder} instance to append serialized JSON.
     */
    void serialize(
            @Nullable Object object, @Nonnull String objClassName, @Nonnull StringBuilder logMessage);
}
