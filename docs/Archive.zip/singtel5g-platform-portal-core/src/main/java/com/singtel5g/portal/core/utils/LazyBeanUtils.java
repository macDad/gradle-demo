package com.singtel5g.portal.core.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.beanutils.PropertyUtils;

import java.lang.reflect.InvocationTargetException;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 14/7/2020<br>
 * Description:
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class LazyBeanUtils {

    /**
     * Copy the all properties from source object and create and paste into destination object.
     *
     * @param clazz  class of destination object.
     * @param source source object where destination object gets the property value
     * @return the object
     *
     * @throws IllegalAccessException    the illegal access exception
     * @throws InstantiationException    the instantiation exception
     * @throws InvocationTargetException the invocation target exception
     * @throws NoSuchMethodException     the no such method exception
     */
    public static Object copyBean(final Class<?> clazz, final Object source)
            throws IllegalAccessException, InstantiationException, InvocationTargetException,
                   NoSuchMethodException {

        Object destination = null;
        destination = clazz.getDeclaredConstructor().newInstance();
        PropertyUtils.copyProperties(destination, source);
        return destination;
    }

    /**
     * Copy the all properties from source object and create and paste into destination object..
     *
     * @param destination the destination
     * @param source      the source
     * @return the object
     *
     * @throws IllegalAccessException    the illegal access exception
     * @throws NoSuchMethodException     the no such method exception
     * @throws InvocationTargetException the invocation target exception
     */
    public static Object copyBean(Object destination, final Object source)
            throws IllegalAccessException, NoSuchMethodException, InvocationTargetException {

        PropertyUtils.copyProperties(destination, source);
        return destination;
    }
}
