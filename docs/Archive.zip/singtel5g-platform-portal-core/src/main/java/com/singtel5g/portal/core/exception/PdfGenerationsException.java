package com.singtel5g.portal.core.exception;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 28/6/2020<br>
 * Description: {@code PdfGenerationsException} is responsible for resolving a source exception to a
 * PDF Generation exception.
 */
public class PdfGenerationsException extends SystemException {

    /**
     * Instantiates a new Pdf generations exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public PdfGenerationsException(String errorContext, ErrorCodes errorCode, String errorMessage) {
        super(errorContext, errorCode, errorMessage);
    }

    /**
     * Instantiates a new Pdf generations exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @param cause        the cause
     */
    public PdfGenerationsException(
            String errorContext, ErrorCodes errorCode, String errorMessage, Throwable cause) {
        super(errorContext, errorCode, errorMessage, cause);
    }
}
