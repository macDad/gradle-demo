package com.singtel5g.portal.core.exception;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description: Description: {@code ValidationException} is responsible for resolving a source
 * exception to a Validation Exception.
 */
public class ValidationException extends SystemException {

    /**
     * Instantiates a new Validation exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public ValidationException(String errorContext, ErrorCodes errorCode, String errorMessage) {
        super(errorContext, errorCode, errorMessage);
    }

    /**
     * Instantiates a new Validation exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @param cause        the cause
     */
    public ValidationException(
            String errorContext, ErrorCodes errorCode, String errorMessage, Throwable cause) {
        super(errorContext, errorCode, errorMessage, cause);
    }
}
