package com.singtel5g.portal.core.utils;

import java.util.concurrent.TimeUnit;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description:
 */
public class TimerUtils {
    private final long startTime;

    /**
     * Instantiates a new Timer util.
     */
    public TimerUtils() {
        startTime = System.nanoTime();
    }

    /**
     * Gets elapsed time ms.
     *
     * @return the elapsed time ms
     */
    public long getElapsedTimeMS() {
        return TimeUnit.MILLISECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS);
    }

    /**
     * Gets elapsed time s.
     *
     * @return the elapsed time s
     */
    public long getElapsedTimeS() {
        return TimeUnit.SECONDS.convert(System.nanoTime() - startTime, TimeUnit.NANOSECONDS);
    }
}
