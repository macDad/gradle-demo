package com.singtel5g.portal.core.exception;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 28/6/2020<br>
 * Description: Description: {@code NetworkUnreachableException} is responsible for resolving a
 * source exception to a Network Unreachable Exception.
 */
public class NetworkUnreachableException extends SystemException {
    /**
     * Instantiates a new Network unreachable exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public NetworkUnreachableException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        super(errorContext, errorCode, errorMessage);
    }

    /**
     * Instantiates a new Network unreachable exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @param cause        the cause
     */
    public NetworkUnreachableException(
            String errorContext, ErrorCodes errorCode, String errorMessage, Throwable cause) {
        super(errorContext, errorCode, errorMessage, cause);
    }
}
