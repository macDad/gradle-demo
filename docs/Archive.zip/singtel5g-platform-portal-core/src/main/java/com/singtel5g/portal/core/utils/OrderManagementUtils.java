package com.singtel5g.portal.core.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 6/7/2020<br>
 * Description:Global factory that can be used to create new {@code OrderManagementUtils}
 * configurations using * {@code OrderManagementUtils.generateOrderId()}. *
 *
 * <p>Usage: *
 *
 * <pre>
 *  *
 *  *      var orderId = OrderManagementUtils.generateOrderId();
 *  *      //output : sin5gom_200706160632000
 *  *      var orderId = OrderManagementUtils.generateOrderId("TESTCODE");
 *  *       //output : TESTCODE200706160632001
 *  *      var orderId = OrderManagementUtils.generateUniqueLongId();
 *  *       //output : 200706160632002
 *  * </pre>
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class OrderManagementUtils {
    /**
     * The constant ORDER_CODE_PREFIX.
     */
    public static final String ORDER_CODE_PREFIX = "SIN5G";
    /**
     * The constant DATE_TIME_FORMAT.
     */
    private static final String DATE_TIME_FORMAT = "yyMMddkkmmss";
    /**
     * The constant SEQUENCE_MAX.
     */
    private static final long SEQUENCE_MAX = 1000;
    /**
     * The constant FORMAT.
     */
    private static final String FORMAT = "%03d";
    /**
     * The constant lastTimeStamp.
     */
    private static volatile long lastTimeStamp = -1L;

    /**
     * The constant sequence.
     */
    private static volatile long sequence = 0L;

    /**
     * Generate Order id string.
     *
     * @return the string
     */
    public static String generateOrderId() {
        return generateOrderId(ORDER_CODE_PREFIX, "ORD");
    }

    /**
     * Generate Order id string.
     *
     * @param orderCodePrefix  the order code prefix
     * @param vendorCodePrefix the vendor code prefix
     * @return the string
     */
    public static String generateOrderId(String orderCodePrefix, String vendorCodePrefix) {
        var randomString = StringUtils.getAlphaNumericString(4).toUpperCase();
        return String.format(
                "%s%s-%s%s", orderCodePrefix, vendorCodePrefix, randomString, generateUniqueLongId());
    }

    /**
     * Generate long id string.
     *
     * @return the string
     */
    public static synchronized String generateUniqueLongId() {
        long timestamp = getCurrentDateTime();
        if (lastTimeStamp == timestamp) {
            sequence = (sequence + 1) % SEQUENCE_MAX;
            if (sequence == 0) {
                timestamp = tilNextMillis(lastTimeStamp);
            }
        } else {
            sequence = 0;
        }
        lastTimeStamp = timestamp;
        return timestamp + String.format(FORMAT, sequence);
    }

    /**
     * Gets current date time.
     *
     * @return the current date time
     */
    private static long getCurrentDateTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        LocalDateTime localDateTime = LocalDateTime.now();
        String ldtString = formatter.format(localDateTime);
        return Long.valueOf(Optional.ofNullable(ldtString).orElseGet(() -> "1"));
    }

    /**
     * Til next millis long.
     *
     * @param lastTimestamp the last timestamp
     * @return the long
     */
    private static long tilNextMillis(long lastTimestamp) {
        long timestamp = getCurrentDateTime();
        while (timestamp <= lastTimestamp) {
            timestamp = getCurrentDateTime();
        }
        return timestamp;
    }

    /**
     * Generate order id string.
     *
     * @param vendorCode the vendor code
     * @return the string
     */
    public static String generateOrderId(String vendorCode) {
        return generateOrderId(ORDER_CODE_PREFIX, vendorCode);
    }

    /**
     * Generate flow one order id string.
     *
     * @return the string
     */
    public static String generateFlowOneOrderId() {
        return generateOrderId(ORDER_CODE_PREFIX, "FO");
    }

    /**
     * Generate mec order id string.
     *
     * @return the string
     */
    public static String generateMECOrderId() {
        return generateOrderId(ORDER_CODE_PREFIX, "MEC");
    }
}
