package com.singtel5g.portal.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Create by: yongsheng.kng@Singtel
 *
 * <p>Date: 16/6/2021<br>
 * Description: {@code NaaSOrderStatus} is use to manage NaaS order status maintains within
 * API params, DB params and status Mappings *
 *
 * <p>This enum need toxxxx be use with GenericBusinessFunction * *
 *
 * <p>usage Examples: * *
 *
 * <pre>
 *  *  NaaSOrderStatus naasOrderStatus = NaaSOrderStatus.PLANNED;
 *  *    naasOrderStatus.getDbCode()          //IN_PROGRESS
 *  *    naasOrderStatus.getDbValue()         //0
 *  *    naasOrderStatus.getNaasCode()     //PLANNED
 *  *    naasOrderStatus.getNaasValue()    //2
 *  *    naasOrderStatus.getJsonValue()       //In Progress
 *  *  </pre>
 */
@Getter
@AllArgsConstructor
public enum NaaSOrderStatus {
    /**
     * Initiated NaaS order status.
     */

    INITIATED("PLANNED", 1, Constants.INITIATED, 3, Constants.INITIATED_JSON_VALUE),
    /**
     * Planned NaaS order status.
     */
    PLANNED("PLANNED", 2, Constants.IN_PROGRESS, 0, Constants.IN_PROGRESS_JSON_VALUE),
    /**
     * Started NaaS order status.
     */
    STARTED("STARTED", 3, Constants.IN_PROGRESS, 0, Constants.IN_PROGRESS_JSON_VALUE),
    /**
     * In progress NaaS order status.
     */
    IN_PROGRESS("STARTED", 0, Constants.IN_PROGRESS, 0, Constants.IN_PROGRESS_JSON_VALUE),
    /**
     * Cancelled NaaS order status.
     */
    CANCELLED("CANCELLED", 6, Constants.FAILED, 2, Constants.FAILED_JSON_VALUE),
    /**
     * Failed NaaS order status.
     */
    FAILED(Constants.FAILED, 8, Constants.FAILED, 2, Constants.FAILED_JSON_VALUE),
    /**
     * Completed NaaS order status.
     */
    COMPLETED(Constants.COMPLETED, 9, Constants.COMPLETED, 1, Constants.COMPLETED_JSON_VALUE),
    /**
     * Cancelling NaaS order status.
     */
    CANCELLING("CANCELLING", 10, Constants.FAILED, 2, Constants.FAILED_JSON_VALUE),
    /**
     * Unknown NaaS order status.
     */
    UNKNOWN("UNKNOWN", 11, Constants.FAILED, 2, Constants.FAILED_JSON_VALUE),
    /**
     * Error NaaS order status.
     */
    ERROR("ERROR", 12, Constants.ERROR, 2, Constants.ERROR_JSON_VALUE);

    private final String naasCode;
    private final int naasValue;
    private final String dbCode;
    private final int dbValue;
    private final String jsonValue;

    /**
     * The type Constants.
     */
    private static class Constants {

        /**
         * The constant INITIATED.
         */
        public static final String INITIATED = "INITIATED";

        /**
         * The constant IN_PROGRESS.
         */
        public static final String IN_PROGRESS = "IN_PROGRESS";

        /**
         * The constant FAILED.
         */
        public static final String FAILED = "FAILED";

        /**
         * The constant COMPLETED.
         */
        public static final String COMPLETED = "COMPLETED";

        /**
         * The constant ERROR.
         */
        public static final String ERROR = "ERROR";

        /**
         * The constant INITIATED_JSON_VALUE.
         */
        public static final String INITIATED_JSON_VALUE = "INITIATED";

        /**
         * The constant IN_PROGRESS_JSON_VALUE.
         */
        public static final String IN_PROGRESS_JSON_VALUE = "In Progress";

        /**
         * The constant FAILED_JSON_VALUE.
         */
        public static final String FAILED_JSON_VALUE = "Failed";

        /**
         * The constant COMPLETED_JSON_VALUE.
         */
        public static final String COMPLETED_JSON_VALUE = "Completed";

        /**
         * The constant ERROR_JSON_VALUE.
         */
        public static final String ERROR_JSON_VALUE = "ERROR";
    }
}
