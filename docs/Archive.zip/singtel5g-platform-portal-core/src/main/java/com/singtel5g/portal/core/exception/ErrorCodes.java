package com.singtel5g.portal.core.exception;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description:
 */
public enum ErrorCodes {
    /**
     * Validation parse error error codes.
     */
    PORTAL_GENERIC_ERROR(420),
    /**
     * Api generic error error codes.
     */
    API_GENERIC_ERROR(421),
    /**
     * Validation generic error error codes.
     */
    VALIDATION_GENERIC_ERROR(422),
    /**
     * Database generic error error codes.
     */
    DATABASE_GENERIC_ERROR(423),
    /**
     * Validation parse error error codes.
     */
    VALIDATION_PARSE_ERROR(424);

    private final int code;

    ErrorCodes(int code) {
        this.code = code;
    }

    /**
     * Gets code.
     *
     * @return the code
     */
    public int getCode() {
        return code;
    }
}
