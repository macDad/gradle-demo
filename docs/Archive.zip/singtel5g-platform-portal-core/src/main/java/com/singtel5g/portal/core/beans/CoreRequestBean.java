// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.core.beans;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 15/9/2020<br>
 * project : 5g-platform-portal-core-modules<br>
 * since : version 1.0<br>
 * Description: <br>
 */
@Data
@NoArgsConstructor
public abstract class CoreRequestBean {
    /**
     * The Context.
     */
    private final Map<String, String> context = new LinkedHashMap<>(4);

    /**
     * Instantiates a new Request context.
     *
     * @param context the context
     */
    public CoreRequestBean(@Nonnull Map<String, String> context) {
        Objects.requireNonNull(context)
                .forEach((key, value) -> this.context.put(key, value != null ? value : "null"));
    }

    /**
     * Add request context.
     *
     * @param key   the key
     * @param value the value
     * @return the request context
     */
    public CoreRequestBean addContext(@Nonnull String key, @Nullable String value) {
        context.put(key, value != null ? value : "null");
        return this;
    }

    /**
     * Review context string.
     *
     * @param key the key
     * @return the string
     */
    public String reviewContext(@Nonnull String key) {
        return context.get(key);
    }
}
