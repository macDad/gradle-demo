package com.singtel5g.portal.core.exception;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 28/6/2020<br>
 * Description: Description: {@code ResourceNotAvailableException} is responsible for resolving a
 * source exception to a Resource Not Available Exception.
 */
public class ResourceNotAvailableException extends SystemException {
    /**
     * Instantiates a new Resource not available exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public ResourceNotAvailableException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        super(errorContext, errorCode, errorMessage);
    }

    /**
     * Instantiates a new Resource not available exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @param cause        the cause
     */
    public ResourceNotAvailableException(
            String errorContext, ErrorCodes errorCode, String errorMessage, Throwable cause) {
        super(errorContext, errorCode, errorMessage, cause);
    }
}
