package com.singtel5g.portal.core.beans;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 29/8/2020<br>
 * Description:
 */
@ToString
@Builder
@EqualsAndHashCode
@NoArgsConstructor
public class RequestContext {
    private final Map<String, String> context = new LinkedHashMap<>(4);

    /**
     * Instantiates a new Request context.
     *
     * @param context the context
     */
    public RequestContext(@Nonnull Map<String, String> context) {
        Objects.requireNonNull(context)
                .forEach((key, value) -> this.context.put(key, value != null ? value : "null"));
    }

    /**
     * Add request context.
     *
     * @param key   the key
     * @param value the value
     * @return the request context
     */
    public RequestContext add(@Nonnull String key, @Nullable String value) {
        context.put(key, value != null ? value : "null");
        return this;
    }
}
