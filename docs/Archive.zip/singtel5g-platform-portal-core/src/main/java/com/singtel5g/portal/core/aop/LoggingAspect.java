package com.singtel5g.portal.core.aop;

import com.singtel5g.portal.core.utils.JsonUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.core.utils.RequestUtils;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;
import com.singtel5g.portal.security.component.AuthCheck;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.StopWatch;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.lang.annotation.Annotation;
import java.util.Arrays;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 28/8/2020<br>
 * Description:
 */
// @formatter:on

/**
 * This class is responsible for performing logging on Controller methods. It used Spring AspectJ
 * (not native Spring CGLib AOP) for weaving logging logic into matching controller methods.
 *
 * <p>This aspect uses two annotations - {@link com.singtel5g.portal.core.annotation.LogEnabled} and
 * {@link com.singtel5g.portal.core.annotation.LogDisabled} to gain fine-grain control over method
 * logging behavior.
 *
 * @see <a
 * href="http://docs.spring.io/spring/docs/current/spring-framework-reference/html/aop.html">
 * Spring Documentation on Aspect Oriented Programming with Spring </a>
 */
// @formatter:off
@Slf4j
@Aspect
public class LoggingAspect extends AbstractLogAdapter implements LogAdapter {

    private static final String portal = ".portal.";
    private static final String controller = ".controller.";


    @Nonnull
    private final JsonUtils jsonUtils;

    @Nonnull
    private final RequestUtils requestUtils;

    @Autowired
    AuthCheck authCheck;

    /**
     * Instantiates a new Logging aspect.
     */
    public LoggingAspect() {
        this(new JsonUtils(), new RequestUtils());
    }

    /**
     * Instantiates a new Logging aspect.
     *
     * @param jsonUtils    the json util
     * @param requestUtils the request util
     */
    public LoggingAspect(@Nonnull JsonUtils jsonUtils, @Nonnull RequestUtils requestUtils) {
        this.jsonUtils = jsonUtils;
        this.requestUtils = requestUtils;
    }

    /**
     * This pointcut is for joinpoint corresponding to all public methods in controller
     */
    @Pointcut(
            "within(@org.springframework.web.bind.annotation.RestController *) ||"
                    + "within(@org.springframework.stereotype.Controller *)")
    @Override
    public void allPublicControllerMethodsPointcut() {
    }

    @Pointcut(
            "@annotation(com.singtel5g.portal.core.annotation.LogEnabled) "
                    + "|| @target(com.singtel5g.portal.core.annotation.LogEnabled)")
    @Override
    public void methodOrClassLoggingEnabledPointcut() {
    }

    @Pointcut("!@annotation(com.singtel5g.portal.core.annotation.LogDisabled)")
    @Override
    public void methodLoggingNotDisabledPointcut() {
    }

    @Around(
            "allPublicControllerMethodsPointcut() "
                    + "&& methodLoggingNotDisabledPointcut() "
                    + "&& methodOrClassLoggingEnabledPointcut()")
    @Nullable
    @Override
    public Object log(@Nonnull ProceedingJoinPoint proceedingJoinPoint) throws Throwable {
        Object result = null;
        String returnType = null;
        RequestMapping methodRequestMapping = null;
        RequestMapping classRequestMapping = null;
        setUserMDC();

        try {
            MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
            methodRequestMapping = methodSignature.getMethod().getAnnotation(RequestMapping.class);
            classRequestMapping =
                    proceedingJoinPoint.getTarget().getClass().getAnnotation(RequestMapping.class);

            returnType = methodSignature.getReturnType().getName();

            logPreExecutionData(proceedingJoinPoint, methodRequestMapping);
        } catch (Exception e) {
            log.error("Exception occurred in pre-proceed logic", e);
        }

        StopWatch timer = new StopWatch();
        try {
            timer.start();
            result = proceedingJoinPoint.proceed();
        } finally {
            timer.stop();
            if (returnType != null)
                logPostExecutionData(
                        proceedingJoinPoint,
                        timer,
                        result,
                        returnType,
                        methodRequestMapping,
                        classRequestMapping);
        }

        return result;
    }

    /**
     * Logs following data on INFO level about executing method -
     *
     * <ul>
     *   <li>Method name
     *   <li>Method argument name-value pair
     *   <li>Request details including referrer, HTTP method, URI and username
     * </ul>
     *
     * @param proceedingJoinPoint  the joinpoint object representing the target method
     * @param methodRequestMapping
     */
    @Override
    public void logPreExecutionData(
            @Nonnull ProceedingJoinPoint proceedingJoinPoint,
            @Nullable RequestMapping methodRequestMapping) {
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
        String className = methodSignature.getDeclaringTypeName();
        String methodName = String.format("%s()", methodSignature.getName());

        Object[] argValues = proceedingJoinPoint.getArgs();
        String[] argNames = methodSignature.getParameterNames();
        String requestContext = requestUtils.getRequestContext().toString();
        Annotation[][] annotations = methodSignature.getMethod().getParameterAnnotations();

        StringBuilder preMessage = new StringBuilder();
        setModuleActionType(preMessage, className, methodSignature.getName(), "request");

        preMessage.append(className).append(".").append(methodName);

        if (argValues.length > 0)
            logFunctionArguments(argNames, argValues, preMessage, annotations, methodRequestMapping);

        preMessage.append(" called via ").append(requestContext);
        log.info(preMessage.toString());
    }

    /**
     * Logs following data on INFO level about executed method -
     *
     * <ul>
     *   <li>Execution time of method in milliseconds
     * </ul>
     *
     * <p>Logs following data on DEBUG level about executed method -
     *
     * <ul>
     *   <li>JSON representation of object returned by method
     * </ul>
     *
     * @param proceedingJoinPoint  the jointpoint denoting the executed method
     * @param timer                {@link StopWatch} object containing execution time of method
     * @param result               the object returned by executed method
     * @param returnType           class name of object returned by executed method
     * @param methodRequestMapping
     * @param classRequestMapping
     */
    @Override
    public void logPostExecutionData(
            @Nonnull ProceedingJoinPoint proceedingJoinPoint,
            @Nonnull StopWatch timer,
            @Nullable Object result,
            @Nonnull String returnType,
            @Nullable RequestMapping methodRequestMapping,
            @Nullable RequestMapping classRequestMapping) {
        MethodSignature methodSignature = (MethodSignature) proceedingJoinPoint.getSignature();
        String className = methodSignature.getDeclaringTypeName();
        String methodName = methodSignature.getName() + "()";
        StringBuilder stringBuilder = new StringBuilder();
        setModuleActionType(stringBuilder, className, methodSignature.getName(), "time");

        log.info(
                String.format(stringBuilder.toString() + "%s.%s took [%d ms] to complete", className, methodName,
                        timer.getTime()));

        boolean needsSerialization;

        String[] produces =
                methodRequestMapping != null ? methodRequestMapping.produces() : new String[0];
        needsSerialization =
                Arrays.stream(produces)
                        .anyMatch(produce -> produce.equals(MediaType.APPLICATION_JSON_VALUE));

        if (!needsSerialization) {
            produces = classRequestMapping != null ? classRequestMapping.produces() : new String[0];
            if (Arrays.stream(produces)
                    .anyMatch(produce -> produce.equals(MediaType.APPLICATION_JSON_VALUE)))
                needsSerialization = true;
        }

        StringBuilder postMessage = new StringBuilder();
        setModuleActionType(postMessage, className, methodSignature.getName(), "response");
        postMessage.append(className).append(".").append(methodName).append(" returned: [");

        if (needsSerialization) {
            String resultClassName = result == null ? "null" : result.getClass().getName();
            resultClassName = returnType.equals("java.lang.Void") ? returnType : resultClassName;
            serialize(result, resultClassName, postMessage);
        } else {
            postMessage.append(result);
        }
        postMessage.append("]");
        log.info(postMessage.toString());
    }

    /**
     * Logs any exception thrown by method. This aspect is executed <b>AFTER</b> the exception has
     * been thrown, so one cannot swallow it over here.
     *
     * @param joinPoint
     * @param e
     */
    @AfterThrowing(
            pointcut =
                    "allPublicControllerMethodsPointcut() && "
                            + "methodLoggingNotDisabledPointcut() && "
                            + "methodOrClassLoggingEnabledPointcut()",
            throwing = "e")
    @Override
    public void onException(@Nonnull JoinPoint joinPoint, @Nonnull Throwable e) {
        String className = joinPoint.getSignature().getDeclaringTypeName();
        String methodName = joinPoint.getSignature().getName();
        StringBuilder stringBuilder = new StringBuilder();
        setModuleActionType(stringBuilder, className, methodName, "exception");
        log.error(stringBuilder.toString() + "{}.{}() threw exception: {} ", className, methodName, e.getCause(), e);
    }

    /**
     * Converts given object to its JSON representation via {@link JsonUtils}. The serialized JSON to
     * then appended to passed {@link StringBuilder} instance.
     *
     * <p>Some exceptional cases -
     *
     * <ol>
     *   <li>For objects of file type the file size in bytes is printed.
     *   <li>Mocked objects are not serialized. Instead a message is printed indicating that the
     *       object is a mocked object. Mocked objects are detected by presence of 'mock' substring in
     *       their class name.
     * </ol>
     *
     * @param object       the object to serialize
     * @param objClassName object's class name.
     * @param logMessage   {@link StringBuilder} instance to append serialized JSON.
     */
    @Override
    public void serialize(
            @Nullable Object object, @Nonnull String objClassName, @Nonnull StringBuilder logMessage) {
        boolean serializedSuccessfully = false;
        Exception exception = null;

        // this is to distinguish between methods returning null value and methods returning void.
        // Object arg is null in both cases but objClassName is not.
        if (objClassName.equals("java.lang.Void")) {
            logMessage.append("void");
            serializedSuccessfully = true;
        }

        // try serializing assuming a perfectly serializable object.
        if (!serializedSuccessfully) {
            try {
                logMessage.append(jsonUtils.toJson(object));
                serializedSuccessfully = true;
            } catch (Exception e) {
                exception = e;
            }
        }

        // try getting file size assuming object is a file type object
        if (!serializedSuccessfully) {
            long fileSize = -1;

            if (object instanceof ByteArrayResource) {
                fileSize = ((ByteArrayResource) object).contentLength();
            } else if (object instanceof MultipartFile) {
                fileSize = ((MultipartFile) object).getSize();
            }

            if (fileSize != -1) {
                logMessage.append("file of size:[").append(fileSize).append(" B]");
                serializedSuccessfully = true;
            }
        }

        // detect if its a mock object.
        if (!serializedSuccessfully && objClassName.toLowerCase().contains("mock")) {
            logMessage.append("Mock Object");
            serializedSuccessfully = true;
        }

        if (!serializedSuccessfully) {
            StringBuilder stringBuilder = new StringBuilder();
            setModuleActionType(stringBuilder, objClassName, "serialize", "serialize");
            log.warn(stringBuilder.toString() + "Unable to serialize object of type [" + objClassName + "] for logging",
                    exception);
        }
    }

    /**
     * Append action and type to log event
     *
     * @param stringBuilder reference
     * @param className
     * @param action
     * @param type
     */
    private void setModuleActionType(StringBuilder stringBuilder, String className, String action, String type) {

        String service = "";
        int indexFirst = className.indexOf(portal) + portal.length();
        int indexLast = className.indexOf(controller);

        if (indexFirst > 0 && indexLast > 0 && indexLast > indexFirst) {
            service = className.substring(indexFirst, indexLast);
        }
        stringBuilder.append("[service:").append(service).append("]");
        stringBuilder.append("[action:").append(action).append("]");
        stringBuilder.append("[type:").append(type).append("]:");
    }

    /**
     * Generated name-value pair of method's formal arguments. Appends the generated string in
     * provided StringBuilder
     *
     * @param argNames      String[] containing method's formal argument names Order of names must
     *                      correspond to order on arg values in argValues.
     * @param argValues     String[] containing method's formal argument values. Order of values must
     *                      correspond to order on arg names in argNames.
     * @param stringBuilder the StringBuilder to append argument data to.
     */
    private void logFunctionArguments(
            @Nonnull String[] argNames,
            @Nonnull Object[] argValues,
            @Nonnull StringBuilder stringBuilder,
            @Nonnull Annotation[][] annotations,
            @Nullable RequestMapping methodRequestMapping) {
        boolean someArgNeedsSerialization = false;

        if (methodRequestMapping != null)
            someArgNeedsSerialization =
                    Arrays.stream(methodRequestMapping.consumes())
                            .anyMatch(consumes -> consumes.equals(MediaType.APPLICATION_JSON_VALUE));

        stringBuilder.append(" called with arguments: ");

        for (int i = 0, length = argNames.length; i < length; ++i) {
            boolean needsSerialization = false;

            if (argValues[i] instanceof ByteArrayResource || argValues[i] instanceof MultipartFile)
                needsSerialization = true;
            else
                // We only need to serialize a param if @RequestBody annotation is found.
                if (someArgNeedsSerialization)
                    needsSerialization = Arrays.stream(annotations[i]).anyMatch(RequestBody.class::isInstance);

            stringBuilder.append(argNames[i]).append(": [");
            if (needsSerialization) {
                String argClassName = argValues[i] == null ? "NULL" : argValues[i].getClass().getName();
                serialize(argValues[i], argClassName, stringBuilder);
            } else {
                Object filteredValue = getScrubbedValue(argValues[i].toString(), argValues[i]);
                stringBuilder.append(getScrubbedValue(argNames[i], filteredValue));
            }
            stringBuilder.append("]").append(i == (length - 1) ? "" : ", ");
        }
    }

    /**
     * Returns scrubbed value for a given arg name-value. The original arg value is returned if data
     * scrubbing is disabled.
     *
     * @param argName  formal parameter name
     * @param argValue the parameter value
     * @return scrubbed value of argValue, or original value if data scrubbing is disabled
     */
    private Object getScrubbedValue(@Nonnull String argName, @Nullable Object argValue) {
        Object argValueToUse = argValue;

        if (enableDataScrubbing
                && (paramBlacklist.contains(argName.toLowerCase())
                || (paramBlacklistRegex != null && paramBlacklistRegex.matcher(argName).matches())
                || paramBlacklist.stream().anyMatch(str -> argName.toLowerCase().indexOf(str) > 0)))
            argValueToUse = scrubbedValue;

        return argValueToUse;
    }


    /**
     * Set [Organization][Department][User] by MDC
     */
    private void setUserMDC() {

        StringBuilder stringBuilder = new StringBuilder();
        String organizationCode = "";
        String departmentCode = "";
        String userName = "";
        try {
            String xUserHeader = requestUtils.getRequestUserHeader();
            if (!ObjectUtils.isNullOrEmpty(xUserHeader)) {

               PrivilegesResponse privilegesResponse = authCheck.retrieveUserDetailsByToken(xUserHeader);

               organizationCode = privilegesResponse.getOrganizationCode();
                departmentCode = privilegesResponse.getDepartmentCode();
               userName = privilegesResponse.getUsername();
            }
        } catch (Exception e) {
            log.error("Exception occurred in retrieve user details ", e);
        } finally {
            stringBuilder.append("[organizationCode:").append(organizationCode).append("]");
            stringBuilder.append("[departmentCode:").append(departmentCode).append("]");
            stringBuilder.append("[userName:").append(userName).append("]");
        }

        MDC.put("mdc_key", stringBuilder.toString());
    }
}
