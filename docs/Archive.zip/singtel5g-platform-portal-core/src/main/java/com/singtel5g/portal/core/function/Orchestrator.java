package com.singtel5g.portal.core.function;

import com.singtel5g.portal.core.exception.SystemException;
import com.singtel5g.portal.core.exception.ValidationException;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.core.utils.ObjectUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import java.util.ArrayList;
import java.util.List;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description:class {@code Orchestrator} use for executing a chain of functions and <br>
 * handle Errors, exemptions, and Transaction rollback according to the given parameters...
 *
 * <p>This class need to be use with GenericBusinessFunction
 *
 * <p>usage Examples:
 *
 * <pre>
 * GenericBusinessFunction[] func = {
 *    () -> validator.validateCurrencyCode(from),
 *    () -> validator.validateCurrencyCode(to),
 *    () -> validator.validateQuantity(quantity)
 * };
 *  Orchestrator.execute("Convert Currency", TransactionType.NOT, ErrorHandlingType.GROUP, func);
 *  </pre>
 */
@Component
@Slf4j
public class Orchestrator {
    private Orchestrator() {
    }

    /**
     * Support GROUP mode without transaction control only If group1 fail, then the gourp2 is not
     * executed; But all functions in the one group can be executed once.
     *
     * @param serviceName the service name
     * @param funcGroup   the func group
     */
    public static final void executeGroup(
            String serviceName, List<GenericServiceFunction[]> funcGroup) {
        if (!ObjectUtils.isNullOrEmpty(funcGroup)) {
            List<SystemException> lst = new ArrayList<>();
            for (GenericServiceFunction[] func : funcGroup) {
                try {
                    execute(serviceName, func);
                } catch (SystemException ex) {
                    log.error(ex.toString());
                    lst.add(ex);
                    break;
                }
            }
            if (!ObjectUtils.isNullOrEmpty(lst)) {
                ExceptionUtils.newMulSysEx(lst);
            }
        }
    }

    /**
     * Execute functions and handle errors and exceptions <strong><u>but not handling
     * Transaction</u>.</strong>
     *
     * @param serviceName the service name
     * @param funcs       the funcs
     * @throws SystemException the system exception
     */
    public static final void execute(String serviceName, GenericServiceFunction... funcs)
            throws SystemException {
        execute(serviceName, TransactionType.NOT, ErrorHandlingType.GROUP, funcs);
    }

    /**
     * Execute functions and handle errors and exceptions.
     *
     * @param serviceName the service name
     * @param tranType    the tran type
     * @param errType     the err type
     * @param funcs       the funcs
     * @throws SystemException the system exception
     */
    public static final void execute(
            String serviceName,
            TransactionType tranType,
            ErrorHandlingType errType,
            GenericServiceFunction... funcs)
            throws SystemException {
        if (tranType == null) {
            tranType = TransactionType.NOT;
        }
        if (errType == null) {
            errType = ErrorHandlingType.GROUP;
        }
        if (!ObjectUtils.isNullOrEmpty(funcs)) {
            try {
                List<SystemException> lst = new ArrayList<>();
                for (GenericServiceFunction func : funcs) {
                    if (errType.isGroup()) {
                        try {
                            func.apply();
                        } catch (ValidationException appEx) {
                            lst.add(appEx);
                        } catch (SystemException sysEx) {
                            lst.add(sysEx);
                        }
                    } else {
                        func.apply();
                    }
                }
                if (!ObjectUtils.isNullOrEmpty(lst)) {
                    try {
                        ExceptionUtils.newMulSysEx(lst);
                    } catch (Exception ex) {
                        log.error(ex.toString());
                        throw ex;
                    }
                }
            } catch (Exception ex) {
                if (tranType.isSupport()) {
                    TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
                }
                log.error(ex.toString());
                throw ex;
            }
        }
    }
}
