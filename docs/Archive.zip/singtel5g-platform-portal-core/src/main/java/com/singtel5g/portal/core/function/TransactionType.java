package com.singtel5g.portal.core.function;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description:
 */
public enum TransactionType {
    /**
     * Support transaction type.
     */
    SUPPORT("S"),
    /**
     * Not transaction type.
     */
    NOT("N");

    private final String type;

    TransactionType(String type) {
        this.type = type;
    }

    /**
     * Is support boolean.
     *
     * @return the boolean
     */
    public boolean isSupport() {
        return this.equals(SUPPORT);
    }

    /**
     * Is not boolean.
     *
     * @return the boolean
     */
    public boolean isNot() {
        return this.equals(NOT);
    }
}
