package com.singtel5g.portal.core.function;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description:
 */
public enum ErrorHandlingType {
    /**
     * Group error handling type.
     */
    GROUP("G"),
    /**
     * Single error handling type.
     */
    SINGLE("S");

    private final String type;

    ErrorHandlingType(String type) {
        this.type = type;
    }

    /**
     * Is group boolean.
     *
     * @return the boolean
     */
    public boolean isGroup() {
        return this.equals(GROUP);
    }

    /**
     * Is single boolean.
     *
     * @return the boolean
     */
    public boolean isSingle() {
        return this.equals(SINGLE);
    }
}
