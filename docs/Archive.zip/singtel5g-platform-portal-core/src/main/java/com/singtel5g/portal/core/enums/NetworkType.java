package com.singtel5g.portal.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 9/7/2020<br>
 * Description: {@code NetworkType} enum is use to manage deference types of networks within tha
 * application *
 *
 * <p>usage Examples: * *
 *
 * <pre>
 *  *  Vendor vendors = Vendor.SA;
 *  *    vendors.NetworkType()          //DNN
 *  *    vendors.getDbValue()             //0
 *  *    vendors.getJsonValue()           //DNN
 *  *  </pre>
 */
@Getter
@AllArgsConstructor
public enum NetworkType {
    /**
     * The Flow one.
     */
    SA("DNN", 0, "DNN"),
    /**
     * The Sky lab.
     */
    NSA("APN", 1, "APN"),
    /**
     * Both network types.
     */
    BOTH("BOTH", 2, "BOTH");
    private final String networkType;
    private final int dbValue;
    private final String jsonValue;
}
