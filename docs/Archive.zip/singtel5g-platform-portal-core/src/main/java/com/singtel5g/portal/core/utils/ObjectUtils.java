package com.singtel5g.portal.core.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description: Class {@code ObjectUtils} provides a series of common Object <br>
 * Utility APIs so that the handling associated with object <br>
 * can be simplified and reused in PCP <br>
 *
 * <p>All APIs are static method, without any object instance * required.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ObjectUtils {

    /**
     * Check whether an object is null or empty
     *
     * <p>It is cater for different type, including normal Object, Collection, Map, Set, String and
     * Array
     *
     * <p>Normal Object: check NULL
     *
     * <p>Collection, Map and Set: check NULL and Empty
     *
     * <p>Array: check NULL and length
     *
     * <p>String: check NULL and blank space which is same as StringUtils.isNullOrBlank
     *
     * <p>Example:
     *
     * <pre>
     * Object obj1 = null;
     * boolean result1 = ObjectUtils.isNullOrEmpty(obj1); //result1 = true
     *
     * List&lt;String&gt; obj2 = new ArrayList&lt;&gt;();
     * boolean result2 = ObjectUtils.isNullOrEmpty(obj2); //result2 = true
     *
     * Map&lt;String&gt;,&lt;String&gt; obj3 = ...; //There are 3 enties
     * boolean result3 = ObjectUtils.isNullOrEmpty(obj3); //result3 = false
     * </pre>
     *
     * @param obj Object
     * @return true if object is null or empty see
     * com.singtel5g.portal.core.utils.StringUtils#isNullOrBlank
     */
    public static final boolean isNullOrEmpty(Object obj) {
        if (obj == null) {
            return true;
        } else if (obj instanceof String) {
            String objStr = (String) obj;
            return objStr.trim().length() == 0;
        } else if (obj instanceof Collection) {
            Collection objCol = (Collection) obj;
            return objCol.isEmpty();
        } else if (obj instanceof Map) {
            Map objMap = (Map) obj;
            return objMap.isEmpty();
        } else if (obj.getClass().isArray()) {
            return Array.getLength(obj) == 0;
        } else {
            return false;
        }
    }
}
