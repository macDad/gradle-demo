package com.singtel5g.portal.core.beans;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 23/7/2020<br>
 * Description:
 */
@Slf4j
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ErrorObj {
    private String error;
    private String message;
    private Object detail;
}
