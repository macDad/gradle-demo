package com.singtel5g.portal.core.exception;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description:
 */
public interface ExceptionHandler {

    /**
     * Handle.
     *
     * @param contextCode the context code
     * @param errorCode   the error code
     * @param errorText   the error text
     * @param t           the t
     */
    void handle(String contextCode, ErrorCodes errorCode, String errorText, Throwable t);

    /**
     * Raise.
     *
     * @param contextCode the context code
     * @param errorCode   the error code
     * @param errorText   the error text
     */
    void raise(String contextCode, ErrorCodes errorCode, String errorText);

    /**
     * Handle.
     *
     * @param systemException SystemException
     */
    void handle(SystemException systemException);
}
