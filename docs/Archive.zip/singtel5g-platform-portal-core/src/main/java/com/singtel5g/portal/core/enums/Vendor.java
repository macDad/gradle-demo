package com.singtel5g.portal.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/7/2020<br>
 * Description: {@code Vendor} enum is use to manage Vendor within tha application *
 *
 * <p>usage Examples: * *
 *
 * <pre>
 *  *  Vendor vendors = Vendor.FLOW_ONE;
 *  *    vendors.getVendorCode()          //FLOW_ONE
 *  *    vendors.getDbValue()             //0
 *  *    vendors.getJsonValue()           //FLOW ONE
 *  *  </pre>
 */
@Getter
@AllArgsConstructor
public enum Vendor {
    /**
     * The Flow one.
     */
    @Deprecated
    FLOW_ONE("FLOW_ONE", 0, "FLOW ONE"),
    /**
     * The Sky lab.
     */
    SKY_LAB("SKY_LAB", 1, "SKY LAB"),
    /**
     * The NAAS.
     */
    NAAS("NAAS", 2, "NaaS"),
    /**
     * The Network Analytic.
     */
    NETWORK_ANALYTIC("NETWORK_ANALYTIC", 3, "NETWORK ANALYTIC"),
    /**
     * The Singtel Service Orchestration.
     */
    SO("SINGTEL_SERVICE_ORCHESTRATION", 4, "SINGTEL SERVICE ORCHESTRATION");

    private final String vendorCode;
    private final int dbValue;
    private final String jsonValue;
}
