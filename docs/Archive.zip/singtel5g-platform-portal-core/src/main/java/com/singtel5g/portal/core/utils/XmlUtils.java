package com.singtel5g.portal.core.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 13/7/2020<br>
 * Description:Global factory Util class for use to fetch element data from XML string {@code
 * XmlUtils}** configurations using {@code XmlUtils.getValueByTagNameFromXml(<String>, <String>)}.
 *
 * <p>Usage:
 *
 * <pre>
 *  *      List<String> output = XmlUtils.getValueByTagNameFromXml(results, "orderStatus");
 *  *       String[] strarray = new String[output.size()];
 *  *       output.toArray(strarray);
 *  *       log.info("Response Array is " + Arrays.toString(strarray));
 *  * </pre>
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class XmlUtils {

    /**
     * Gets value by tag name from xml.
     *
     * @param response the response
     * @param tagName  the tag name
     * @return the value by tag name from xml
     *
     * @throws IOException                  the io exception
     * @throws SAXException                 the sax exception
     * @throws ParserConfigurationException the parser configuration exception
     */
    public static List<String> getValueByTagNameFromXml(String response, String tagName)
            throws IOException, SAXException, ParserConfigurationException {
        Document xmlDoc = loadXMLString(response);
        NodeList nodeList = xmlDoc.getElementsByTagName(tagName);
        List<String> ids = new ArrayList<>(nodeList.getLength());
        IntStream.range(0, nodeList.getLength())
                .forEach(
                        i -> {
                            Node x = nodeList.item(i);
                            ids.add(x.getFirstChild().getNodeValue());
                            log.info(nodeList.item(i).getFirstChild().getNodeValue());
                        });
        return ids;
    }

    /**
     * Load xml string document.
     *
     * @param response the response
     * @return the document
     *
     * @throws ParserConfigurationException the parser configuration exception
     * @throws IOException                  the io exception
     * @throws SAXException                 the sax exception
     */
    public static Document loadXMLString(String response)
            throws ParserConfigurationException, IOException, SAXException {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
        dbf.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
        DocumentBuilder db = dbf.newDocumentBuilder();
        InputSource is = new InputSource(new StringReader(response));
        return db.parse(is);
    }
}
