package com.singtel5g.portal.core.utils;

import com.singtel5g.portal.core.beans.ErrorObj;
import com.singtel5g.portal.core.exception.*;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

import static java.util.Collections.singleton;
import static java.util.Collections.singletonList;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description:Class {@code ExceptionUtils} use for handle Exception Utility on the 5G platform
 * backend microservices.
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ExceptionUtils {
    /**
     * The constant exceptionHandler.
     */
    protected static ExceptionHandler exceptionHandler =
            new ExceptionHandler() {
                public void handle(
                        String errorContext, ErrorCodes errorCode, String errorText, Throwable t) {

                    if (!(t instanceof SystemException)) {
                        throw new SystemException(errorContext, errorCode, errorText, t);
                    } else {
                        ((SystemException) t).addInfo(errorContext, errorCode, errorText);
                    }
                }

                public void raise(String errorContext, ErrorCodes errorCode, String errorText) {
                    throw new SystemException(errorContext, errorCode, errorText);
                }

                @Override
                public void handle(SystemException p) {
                    if (!(p instanceof SystemException)) {
                        throw p;
                    }
                }
            };


    /**
     * New mul sys ex system exception.
     *
     * @param sysExLst the sys ex lst
     * @return the system exception
     */
    public static void newMulSysEx(List<SystemException> sysExLst) {
        if (!ObjectUtils.isNullOrEmpty(sysExLst)) {
            sysExLst.forEach(
                    p -> {
                        exceptionHandler.handle(p);
                        throw p;
                    });
        }
    }

    /**
     * Validation exception validation exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @return the validation exception
     */
    public static ValidationException newValidationException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        ValidationException appEx = new ValidationException(errorContext, errorCode, errorMessage);
        return appEx;
    }

    /**
     * Invalid service exception invalid service exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @return the invalid service exception
     */
    public static InvalidServiceException newInvalidServiceException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        InvalidServiceException appEx =
                new InvalidServiceException(errorContext, errorCode, errorMessage);
        return appEx;
    }

    /**
     * Invalid user state exception invalid user state exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @return the invalid user state exception
     */
    public static InvalidUserStateException newInvalidUserStateException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        InvalidUserStateException appEx =
                new InvalidUserStateException(errorContext, errorCode, errorMessage);
        return appEx;
    }

    /**
     * Network unreachable exception network unreachable exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @return the network unreachable exception
     */
    public static NetworkUnreachableException newNetworkUnreachableException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        NetworkUnreachableException appEx =
                new NetworkUnreachableException(errorContext, errorCode, errorMessage);
        return appEx;
    }

    /**
     * Resource not available exception resource not available exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @return the resource not available exception
     */
    public static ResourceNotAvailableException newResourceNotAvailableException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        ResourceNotAvailableException appEx =
                new ResourceNotAvailableException(errorContext, errorCode, errorMessage);
        return appEx;
    }

    /**
     * New pdf generations exception pdf generations exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @return the pdf generations exception
     */
    public static PdfGenerationsException newPdfGenerationsException(
            String errorContext, ErrorCodes errorCode, String errorMessage) {
        PdfGenerationsException appEx =
                new PdfGenerationsException(errorContext, errorCode, errorMessage);
        return appEx;
    }

    /**
     * Format exception message map.
     *
     * @param e the e
     * @return the map
     */
    public static Object formatExceptionMessage(Exception e) {
        try {
            final var randomString = new RandomStringUtils(4).nextString();
            final var randomId = OrderManagementUtils.generateOrderId("PBE", randomString);

            log.error(String.format("ErrorID : [%s]", randomId), e);
            return formatExceptionMessage(e, randomId);
        } catch (Exception ex) {
            List errors = new ArrayList();
            ErrorObj errorObj = new ErrorObj();
            errorObj.setError(e.getLocalizedMessage());
            List errorsMsgs = new ArrayList();
            errorObj.setDetail(errorsMsgs.add(e.getMessage()));
            errors.add(errorObj);
            return errors;
        }
    }

    /**
     * Format exception message map.
     *
     * @param errorMsg the error msg
     * @param randomId the random id
     * @return the map
     *
     * @throws Exception the exception
     */
    public static List formatExceptionMessage(String errorMsg, String randomId) {
        Map<String, List> map = new HashMap();
        List errors = new ArrayList();

        getList(errorMsg, map, errors);

        if (!StringUtils.isNullOrBlank(randomId)) {
            ErrorObj errorObj = new ErrorObj();
            errorObj.setError("ERROR_ID");
            errorObj.setDetail(singletonList(randomId));
            errors.add(errorObj);
        }
        return errors;
    }

    /**
     * Format exception message map.
     *
     * @param e the excecption
     * @param randomId the random id
     * @return the map
     *
     * @throws Exception the exception
     */
    public static List formatExceptionMessage(Exception e, String randomId) {
        Map<String, List> map = new HashMap();
        List errors = new ArrayList();

        if(e instanceof SystemException){
            getList(e.toString(), map, errors);
        }

        if (!StringUtils.isNullOrBlank(randomId)) {
            ErrorObj errorObj = new ErrorObj();
            errorObj.setError("Error");
            errorObj.setDetail(singletonList(formatExceptionMessageJiraFormat(randomId)));
            errors.add(errorObj);
        }
        return errors;
    }

    private static List getList(String errorMsg, Map<String, List> map, List errors) {
        if (StringUtils.isNullOrBlank(errorMsg)) return errors;

        List<String> myList = new ArrayList<>(Arrays.asList(errorMsg.replace("[", "#*,*# [").split("#\\*,\\*#")));
        for (String s : myList)
            if (!StringUtils.isNullOrBlank(s)) {
                var split = s.replace("]", "]#*,*#").split("#\\*,\\*#");
                var existing = map.get(split[0]);
                if (!ObjectUtils.isNullOrEmpty(split)
                        && split.length > 1
                        && !StringUtils.isNullOrBlank(split[1])
                        && !split[1].trim().isEmpty()) {
                    if (existing == null) existing = new ArrayList();
                    existing.add(split[1]);
                    map.put(split[0], existing);
                }
            }

        for (Map.Entry<String, List> entry : map.entrySet()) {
            ErrorObj errorObj = new ErrorObj();
            errorObj.setError(entry.getKey());
            errorObj.setDetail(entry.getValue());
            errors.add(errorObj);
        }
        return errors;
    }

    private static Object formatExceptionMessageJiraFormat(String randomId) {
        return new StringBuilder().append("An exception occurred in API. ")
                .append("Please contact the helpdesk or raise the JIRA ticket using key [")
                .append(randomId)
                .append("]")
                .toString();
    }

    /**
     * Format exception message map.
     *
     * @param errorMsg the error msg
     * @return the map
     *
     * @throws Exception the exception
     */
    public static List formatExceptionMessage(String errorMsg) {
        Map<String, List> map = new HashMap();
        List errors = new ArrayList();
        return getList(errorMsg, map, errors);
    }
}
