package com.singtel5g.portal.core.exception;

import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description: Global factory that can be used to create new {@code SystemException} configurations
 * using * {@code new SystemException()}. *
 *
 * <p>Usage: *
 *
 * <pre>
 *  *    throw new SystemException(errorContext, errorCode, errorText);
 *  *                                  // Create ExceptionTranslator from configuration
 *  * </pre>
 */
@Slf4j
public class SystemException extends RuntimeException implements Serializable {
    /**
     * The constant serialVersionUID.
     */
    public static final long serialVersionUID = -1;

    /**
     * The Info items.
     */
    protected List<InfoItem> infoItems = new ArrayList<InfoItem>();

    /**
     * Instantiates a new System exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public SystemException(String errorContext, ErrorCodes errorCode, String errorMessage) {

        addInfo(errorContext, errorCode, errorMessage);
    }

    /**
     * Add info system exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorText    the error text
     * @return the system exception
     */
    public SystemException addInfo(String errorContext, ErrorCodes errorCode, String errorText) {
        var infoItem = new InfoItem(errorContext, errorCode, errorText);
        this.infoItems.add(infoItem);
        log.error(infoItem.toString());
        return this;
    }

    /**
     * Instantiates a new System exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @param cause        the cause
     */
    public SystemException(
            String errorContext, ErrorCodes errorCode, String errorMessage, Throwable cause) {
        super(cause);
        addInfo(errorContext, errorCode, errorMessage);
    }

    /**
     * Gets code.
     *
     * @return the code
     */
    public String getCode() {
        StringBuilder builder = new StringBuilder();

        for (int i = this.infoItems.size() - 1; i >= 0; i--) {
            InfoItem info = this.infoItems.get(i);
            builder.append('[');
            builder.append(info.errorContext);
            builder.append(':');
            builder.append(info.errorCode.getCode());
            builder.append(']');
        }

        return builder.toString();
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();

        builder.append(getCode());
        builder.append('\n');

        // append additional context information.
        for (int i = this.infoItems.size() - 1; i >= 0; i--) {
            InfoItem info = this.infoItems.get(i);
            builder.append('[');
            builder.append(info.errorContext);
            builder.append(':');
            builder.append(info.errorCode.getCode());
            builder.append(']');
            builder.append(info.errorText);
            if (i > 0) builder.append('\n');
        }

        // append root causes and text from this exception first.
        if (getMessage() != null) {
            builder.append('\n');
            if (getCause() == null) {
                builder.append(getMessage());
            } else if (!getMessage().equals(getCause().toString())) {
                builder.append(getMessage());
            }
        }
        appendException(builder, getCause());

        return builder.toString();
    }

    private void appendException(StringBuilder builder, Throwable throwable) {
        if (throwable == null) return;
        appendException(builder, throwable.getCause());
        builder.append(throwable.toString());
        builder.append('\n');
    }

    /**
     * Retrieve list of error codes and details
     * @return List<InfoItem>
     */
    public List<InfoItem> getErrorInfoList(){
        return infoItems;
    }

    /**
     * The type Info item.
     */
    @ToString
    public class InfoItem {
        /**
         * The Error context.
         */
        public String errorContext = null;

        /**
         * The Error code.
         */
        public ErrorCodes errorCode = null;

        /**
         * The Error text.
         */
        public String errorText = null;

        /**
         * Instantiates a new Info item.
         *
         * @param contextCode the context code
         * @param errorCode   the error code
         * @param errorText   the error text
         */
        public InfoItem(String contextCode, ErrorCodes errorCode, String errorText) {
            this.errorContext = contextCode;
            this.errorCode = errorCode;
            this.errorText = errorText;
        }
    }
}
