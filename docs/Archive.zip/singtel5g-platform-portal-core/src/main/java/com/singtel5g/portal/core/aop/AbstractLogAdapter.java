package com.singtel5g.portal.core.aop;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 28/8/2020<br>
 * Description: Base class for any logger aspect implementation. It contains global configurations
 * and settings to be used by all loggers.
 */
public abstract class AbstractLogAdapter {
    /**
     * The Param blacklist.
     */
    protected final Set<String> paramBlacklist =
            new HashSet<>(
                    Arrays.asList(
                            "password",
                            "passwd",
                            "pass",
                            "pwd",
                            "secret",
                            "authorization",
                            "api_key",
                            "apikey",
                            "access_token",
                            "accesstoken"));

    /**
     * The Scrubbed value.
     */
    @Nonnull
    protected String scrubbedValue = "xxxxx";

    /**
     * The Enable data scrubbing.
     */
    protected boolean enableDataScrubbing = true;

    /**
     * The Param blacklist regex.
     */
    @Nullable
    protected Pattern paramBlacklistRegex;

    /**
     * Sets default scrubbed value.
     *
     * @param defaultScrubbedValue the default scrubbed value
     */
    public void setDefaultScrubbedValue(@Nonnull String defaultScrubbedValue) {
        scrubbedValue = defaultScrubbedValue;
    }

    /**
     * Sets enable data scrubbing.
     *
     * @param enableDataScrubbing the enable data scrubbing
     */
    public void setEnableDataScrubbing(boolean enableDataScrubbing) {
        this.enableDataScrubbing = enableDataScrubbing;
    }

    /**
     * Sets param blacklist regex.
     *
     * @param paramBlacklistRegex the param blacklist regex
     */
    public void setParamBlacklistRegex(@Nonnull String paramBlacklistRegex) {
        this.paramBlacklistRegex = Pattern.compile(paramBlacklistRegex);
    }

    /**
     * Sets custom param blacklist.
     *
     * @param customParamBlacklist the custom param blacklist
     */
    public void setCustomParamBlacklist(@Nonnull Set<String> customParamBlacklist) {
        customParamBlacklist.forEach(i -> paramBlacklist.add(i.toLowerCase()));
    }
}
