package com.singtel5g.portal.core.exception;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 28/6/2020<br>
 * Description: Description: {@code InvalidUserStateException} is responsible for resolving a source
 * exception to a Invalid User StateException.
 */
public class InvalidUserStateException extends SystemException {
    /**
     * Instantiates a new Invalid user state exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public InvalidUserStateException(String errorContext, ErrorCodes errorCode, String errorMessage) {
        super(errorContext, errorCode, errorMessage);
    }

    /**
     * Instantiates a new Invalid user state exception.
     *
     * @param errorContext the error context
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @param cause        the cause
     */
    public InvalidUserStateException(
            String errorContext, ErrorCodes errorCode, String errorMessage, Throwable cause) {
        super(errorContext, errorCode, errorMessage, cause);
    }
}
