package com.singtel5g.portal.core.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 21/7/2020<br>
 * Description: Class {@code EnumUtils} provides a series of common Enum <br>
 * Utility APIs so that the handling associated with Enum object <br>
 * can be simplified and reused in PCP
 *
 * <p>All APIs are static method, without any object instance required.
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class EnumUtils {

    /**
     * Search enum t.
     *
     * <p>Usage :
     *
     * <pre>
     * public enum Horse {
     *    THREE_LEG_JOE, GLUE_FACTORY
     * };
     *
     *  public static void main(String[] args) {
     *      System.out.println(searchEnum(Horse.class,"Three_Leg_Joe"));
     *     System.out.println(searchEnum(Day.class, "ThUrSdAy"));
     *  }
     * </pre>
     *
     * <p>
     *
     * @param enumeration the enumeration
     * @return the t
     */
    public static <T extends Enum<?>> T searchEnum(Class<T> enumeration, String search) {
        for (T each : enumeration.getEnumConstants()) {
            if (each.name().compareToIgnoreCase(search) == 0) {
                return each;
            }
        }
        return null;
    }
}
