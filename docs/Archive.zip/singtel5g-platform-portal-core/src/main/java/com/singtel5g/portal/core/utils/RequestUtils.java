package com.singtel5g.portal.core.utils;

import com.singtel5g.portal.core.beans.RequestContext;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 29/8/2020<br>
 * Description:
 */
public class RequestUtils {
    /**
     * Gets request context.
     *
     * @return the request context
     */
    public RequestContext getRequestContext() {
        HttpServletRequest request = getCurrentHttpRequest();

        return new RequestContext().add("url", getRequestUrl(request));
    }

    /**
     * Gets current http request.
     *
     * @return the current http request
     */
    @Nullable
    private HttpServletRequest getCurrentHttpRequest() {
        HttpServletRequest request = null;
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        if (requestAttributes != null && requestAttributes instanceof ServletRequestAttributes)
            request = ((ServletRequestAttributes) requestAttributes).getRequest();
        return request;
    }

    /**
     * Gets request url.
     *
     * @param request the request
     * @return the request url
     */
    @Nullable
    private String getRequestUrl(@Nullable HttpServletRequest request) {
        return request == null ? null : request.getRequestURL().toString();
    }

    /**
     * Gets request user header.
     *
     * @return the request context
     */
    public String getRequestUserHeader() {

        HttpServletRequest request = getCurrentHttpRequest();
        return getRequestUserHeader(request);
    }

    /**
     * Gets request user header.
     *
     * @param request the request
     * @return the user header
     */
    @Nullable
    private String getRequestUserHeader(@Nullable HttpServletRequest request) {
        return request == null ? null : request.getHeader("X-User-Details");
    }

}
