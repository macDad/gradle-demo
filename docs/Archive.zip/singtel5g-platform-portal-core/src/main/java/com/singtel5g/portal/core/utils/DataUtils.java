package com.singtel5g.portal.core.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 6/7/2020<br>
 * Description:
 */

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DataUtils {

    /**
     * Gets the long.
     *
     * @param value the value
     * @return the long
     */
    public static Long getLong(Object value) {

        Long ret = null;
        if (value != null) {
            if (value instanceof Long) {
                ret = (Long) value;
            } else if (value instanceof String) {
                ret = Long.parseLong((String) value);
            } else if (value instanceof BigDecimal) {
                ret = ((BigDecimal) value).longValue();
            } else if (value instanceof Number) {
                ret = ((Number) value).longValue();
            } else {
                throw new ClassCastException(
                        "Not possible to coerce ["
                                + value
                                + "] from class "
                                + value.getClass()
                                + " into a Long.");
            }
        }
        return ret;
    }

    /**
     * Gets big integer.
     *
     * @param value the value
     * @return the big integer
     */
    public static BigInteger getBigInteger(Object value) {
        BigInteger ret = null;
        if (value != null) {
            if (value instanceof BigInteger) {
                ret = (BigInteger) value;
            } else if (value instanceof String) {
                ret = new BigInteger((String) value);
            } else if (value instanceof BigDecimal) {
                ret = ((BigDecimal) value).toBigInteger();
            } else if (value instanceof Number) {
                ret = BigInteger.valueOf(((Number) value).longValue());
            } else {
                throw new ClassCastException(
                        "Not possible to coerce ["
                                + value
                                + "] from class "
                                + value.getClass()
                                + " into a BigInteger.");
            }
        }
        return ret;
    }

    /**
     * Gets big decimal.
     *
     * @param value the value
     * @return the big decimal
     */
    public static BigDecimal getBigDecimal(Object value) {
        BigDecimal ret = null;
        if (value != null) {
            if (value instanceof BigDecimal) {
                ret = (BigDecimal) value;
            } else if (value instanceof String) {
                ret = new BigDecimal((String) value);
            } else if (value instanceof BigInteger) {
                ret = new BigDecimal((BigInteger) value);
            } else if (value instanceof Number) {
                ret = BigDecimal.valueOf(((Number) value).doubleValue());
            } else {
                throw new ClassCastException(
                        "Not possible to coerce ["
                                + value
                                + "] from class "
                                + value.getClass()
                                + " into a BigDecimal.");
            }
        }
        return ret;
    }

    /**
     * Big int to string string.
     *
     * @param bigInteger the big Integer
     * @return the string
     */
    public static String bigIntToString(BigInteger bigInteger) {
        String result = "";
        if (!ObjectUtils.isNullOrEmpty(bigInteger)) {
            result = bigInteger.toString();
        }
        return result;
    }
}
