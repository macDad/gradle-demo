package com.singtel5g.portal.core.function;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 8/5/2020<br>
 * Description: Interface {@code GenericServiceFunction} use to execute functions on the components
 * of 5G platform portal microservices
 *
 * <p>This need to be use on component classes, without any object instance required.
 */
@FunctionalInterface
public interface GenericServiceFunction {
    /**
     * Apply.
     */
    void apply();
}
