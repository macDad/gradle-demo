package com.singtel5g.portal.audit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * The type Singtel 5 g platform portal audit module application tests.
 */
@SpringBootTest
class Singtel5gPlatformPortalAuditModuleApplicationTests {

    /**
     * Context loads.
     */
    @Test
    void contextLoads() {
    }
}
