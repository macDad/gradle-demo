package com.singtel5g.portal.audit.producer;

import com.singtel5g.portal.audit.models.AuditMessageModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/5/2020<br>
 * Description: Class {@code LoggingWriter} is used to manage the writing of <br>
 * audit log
 *
 * <p>LoggingWriter call NGCC API to write audit log with some <br>
 * customerized setting
 */
@Slf4j
@Service
public class AuditLogProducer {
  private final KafkaTemplate<String, AuditMessageModel> kafkaTemplate;

  private final KafkaAdmin kafkaAdmin;

  @Autowired
  public AuditLogProducer(KafkaAdmin kafkaAdmin,
                          KafkaTemplate<String, AuditMessageModel> kafkaTemplate) {
    this.kafkaAdmin = kafkaAdmin;
    this.kafkaTemplate = kafkaTemplate;
  }

  /**
   * Perform audit log with necessary parameters.
   *
   * @param topicName the topic name
   * @param payload   the payload
   */
  public void send(String topicName, AuditMessageModel payload) {

    log.info("Perform Audit Event start.");
    log.info("sending payload='{}'", payload);
    kafkaTemplate.send(topicName, payload);
    log.info("Preform Audit Event end.");
  }
}
