package com.singtel5g.portal.audit.component;

import com.singtel5g.portal.audit.models.AuditMessageModel;
import com.singtel5g.portal.audit.producer.AuditLogProducer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 6/5/2020<br>
 * Description: Class {@code AuditWriter} is used to manage the writing of audit log
 *
 * <p>AuditWriter call AuditLogProducer methods to write audit log with some <br>
 * customized setting
 */
@Slf4j
@Component
public class AuditWriter {
  /**
   * The Topic name.
   */
  private final String topicName = "singtel5g-portal-audit-topic";
  /**
   * The Kafka message sender.
   */
  @Autowired
  AuditLogProducer auditLogProducer;
  /**
   * The Group id.
   */
  @Value("${group.id.config}")
  private String groupId;

  @Value("${audit.enabled}")
  private boolean auditEnabled;

  /**
   * Perform audit log with necessary parameters
   *
   * @param tableName    the table name
   * @param functionCode the function code
   * @param payload      the payload
   */
  public void perform(String tableName, String functionCode, Map<String, Object> payload) {
    log.info("Perform Audit Writer start.");
    if (auditEnabled) {
      log.info(
              "prepared date to send topicName:'{}' groupId:'{}' tableName:'{}' functionCode:'{}' payload:'{}'",
              topicName,
              groupId,
              tableName,
              functionCode,
              payload);
      AuditMessageModel kafkaMessageModel =
              new AuditMessageModel(topicName, groupId, tableName, functionCode, payload);

      auditLogProducer.send(topicName, kafkaMessageModel);

      log.info("Preform Audit Event end.");
    } else log.info(">>>>> >>>> >>> >> > Audit not enabled.");
  }
}
