package com.singtel5g.portal.audit.config;

import com.singtel5g.portal.audit.consumer.AuditLogConsumer;
import com.singtel5g.portal.audit.models.AuditMessageModel;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/5/2020<br>
 * Description:
 */
@Configuration
@EnableKafka
@EnableEncryptableProperties
public class KafkaConsumerConfig {

  @Value("${bootstrap.servers.config.key}")
  private String bootstrapServersConfig;

  @Value("${group.id.config}")
  private String groupId;

  @Value("${auto.offset.reset.config}")
  private String earliest;

  @Value("${security.protocol}")
  private String securityProtocol;

  @Value("${ssl.truststore.location.key}")
  private String trustStoreLocation;

  @Value("${ssl.truststore.password.key}")
  private String trustStorePassword;

  @Value("${ssl.keystore.location.key}")
  private String keyStoreLocation;

  @Value("${ssl.keystore.password.key}")
  private String keyStorePassword;

  @Value("${ssl.key.password.key}")
  private String keyPassword;

  @Value("${ssl.enabled}")
  private boolean sslEnabled;

  /**
   * Kafka listener container factory concurrent kafka listener container factory.
   *
   * @return the concurrent kafka listener container factory
   */
  @Bean
  public ConcurrentKafkaListenerContainerFactory<String, AuditMessageModel>
  kafkaListenerContainerFactory() {
    ConcurrentKafkaListenerContainerFactory<String, AuditMessageModel>
            concurrentKafkaListenerContainerFactory = new ConcurrentKafkaListenerContainerFactory<>();
    concurrentKafkaListenerContainerFactory.setConsumerFactory(consumerFactory());
    return concurrentKafkaListenerContainerFactory;
  }

  /**
   * Consumer factory consumer factory.
   *
   * @return the consumer factory
   */
  @Bean
  public ConsumerFactory<String, AuditMessageModel> consumerFactory() {
    Map<String, Object> config = consumerConfigs();

    return new DefaultKafkaConsumerFactory<>(
            config, new StringDeserializer(), new JsonDeserializer<>(AuditMessageModel.class));
  }

  /**
   * Consumer configs map.
   *
   * @return the map
   */
  @Bean
  public Map<String, Object> consumerConfigs() {
    Map<String, Object> config = new HashMap<>();
    // list of host:port pairs used for establishing the initial connections to the Kafka cluster
    config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, System.getProperty(bootstrapServersConfig));
    config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
    // allows a pool of processes to divide the work of consuming and processing records
    config.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
    // automatically reset the offset to the earliest offset
    config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, earliest);
    if (sslEnabled) {
      config.put("security.protocol", securityProtocol);
      config.put("ssl.truststore.location", System.getProperty(trustStoreLocation));
      config.put("ssl.truststore.password", System.getProperty(trustStorePassword));
      config.put("ssl.key.password", System.getProperty(keyPassword));
      config.put("ssl.keystore.password", System.getProperty(keyStorePassword));
      config.put("ssl.keystore.location", System.getProperty(keyStoreLocation));
      config.put("ssl.endpoint.identification.algorithm", "");
    }
    return config;
  }

  /**
   * Receiver audit log consumer.
   *
   * @return the audit log consumer
   */
  @Bean
  public AuditLogConsumer receiver() {
    return new AuditLogConsumer();
  }
}
