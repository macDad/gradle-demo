package com.singtel5g.portal.audit;

import com.singtel5g.portal.audit.producer.AuditLogProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;

/** The type Singtel 5 g platform portal audit module application. */
// @EnableAsync
// @SpringBootApplication
public class Singtel5gPlatformPortalAuditModuleApplication {
  @Autowired
  AuditLogProducer auditLogProducer;
  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    SpringApplication.run(Singtel5gPlatformPortalAuditModuleApplication.class, args);
  }
}
