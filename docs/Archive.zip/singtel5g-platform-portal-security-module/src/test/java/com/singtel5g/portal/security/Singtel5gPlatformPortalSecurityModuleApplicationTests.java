package com.singtel5g.portal.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * The type Singtel 5 g platform portal security module application tests.
 */
@SpringBootTest
class Singtel5gPlatformPortalSecurityModuleApplicationTests {

  /**
   * Context loads.
   */
  @Test
  void contextLoads() {
  }
}
