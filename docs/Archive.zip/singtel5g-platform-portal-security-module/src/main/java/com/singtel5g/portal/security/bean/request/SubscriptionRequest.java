// ************************************************************************************************* 
// 
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************ 
// 
// Copyright(C) 2020 Singapore Telecommunications Limited 
// All rights reserved. 
// 
// This source code and all binaries derived from this source code here is intended for the sole 
// use of Singapore Telecommunications Limited and contains information that is confidential 
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including, 
// but not limited to, total or partial reproduction, communication, or dissemination in any form) 
// by persons other than the employees of Singapore Telecommunications Limited is prohibited. 
// 
// ***********************************************************************************************
package com.singtel5g.portal.security.bean.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Create by    : <B>Udayanga@Singtel</B>
 *
 * <p>Date      : 02 July 2021<br>
 * Project      : <B>singtel5g-platform-portal-security-module</B><br>
 * Since        : version 6.2 <br></p>
 * Description  : The SubscriptionRequest type
 */

/**
 * The type Subscription request.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubscriptionRequest {

	private String id;

    @Schema(description = "Reference Number.", example = "5G00020001")
    private String referenceNumber;
}
