package com.singtel5g.portal.security.component.helper;

import com.singtel5g.portal.core.utils.StringUtils;
import com.singtel5g.portal.security.common.enums.Privilege;
import com.singtel5g.portal.security.proxy.AuthProxy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;


/**
 * Create by:KasunSilva@Singtel
 *
 * <p>Date: 21/11/2021<br>
 * Description: Class {@code AuthCheckHelper} is used to check the user's authority on accessing particular resource
 *
 * <p>AuthCheckHelper is extention of AuthCheck <br>
 */
@Slf4j
@Component
public class AuthCheckHelper {

	/** API Proxy component to call auth service. **/
	@Autowired
	private AuthProxy apiProxy;

    /** Auth check switch **/
    @Value("${5gplatform.auth.privileges.check:true}")
    private boolean authCheckOn;

    /**
     * validate given user details and given organization code
     * @param userDetails
     * @param orgCode
     * @return boolean
     */
    protected boolean organizationDetailsCheck(String userDetails, String orgCode) {

        if(!authCheckOn) {
            log.info("Auth check is deactivated. Organization Details check skipped");
            return true;
        }

        if (StringUtils.isNullOrBlank(orgCode)) {
            log.info("Organization cannot be null or empty.");
            return false;
        }

        final var privilegesResponse = this.apiProxy.getPrivilegessMap(userDetails);
        if (privilegesResponse != null && HttpStatus.OK.equals(privilegesResponse.getResultCode()) ){
            if(!privilegesResponse.getPrivileges().contains(Privilege.SUPER_ADMIN.value())){
                if (orgCode.equals(privilegesResponse.getOrganizationCode())) {
                    log.info("You are not authorized to perform this actions for the organization: " + orgCode);
                    return true;
                }
            }else{
                return true;
            }
        }

        log.info("Organization Details Check End and organization: " + orgCode+ " is not valid to perform this action.");
        return false;
    }

}
