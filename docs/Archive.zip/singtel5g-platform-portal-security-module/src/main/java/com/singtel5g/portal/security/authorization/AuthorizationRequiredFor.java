// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

package com.singtel5g.portal.security.authorization;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Create by : <B>Kushan@Singtel</B>
 *
 * <p>
 * Date : 18/3/2021<br>
 * Project : <B>singtel5g-platform-portal-security-module </B><br>
 * Since : version 5.03 <br>
 * </p>
 * Description : Annotation is used to validate the user permission in REST endpoints
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface AuthorizationRequiredFor {

    /**
     * Check at least one permission is satisfied with user token
     * @return
     */
    String [] hasAnyPermission() default {};

    /**
     * Check all the given permissions are satisfied with user token
     * @return
     */
    String [] hasAllPermission() default {};
}
