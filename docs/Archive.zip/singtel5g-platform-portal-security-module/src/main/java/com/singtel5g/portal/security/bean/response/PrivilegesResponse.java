package com.singtel5g.portal.security.bean.response;

import java.util.List;
import java.util.Set;

import com.singtel5g.portal.security.bean.request.SubscriptionRequest;
import org.springframework.http.HttpStatus;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Create by: ishan.liyanage@Singtel
 *
 * <p>Date: 8/9/2020<br>
 * Description: Class {@code PrivilegesResponse} is used to return user's privilege set
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrivilegesResponse {

	private String id;
    private String username;
    private String email;
    private String firstName;
    private String lastName;
    private String status;
    private List<String> roles;
    private String organizationId;
    private String organizationCode;
    private String organizationName;
    private String departmentId;
    private String departmentCode;
    private String departmentName;
    private Set<String> privileges;
    private SubscriptionRequest currentSubscription;
    private Set<SubscriptionRequest> subscriptions;

    private String result;
    private HttpStatus resultCode;
}
