package com.singtel5g.portal.security.bean.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Create by: ishan.liyanage@Singtel
 *
 * <p>Date: 8/9/2020<br>
 * Description: Class {@code PrivilegesRequest} is used to request user's privilege set
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrivilegesRequest {

	private String userDetails;
}
