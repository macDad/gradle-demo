package com.singtel5g.portal.security.proxy;

import com.singtel5g.portal.core.exception.ErrorCodes;
import com.singtel5g.portal.core.utils.ExceptionUtils;
import com.singtel5g.portal.security.bean.request.PrivilegesRequest;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

/**
 * Create by: ishan.liyanage@Singtel
 *
 * <p>Date: 8/9/2020<br>
 * Description: Class {@code AuthProxy} is used to call Auth Service to get user's privilege set
 *
 */
@Slf4j
@Component
public class AuthProxy {

    /** The Application name. */
    @Value("${spring.application.name}")
    public String APPLICATION_NAME;
    
    /** Auth Service User URL **/
    @Value("${5gplatform.user.details.url}")
    private String user_details_url;

    /** Auth Service URL **/
    @Value("${5gplatform.auth.privileges.url}")
    private String url;

    /** User Details Header **/
    private final String X_USER_DETAILS = "X-User-Details";

    /**
     * retrieve User privileges set.
     *
     * @return the privileges Set response
     */
    public PrivilegesResponse getPrivilegessMap(String userDetails) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            log.info("Sending request to get user's privileges set");
            PrivilegesRequest request = new PrivilegesRequest();
            request.setUserDetails(userDetails);
            ResponseEntity<PrivilegesResponse> responseBean =
                    restTemplate.postForEntity(url, request, PrivilegesResponse.class);

            log.info("received response for user permission set with PrivilegesResponse");
            return responseBean.getBody();
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            if (HttpStatus.NOT_FOUND.equals(e.getStatusCode())) {
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME, ErrorCodes.API_GENERIC_ERROR, "ServiceRequestBean not found");
            } else {
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME, ErrorCodes.API_GENERIC_ERROR, "Internal server error.");
            }
        }
    }

    /**
     * Get User Details.
     *
     * @return the privileges Set response
     */
    public PrivilegesResponse getUserDetails(String userDetails) {
        try {
            RestTemplate restTemplate = new RestTemplate();

            HttpHeaders requestHeaders = new HttpHeaders() ;
            requestHeaders.add(X_USER_DETAILS,userDetails);
            HttpEntity request = new HttpEntity(requestHeaders);

            ResponseEntity<PrivilegesResponse> responseBean =
                    restTemplate.exchange( user_details_url, HttpMethod.GET, request,  PrivilegesResponse.class);

            log.info("received response for user permission set with PrivilegesResponse");
            return responseBean.getBody();
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            if (HttpStatus.NOT_FOUND.equals(e.getStatusCode())) {
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME, ErrorCodes.API_GENERIC_ERROR, "ServiceRequestBean not found");
            } else {
                throw ExceptionUtils.newValidationException(
                        APPLICATION_NAME, ErrorCodes.API_GENERIC_ERROR, "Internal server error.");
            }
        }
    }
}
