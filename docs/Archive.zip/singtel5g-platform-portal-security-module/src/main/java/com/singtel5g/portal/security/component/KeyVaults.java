package com.singtel5g.portal.security.component;
// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************


import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.security.proxy.VaultsProxy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


/**
 * Create by    : <B>Udayanga@Singtel</B>
 *
 * <p>Date      : 30/12/2020<br>
 * Project      : <B>singtel5g-platform-portal-security-module</B><br>
 * Since        : version 5.0 <br></p>
 * Description  : The type KeyVaults.
 */
@Slf4j
@Component
public class KeyVaults {


    /**
     * API Proxy component to call key vault service.
     **/
    @Autowired
    private VaultsProxy vaultsProxy;


    public String retrieveKeyVault(String key) {

        log.info("Perform Retrieve Key Vault start.");

        if (ObjectUtils.isNullOrEmpty(key)) {
            return null;
        }

        String vault = vaultsProxy.retrieveKeyVault(key);

        log.info("Preform Auth Check end.");
        return vault;

    }


    public Map retrieveKeyVaultMap(String key) {

        log.info("Perform Retrieve Key Vault start.");

        if (ObjectUtils.isNullOrEmpty(key)) {
            return null;
        }

        Map vault = vaultsProxy.retrieveKeyVaultMap(key);

        log.info("Preform Auth Check end.");
        return vault;

    }

}
