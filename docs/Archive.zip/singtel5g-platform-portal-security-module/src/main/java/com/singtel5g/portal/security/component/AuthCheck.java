package com.singtel5g.portal.security.component;

import com.singtel5g.portal.core.exception.ErrorCodes;
import com.singtel5g.portal.core.exception.SystemException;
import com.singtel5g.portal.core.utils.StringUtils;
import com.singtel5g.portal.security.bean.request.PermissionParam;
import com.singtel5g.portal.security.bean.response.PrivilegesResponse;
import com.singtel5g.portal.security.common.constant.SecurityConstants;
import com.singtel5g.portal.security.common.enums.Privilege;
import com.singtel5g.portal.security.component.helper.AuthCheckHelper;
import com.singtel5g.portal.security.proxy.AuthProxy;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Set;

/**
 * Create by: ishan.liyanage@Singtel
 *
 * <p>Date: 8/9/2020<br>
 * Description: Class {@code AuthCheck} is used to check the user's authority on accessing particular resource
 *
 * <p>AuthCheck call Auth Service Module method to check against user's role privileges map <br>
 */
@Slf4j
@Component
public class AuthCheck extends AuthCheckHelper {

	/** API Proxy component to call auth service. **/
	@Autowired
	private AuthProxy apiProxy;

	/** Auth check switch **/
    @Value("${5gplatform.auth.privileges.check:true}")
    private boolean authCheckOn;
    
  /**
   * Perform permission check with necessary parameters
   * @param userDetails    the user detail token
   * @param action    the action name
   */
  public boolean hasPermission(String userDetails, String action) {
    log.info("Perform Auth Check start.");
      if(checkUserDetailsAndAction(userDetails, action)) {
          return true;
      }

    log.info("Preform Auth Check end.");
    return false;
  }

    /**
     * Perform permission check with necessary parameters
     * @param userDetails    the user detail token
     * @param action    the action name
     * @param orgCode    the organization Code
     */
    public boolean hasPermission(String userDetails, String action, String orgCode) {
        log.info("Perform Auth Check and Organization Check start.");
        if(checkUserDetailsAndAction(userDetails, action)) {
            log.info("UserDetails And Action check successful.");
            if(organizationDetailsCheck(userDetails, orgCode)){
                log.info("Organization Details Check check successful.");
                return true;
            }
        }

        log.info("Preform Auth Check and Organization Check end.");
        return false;
    }

    /**
     * Perform permission check with  parameters from provided in @{@link PermissionParam}
     * -Check user have permission to the Action
     * -Check user have permission to access organization and subscription
     *
     * @param param @{@link PermissionParam}
     * @return @{@link Boolean}
     */
    public boolean hasPermission(PermissionParam param) {

        boolean hasPermission = false;

        if (!authCheckOn) {
            log.debug("Auth check is deactivated.");
            hasPermission = true;
        }else {
            PrivilegesResponse privilegesDetails = getPrivilegesResponse(param);
            if (privilegesDetails != null && privilegesDetails.getPrivileges() != null) {
                hasPermission = hasPermission(param, privilegesDetails);
            }
        }
        return hasPermission;
    }

    private PrivilegesResponse getPrivilegesResponse(PermissionParam param) {

        PrivilegesResponse privilegesDetails = null;
        if(param !=null && !StringUtils.isNullOrBlank(param.getUserDetails())){

            privilegesDetails = apiProxy.getPrivilegessMap(param.getUserDetails());
            if(privilegesDetails == null || privilegesDetails.getPrivileges() == null){

                throw new SystemException("[Security]",
                        ErrorCodes.PORTAL_GENERIC_ERROR,
                        "Unable to retrieve user details for the given token Token" + param.getUserDetails());
            }
        }else{
            log.error("PermissionParam / X-User-Details is not provided");
        }
        return privilegesDetails;
    }

    private boolean hasPermission(PermissionParam param, PrivilegesResponse privilegesDetails) {

        boolean hasPermission =false;
        if (privilegesDetails.getPrivileges().contains(param.getAction())
                || privilegesDetails.getPrivileges().contains(param.getAction().concat(SecurityConstants.PERMISSION_ALL_SUFFIX))) {

            hasPermission = isOrganizationAllowed(param, privilegesDetails) && isSubscriptionAllowed(param, privilegesDetails);
            if(hasPermission){
                log.debug("User[ %s ] have privilege to access (Organization: %s or/and Subscription: %s )",
                        privilegesDetails.getUsername(), param.getAction(), param.getOrgCode(), param.getSubscription());
            }else{
                log.error("User[ %s ] NOT have privilege to access (Organization: %s or/and Subscription: %s )",
                        privilegesDetails.getUsername(), param.getAction(), param.getOrgCode(), param.getSubscription());
            }

        } else {
            log.error("User[ %s ] not have action privilege to perform the operation: %s",
                    privilegesDetails.getUsername(), param.getAction());
        }
        return hasPermission;
    }

    private boolean isSubscriptionAllowed(PermissionParam param, PrivilegesResponse privilegesDetails) {
        return !param.isValidateSubscription() || privilegesDetails.getPrivileges().contains(Privilege.VIEW_ALL_SUBSCRIPTION.value()) ||
                isSubscriptionContains(param, privilegesDetails);
    }

    private boolean isSubscriptionContains(PermissionParam param, PrivilegesResponse privilegesDetails) {
        boolean isContainsSubscription = false;
        if (param.getSubscription() != null && privilegesDetails != null && !CollectionUtils.isEmpty(privilegesDetails
                .getSubscriptions())) {
            isContainsSubscription =
                    privilegesDetails.getSubscriptions().stream().
                            anyMatch(subscriptionRequest -> StringUtils.isEquals(subscriptionRequest.getReferenceNumber(), param.getSubscription())
                                    || StringUtils.isEquals(subscriptionRequest.getId(), param.getSubscription()));
        }
        return isContainsSubscription;
    }

    private boolean isOrganizationAllowed(PermissionParam param, PrivilegesResponse privilegesDetails) {
        return !param.isValidateOrganization() || privilegesDetails.getPrivileges().contains(Privilege.VIEW_ALL_ORGANIZATION.value()) ||
                StringUtils.isEquals(privilegesDetails.getOrganizationCode(),
                        param.getOrgCode())
                ||StringUtils.isEquals(privilegesDetails.getOrganizationId(),
                param.getOrgCode());
    }


    /**
     * Perform permission check with necessary parameters
     * @param userDetails    the user detail token
     * @param action    the action name
     */
    private boolean checkUserDetailsAndAction(String userDetails, String action) {
        log.info("Perform check User Details And Action.");
        if(!authCheckOn) {
            log.info("Auth check is deactivated.");
            return true;
        }
        PrivilegesResponse privilegesDetails = apiProxy.getPrivilegessMap(userDetails);
        if(privilegesDetails != null && privilegesDetails.getPrivileges() != null) {
            return privilegesDetails.getPrivileges().contains(action);
        }

        log.info("Preform Auth Check end.");
        return false;
    }
  
  /**
   * Perform user session validity
   * @param userDetails    the user detail token
   */
  public boolean hasValidSession(String userDetails) {
    log.info("Perform session validity start.");
    if(!authCheckOn) {
    	return true;
    }
    PrivilegesResponse privilegesDetails = apiProxy.getPrivilegessMap(userDetails);
    if(privilegesDetails.getPrivileges() != null) {
    	return true;
    }

    log.info("Preform session validity end.");
    return false;
  }
  
  /**
   * Perform user details retrieval
   * @param userDetails    the user detail token
   */
  public PrivilegesResponse retreiveUserDetails(String userDetails) {
    log.info("Preform retrieve user details start.");
    if(!authCheckOn) {
    	return null;
    }
    PrivilegesResponse privilegesDetails = apiProxy.getPrivilegessMap(userDetails);
    log.info("Preform retrieve user details end.");

    return privilegesDetails;

  }
  /**
   * Perform check to see if auth check is enabled.
   */
  public boolean isAuthCheckEnabled() {
	  return authCheckOn;
  }


    /**
     * Perform user details retrieval
     * @param token  the user detail token
     */
    public PrivilegesResponse retrieveUserDetailsByToken(String token) {
        log.info("Preform retrieve User Details By Token start.");
        if(!authCheckOn) {
            return null;
        }
        PrivilegesResponse privilegesDetails = apiProxy.getUserDetails(token);
        log.info("Preform retrieve User Details By Token end.");

        return privilegesDetails;
    }

  /**
   * validate given token has all the required permissions
   * @param userDetails
   * @param permissions
   * @return
   */
  public boolean hasAllPermission(String userDetails, Set<String> permissions) {
    log.info("Perform Auth Check start.");
    if (!this.authCheckOn) {
      return true;
    } else {
      PrivilegesResponse privilegesDetails = this.apiProxy.getPrivilegessMap(userDetails);
      if (privilegesDetails.getPrivileges() != null) {
        return privilegesDetails.getPrivileges().containsAll(permissions);
      } else {
        log.info("Preform Auth Check end.");
        return false;
      }
    }
  }

  /**
   * validate given token has at least one required permissions
   * @param userDetails
   * @param permissions
   * @return
   */
  public boolean hasAnyPermission(String userDetails, Set<String> permissions) {
    log.info("Perform Auth Check start.");
    if (!this.authCheckOn) {
      return true;
    } else {

      final PrivilegesResponse privilegesDetails = this.apiProxy.getPrivilegessMap(userDetails);
      if (privilegesDetails.getPrivileges() != null && permissions !=null) {
        return privilegesDetails.getPrivileges().stream().anyMatch(s -> permissions.contains(s));
      } else {
        log.info("Preform Auth Check end.");
        return false;
      }
    }
  }

}
