// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

package com.singtel5g.portal.security.bean.request;

import lombok.*;

/**
 * Create by : <B>Kushan@Singtel</B>
 *
 * <p>
 * Date : 20/1/2022<br>
 * Project : <B>singtel5g-platform-portal-security-module </B><br>
 * Since : version version 6.7.0 <br>
 * </p>
 * Description : Model class to transfer the permission parameters to security check
 */
@Getter
@Builder
@NoArgsConstructor
public class PermissionParam {

    private String action;
    private String userDetails;
    private String orgCode;
    private String subscription;
    private boolean validateOrganization;
    private boolean validateSubscription;

    /**
     * When the organization is setting @{@link PermissionParam.validateOrganization} is setting to true.
     * this is should be set to false if no need to validate organization
     * @param orgCode
     */
    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
        validateOrganization = true;
    }

    /**
     * When the subscription is setting @{@link PermissionParam.validateSubscription} is setting to true.
     * this is should be set to false if no need to validate subscription
     * @param subscription
     */
    public void setSubscription(String subscription) {
        this.subscription = subscription;
        validateSubscription = true;
    }


    /**
     * Create the PermissionParam obejct
     * validateOrganization is setting to true or false base on the organization value
     * validateSubscription is setting to true or flase base on the subscription value
     * @param action
     * @param userDetails
     * @param orgCode
     * @param subscription
     * @param validateOrganization
     * @param validateSubscription
     */
    public PermissionParam(final String action, final String userDetails, final String orgCode, final String subscription, final boolean validateOrganization, final boolean validateSubscription) {
        this.action = action;
        this.userDetails = userDetails;
        this.orgCode = orgCode;
        this.subscription = subscription;
        this.validateOrganization = orgCode !=null;
        this.validateSubscription = subscription!=null;
    }


}
