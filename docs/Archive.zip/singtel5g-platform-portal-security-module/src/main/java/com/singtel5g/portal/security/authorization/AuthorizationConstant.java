// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

package com.singtel5g.portal.security.authorization;

/**
 * Create by : <B>Kushan@Singtel</B>
 *
 * <p>
 * Date : 18/3/2021<br>
 * Project : <B>singtel5g-platform-portal-security-module </B><br>
 * Since : version 5.03 <br>
 * </p>
 * Description : singtel5g-platform-portal-security-module
 */
public class AuthorizationConstant {

    private AuthorizationConstant() {
        throw new AssertionError();
    }

    /**
     * The enum String constant.
     */
    public enum StringConstant implements ConstantType {


        UNAUTH_MESSAGE("Unauthorized API call");

        private final String value;

        StringConstant(String value) {
            this.value = value;
        }

        /**
         * Value string.
         *
         * @return the string
         */
        public String value() {
            return value;
        }
    }

    /**
     * The interface Constant type.
     */
    public interface ConstantType {
    }

}
