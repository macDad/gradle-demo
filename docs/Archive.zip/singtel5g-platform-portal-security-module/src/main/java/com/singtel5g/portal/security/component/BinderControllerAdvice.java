/*  *************************************************************************************************
 *
 * PROJECT : Paragon 5G Platform™
 * PRODUCT : Paragon 5G Platform™ - Backend
 *  ************************************************************************************************
 *
 * Copyright(C) 2020 Singapore Telecommunications Limited
 * All rights reserved.
 *
 * This source code and all binaries derived from this source code here is intended for the sole
 * use of Singapore Telecommunications Limited and contains information that is confidential
 * and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
 * but not limited to, total or partial reproduction, communication, or dissemination in any form)
 * by persons other than the employees of Singapore Telecommunications Limited is prohibited.
 *
 * ************************************************************************************************/
package com.singtel5g.portal.security.component;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author : Moira_Pang@Singtel
 * @date : 8/4/2022
 * @project : 5g-platform-portal-core-modules-security
 * @Since : version 1.0
 * @Description : Spring RCE Vulnerability https://spring.io/blog/2022/03/31/spring-framework-rce-early-announcement
 *				  BinderControllerAdvice Class no longer required with SpringBoot 2.6.6, hence can be removed
 */

@RestControllerAdvice
@Order(Ordered.LOWEST_PRECEDENCE)
public class BinderControllerAdvice {

	@InitBinder
	public void setAllowedFields(WebDataBinder dataBinder) {
		String[] denylist = new String[]{"class.*", "Class.*", "*.class.*", "*.Class.*"};
		dataBinder.setDisallowedFields(denylist);
	}
}