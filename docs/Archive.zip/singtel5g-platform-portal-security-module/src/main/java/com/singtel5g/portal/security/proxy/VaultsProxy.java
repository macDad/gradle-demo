package com.singtel5g.portal.security.proxy;
// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Create by    : <B>Udayanga@Singtel</B>
 *
 * <p>Date      : 30/12/2020<br>
 * Project      : <B>singtel5g-platform-portal-security-module</B><br>
 * Since        : version 5.0 <br></p>
 * Description  : The type VaultsProxy.
 */

@Slf4j
@Component
public class VaultsProxy {


    /**
     * Vault Service URL
     **/
    @Value("${5gplatform.auth.key.vaults.url}")
    private String url;

    /**
     * Retrieve Key Vault.
     *
     * @param key
     * @return the vault string
     */
    public String retrieveKeyVault(String key) {

        log.info("Retrieve Key Vault start.");

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<?> response = restTemplate.exchange(url == null ? "" : url + key, HttpMethod.GET, null, new ParameterizedTypeReference<Object>() {
        });
        LinkedHashMap map = (LinkedHashMap) response.getBody();
        String secretVal = map.get("secret").toString();

        log.info("Retrieve Key Vault end.");
        return secretVal;
    }

    /**
     * Retrieve Key Vault Map.
     *
     * @param key
     * @return the vault string
     */
    public Map retrieveKeyVaultMap(String key) {

        log.info("Retrieve Key Vault Map start.");

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<?> response = restTemplate.exchange(url == null ? "" : url + "map/"+key, HttpMethod.GET, null, new ParameterizedTypeReference<Object>() {
        });
        LinkedHashMap map = (LinkedHashMap) response.getBody();

        log.info("Retrieve Key Vault Map end.");
        return map;
    }
}
