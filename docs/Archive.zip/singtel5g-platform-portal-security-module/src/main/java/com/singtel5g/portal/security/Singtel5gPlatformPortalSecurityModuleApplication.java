package com.singtel5g.portal.security;

import org.springframework.boot.SpringApplication;

/**
 * The type Singtel 5 g platform portal security module application.
 */
// @EnableAsync
// @SpringBootApplication
public class Singtel5gPlatformPortalSecurityModuleApplication {

  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    SpringApplication.run(Singtel5gPlatformPortalSecurityModuleApplication.class, args);
  }
}
