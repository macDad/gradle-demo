// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

package com.singtel5g.portal.security.authorization;

import com.singtel5g.portal.core.utils.LogUtils;
import com.singtel5g.portal.core.utils.RequestUtils;
import com.singtel5g.portal.security.component.AuthCheck;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.server.ResponseStatusException;


import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Create by : <B>Kushan@Singtel</B>
 *
 * <p>
 * Date : 18/3/2021<br>
 * Project : <B>singtel5g-platform-portal-security-module </B><br>
 * Since : version 5.03 <br>
 * </p>
 * Description : This uses to validate the user authorization to particular REST endpoint operation
 */
@Aspect
@Slf4j
@Component
public class AuthorizationValidator {

    @Autowired
    private AuthCheck authCheck;

    @Value("${5gplatform.auth.privileges.check:true}")
    private boolean authCheckOn;

    /**
     * AOP point cut to define the {@code: AuthorizationRequiredFor} annotation to validate user details
     * @param authorizationRequiredFor
     */
    @Pointcut("@annotation(authorizationRequiredFor)")
    public void validateRestEndpointPointCut(AuthorizationRequiredFor authorizationRequiredFor) {
    }

    /**
     * Validate given user details have required permission process the incoming request
     * @param proceedingJoinPoint
     * @param authorizationRequiredFor
     * @return
     * @throws Throwable
     */
    @Around("validateRestEndpointPointCut(authorizationRequiredFor)")
    public Object validateUser(ProceedingJoinPoint proceedingJoinPoint,
                               AuthorizationRequiredFor authorizationRequiredFor) throws Throwable{
        Object returnObject = null;

        boolean hasPermission = false;
        RequestUtils requestUtils = new RequestUtils();

        Set<String> hasAllPermission = new HashSet<>(Arrays.asList(authorizationRequiredFor.hasAllPermission()));
        Set<String> hasAnyPermission = new HashSet<>(Arrays.asList(authorizationRequiredFor.hasAnyPermission()));

        if(authCheckOn){
            if(!CollectionUtils.isEmpty(hasAllPermission)){
                log.debug("Evaluate hasALLPermission");
                hasPermission = authCheck.hasAllPermission(requestUtils.getRequestUserHeader(),hasAllPermission);
            }else if(!CollectionUtils.isEmpty(hasAnyPermission)){
                log.debug("Evaluate hasANYPermission");
                hasPermission = authCheck.hasAnyPermission(requestUtils.getRequestUserHeader(),hasAnyPermission);
            }
        }else{
            hasPermission = true;
        }


        if(hasPermission){
            returnObject = proceedingJoinPoint.proceed();
        }else {
            StringBuilder message = new StringBuilder();
            HttpServletRequest request = getCurrentHttpRequest();
            String endPoint = request.getContextPath();
            message.append("result :").append(AuthorizationConstant.StringConstant.UNAUTH_MESSAGE.value()).
                    append("[endPoint:").append(endPoint).append("]").
                    append("[method:").append(request.getMethod()).append("]").
                    append("[type:unauthorized]");
            LogUtils.INFO(this.getClass(), "authCheck", message.toString());
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,message.toString());
        }
        return returnObject;
    }

    /**
     * Return the current http request details
     * @return
     */
    @Nullable
    private HttpServletRequest getCurrentHttpRequest() {
        HttpServletRequest request = null;
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        if (requestAttributes != null && requestAttributes instanceof ServletRequestAttributes) {
            request = ((ServletRequestAttributes)requestAttributes).getRequest();
        }

        return request;
    }

}
