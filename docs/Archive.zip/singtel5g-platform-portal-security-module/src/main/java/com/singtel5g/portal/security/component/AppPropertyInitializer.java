package com.singtel5g.portal.security.component;
// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

import com.singtel5g.portal.core.utils.ObjectUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Create by    : <B>Udayanga@Singtel</B>
 *
 * <p>Date      : 07/05/2021<br>
 * Project      : <B>singtel5g-platform-portal-security-module</B><br>
 * Since        : version 6.0 <br></p>
 * Description  : The type AppPropertyInitializer.
 */


@Component
public class AppPropertyInitializer {


    @Autowired
    private Environment env;

    /**
     * key vaults interceptor
     */
    @Autowired
    KeyVaults keyVaults;


    /**
     * SSL Truststore Location.
     */
    @Value("${ssl.truststore.location.key}")
    public String SSL_TRUSTSTORE_LOCATION;


    /**
     * SSL Truststore password.
     */
    @Value("${ssl.truststore.password.key}")
    public String SSL_TRUSTSTORE_PASSWORD;


    /**
     * SSL Keystore Location.
     */
    @Value("${ssl.keystore.location.key}")
    public String SSL_KEYSTORE_LOCATION;


    /**
     * SSL Keystore password.
     */
    @Value("${ssl.keystore.password.key}")
    public String SSL_KEYSTORE_PASSWORD;


    /**
     * SSL Key password.
     */
    @Value("${ssl.key.password.key}")
    public String SSL_KEY_PASSWORD;


    /**
     * Mongo DB URI.
     */
    @Value("${spring.data.mongodb.uri.key}")
    public String MONGODB_URI;

    /**
     * Spring security username
     */
    @Value("${spring.security.user.name.key}")
    public String SPRING_SECURITY_USER_NAME_KEY;


    /**
     * Spring security password
     */
    @Value("${spring.security.user.password.key}")
    public String SPRING_SECURITY_USER_PASSWORD_KEY;


    /**
     * Bootstrap Servers Config.
     */
    @Value("${bootstrap.servers.config.key}")
    public String BOOTSTRAP_SERVERS_CONFIG;

    /** App Property Initialized **/
    private static boolean appPropertyInitialized = false;


    /** Load App property switch **/
    @Value("${5gplatform.load.app.property.check:true}")
    private boolean loadAppProp;


    @Bean
    public BeanPostProcessor entityManagerBeanPostProcessor() {
        return new BeanPostProcessor() {
            @Override
            public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {

                if (!env.getProperty("spring.application.name").equals("singtel5g-platform-portal-auth-service") && loadAppProp) {

                    StringBuilder requiredKeys = new StringBuilder();
                    requiredKeys.append(SSL_TRUSTSTORE_LOCATION).append(",");
                    requiredKeys.append(SSL_TRUSTSTORE_PASSWORD).append(",");
                    requiredKeys.append(SSL_KEYSTORE_LOCATION).append(",");
                    requiredKeys.append(SSL_KEYSTORE_PASSWORD).append(",");
                    requiredKeys.append(SSL_KEY_PASSWORD).append(",");
                    requiredKeys.append(MONGODB_URI).append(",");
                    requiredKeys.append(SPRING_SECURITY_USER_NAME_KEY).append(",");
                    requiredKeys.append(SPRING_SECURITY_USER_PASSWORD_KEY).append(",");
                    requiredKeys.append(BOOTSTRAP_SERVERS_CONFIG);

                    if (!appPropertyInitialized) {

                        Map secretMap = keyVaults.retrieveKeyVaultMap(requiredKeys.toString());

                        if (!ObjectUtils.isNullOrEmpty(secretMap)) {

                            appPropertyInitialized = true;

                            if (ObjectUtils.isNullOrEmpty(System.getProperty(SSL_TRUSTSTORE_LOCATION))) {
                                if (secretMap.containsKey(SSL_TRUSTSTORE_LOCATION)) {
                                    System.setProperty(SSL_TRUSTSTORE_LOCATION, secretMap.get(SSL_TRUSTSTORE_LOCATION).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(System.getProperty(SSL_TRUSTSTORE_PASSWORD))) {
                                if (secretMap.containsKey(SSL_TRUSTSTORE_PASSWORD)) {
                                    System.setProperty(SSL_TRUSTSTORE_PASSWORD, secretMap.get(SSL_TRUSTSTORE_PASSWORD).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(System.getProperty(SSL_KEYSTORE_LOCATION))) {
                                if (secretMap.containsKey(SSL_KEYSTORE_LOCATION)) {
                                    System.setProperty(SSL_KEYSTORE_LOCATION, secretMap.get(SSL_KEYSTORE_LOCATION).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(System.getProperty(SSL_KEYSTORE_PASSWORD))) {
                                if (secretMap.containsKey(SSL_KEYSTORE_PASSWORD)) {
                                    System.setProperty(SSL_KEYSTORE_PASSWORD, secretMap.get(SSL_KEYSTORE_PASSWORD).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(System.getProperty(SSL_KEY_PASSWORD))) {
                                if (secretMap.containsKey(SSL_KEY_PASSWORD)) {
                                    System.setProperty(SSL_KEY_PASSWORD, secretMap.get(SSL_KEY_PASSWORD).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(env.getProperty("spring.data.mongodb.uri"))
                                    && ObjectUtils.isNullOrEmpty(System.getProperty(MONGODB_URI))) {
                                if (secretMap.containsKey(MONGODB_URI)) {
                                    System.setProperty("spring.data.mongodb.uri", secretMap.get(MONGODB_URI).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(env.getProperty("spring.security.user.name"))
                                    && ObjectUtils.isNullOrEmpty(System.getProperty(SPRING_SECURITY_USER_NAME_KEY))) {
                                if (secretMap.containsKey(SPRING_SECURITY_USER_NAME_KEY)) {
                                    System.setProperty(SPRING_SECURITY_USER_NAME_KEY, secretMap.get(SPRING_SECURITY_USER_NAME_KEY).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(env.getProperty("spring.security.user.password"))
                                    && ObjectUtils.isNullOrEmpty(System.getProperty(SPRING_SECURITY_USER_PASSWORD_KEY))) {
                                if (secretMap.containsKey(SPRING_SECURITY_USER_PASSWORD_KEY)) {
                                    System.setProperty(SPRING_SECURITY_USER_PASSWORD_KEY, secretMap.get(SPRING_SECURITY_USER_PASSWORD_KEY).toString());
                                }
                            }

                            if (ObjectUtils.isNullOrEmpty(System.getProperty(BOOTSTRAP_SERVERS_CONFIG))) {
                                if (secretMap.containsKey(BOOTSTRAP_SERVERS_CONFIG)) {
                                    System.setProperty(BOOTSTRAP_SERVERS_CONFIG, secretMap.get(BOOTSTRAP_SERVERS_CONFIG).toString());
                                }
                            }
                        }
                    }
                }

                return bean;
            }
        };
    }
}
