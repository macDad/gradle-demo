// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************

package com.singtel5g.portal.security.component;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Create by : <B>Kushan@Singtel</B>
 *
 * <p>
 * Date : 18/3/2021<br>
 * Project : <B>singtel5g-platform-portal-security-module </B><br>
 * Since : version 5.03 <br>
 * </p>
 * Description : Rest Controller advices to properly propagate the HTTP status when the application throws an
 * exception
 */
@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * Handle all the ResponseStatusException in the application and return the HTTP status based on the error code
     * @param exception
     * @return
     */
    @ExceptionHandler({ ResponseStatusException.class })
    public ResponseEntity<Object> handleGeneralResponseStatusException(ResponseStatusException exception){
        return ResponseEntity.status(exception.getStatus()).body(exception.getMessage());
    }
}