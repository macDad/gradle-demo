package com.singtel5g.portal.dataapi.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * The type Singtel 5 g platform portal dataApi module application tests.
 */
@SpringBootTest
class ApplicationTests {

    /**
     * Context loads.
     */
    @Test
    void contextLoads() {
    }
}
