package com.singtel5g.portal.dataapi.core.consumer;

import org.springframework.stereotype.Component;

import java.util.concurrent.CountDownLatch;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/5/2020<br>
 * Description:
 */
@Component
public class DataApiConsumer {

    /**
     * The Latch.
     */
    public final CountDownLatch latch = new CountDownLatch(1);

    /**
     * Gets latch.
     *
     * @return the latch
   */
  public CountDownLatch getLatch() {
    return latch;
  }
}
