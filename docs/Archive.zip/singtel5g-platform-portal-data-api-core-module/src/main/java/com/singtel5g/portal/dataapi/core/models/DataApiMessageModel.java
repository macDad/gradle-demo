package com.singtel5g.portal.dataapi.core.models;


import com.singtel5g.portal.core.utils.ObjectUtils;
import lombok.*;

import java.io.Serializable;
import java.util.Map;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/5/2020<br>
 * Description: The class is used to construct DataApi data,
 *
 * <p>The standard format of DataApi data should be KEY/VALUE pair, <br>
 * the format looks like <b>Key1=Value1;Key2=Value2;</b>; <br>
 * For developer understand <b>topicName, groupId ,tableName, functionCode</b> are mandatory fields.
 * And all the dataApi values will be store in data field.
 */
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Setter
@Getter
public class DataApiMessageModel implements Serializable {
  private static final long serialVersionUID = 2405172041950251807L;
  private String topicName;
  private String groupId;
  private String functionCode;
  private Map<String, Object> data;

  /**
   * Add DataApi data under any scenario, including Create/Update/Delete transactions, <br>
   *
   * <p>Value is allowed for any type, which can be converted to JSON format
   *
   * @param data DataApi data
   * @return DataApiMessageModel dataApi message model
   */
  public DataApiMessageModel addStandardData(Map<String, Object> data) {
    if (!ObjectUtils.isNullOrEmpty(data)) {
      data.forEach((key, value) -> data.put(key, value));
    }
    return this;
  }
}
