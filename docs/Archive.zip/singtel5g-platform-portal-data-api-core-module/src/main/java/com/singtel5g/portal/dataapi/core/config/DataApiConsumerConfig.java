package com.singtel5g.portal.dataapi.core.config;

import com.singtel5g.portal.dataapi.core.common.utils.PropertyUtils;
import com.singtel5g.portal.dataapi.core.consumer.DataApiConsumer;
import com.singtel5g.portal.dataapi.core.models.DataApiMessageModel;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/5/2020<br>
 * Description:
 */
@Configuration
@EnableKafka
@EnableEncryptableProperties
public class DataApiConsumerConfig {

    @Autowired
    private PropertyUtils utils;

    @Value("${dataapi.group.id.config}")
    private String groupId;

    @Value("${auto.offset.reset.config}")
    private String autoOffsetResetConfig;

    @Value("${bootstrap.servers.config.key}")
    private String bootstrapServersConfig;

    @Value("${security.protocol}")
    private String securityProtocol;

    @Value("${ssl.truststore.location.key}")
    private String trustStoreLocation;

    @Value("${ssl.truststore.password.key}")
    private String trustStorePassword;

    @Value("${ssl.keystore.location.key}")
    private String keyStoreLocation;

    @Value("${ssl.keystore.password.key}")
    private String keyStorePassword;

    @Value("${ssl.key.password.key}")
    private String keyPassword;

    @Value("${ssl.enabled}")
    private boolean sslEnabled;

    /**
     * Kafka listener container factory concurrent kafka listener container factory.
     *
     * @return the concurrent kafka listener container factory
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, DataApiMessageModel>
    dataApiListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, DataApiMessageModel>
                concurrentKafkaListenerContainerFactory = new ConcurrentKafkaListenerContainerFactory<>();
        concurrentKafkaListenerContainerFactory.setConsumerFactory(dataApiConsumerFactory());
        return concurrentKafkaListenerContainerFactory;
    }

    /**
     * Consumer factory consumer factory.
     *
     * @return the consumer factory
     */
    @Bean
    public ConsumerFactory<String, DataApiMessageModel> dataApiConsumerFactory() {
        Map<String, Object> config = dataApiConsumerConfigs();

        return new DefaultKafkaConsumerFactory<>(
                config, new StringDeserializer(), new JsonDeserializer<>(DataApiMessageModel.class));
    }

    /**
     * Consumer configs map.
     *
     * @return the map
     */
    @Bean
    public Map<String, Object> dataApiConsumerConfigs() {
        Map<String, Object> config = new HashMap<>();
        // list of host:port pairs used for establishing the initial connections to the Kafka cluster
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, utils.getValue(bootstrapServersConfig));
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        // allows a pool of processes to divide the work of consuming and processing records
        config.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        // automatically reset the offset to the earliest offset
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetResetConfig);

        if (sslEnabled) {
            config.put("security.protocol", securityProtocol);
            config.put("ssl.truststore.location", utils.getValue(trustStoreLocation));
            config.put("ssl.truststore.password", utils.getValue(trustStorePassword));
            config.put("ssl.key.password", utils.getValue(keyPassword));
            config.put("ssl.keystore.password", utils.getValue(keyStorePassword));
            config.put("ssl.keystore.location", utils.getValue(keyStoreLocation));
            config.put("ssl.endpoint.identification.algorithm", "");
        }

        return config;
    }

    /**
     * Receiver dataApi log consumer.
     *
     * @return the dataApi log consumer
     */
    @Bean
    public DataApiConsumer dataApiReceiver() {
        return new DataApiConsumer();
    }
}
