package com.singtel5g.portal.dataapi.core.component;

import com.singtel5g.portal.dataapi.core.models.DataApiMessageModel;
import com.singtel5g.portal.dataapi.core.producer.DataApiProducer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 6/5/2020<br>
 * Description: Class {@code DataApiWriter} is used to manage the writing of dataApi log
 *
 * <p>DataApiWriter call DataApiMsgProducer methods to write dataApi log with some <br>
 * customized setting
 */
@Slf4j
@Component
public class DataApiWriter {
  /**
   * The Kafka message sender.
   */
  @Autowired
  DataApiProducer dataApiProducer;
  /**
   * The Topic name.
   */
  @Value("${kafka.topic.name}")
  private String topicName;
  /**
   * The Group id.
   */
  @Value("${dataapi.group.id.config}")
  private String groupId;

  @Value("${dataApi.enabled}")
  private boolean dataApiEnabled;

  /**
   * Perform dataApi log with necessary parameters
   *
   * @param functionCode the function code
   * @param payload      the payload
   */
  public void perform(String functionCode, Map<String, Object> payload) {
    log.info("Perform DataApi Writer start.");
    if (dataApiEnabled) {
      log.info(
              "prepared date to send topicName:'{}' groupId:'{}' tableName:'{}' functionCode:'{}' payload:'{}'",
              topicName,
              groupId,
              functionCode,
              payload);
      DataApiMessageModel kafkaMessageModel =
              new DataApiMessageModel(topicName, groupId, functionCode, payload);

      dataApiProducer.send(topicName, kafkaMessageModel);

      log.info("Preform DataApi Event end.");
    } else log.info(">>>>> >>>> >>> >> > DataApi not enabled.");
  }

  /**
   * Perform dataApi log with necessary parameters
   *
   * @param topicName    the topic name
   * @param groupId      the group id
   * @param functionCode the function code
   * @param payload      the payload
   */
  public void perform(String topicName, String groupId, String functionCode, Map<String, Object> payload) {
    log.info("Perform DataApi Writer start.");
    if (dataApiEnabled) {
      log.info(
              "prepared date to send topicName:'{}' groupId:'{}' tableName:'{}' functionCode:'{}' payload:'{}'",
              topicName,
              groupId,
              functionCode,
              payload);
      DataApiMessageModel kafkaMessageModel =
              new DataApiMessageModel(topicName, groupId, functionCode, payload);

      dataApiProducer.send(topicName, kafkaMessageModel);

      log.info("Preform DataApi Event end.");
    } else log.info(">>>>> >>>> >>> >> > DataApi not enabled.");
  }
}
