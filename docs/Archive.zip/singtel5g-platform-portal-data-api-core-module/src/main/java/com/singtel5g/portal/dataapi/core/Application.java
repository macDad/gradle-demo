package com.singtel5g.portal.dataapi.core;

import com.singtel5g.portal.dataapi.core.producer.DataApiProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;

/**
 * The type Singtel 5 g platform portal dataApi module application.
 */
// @EnableAsync
// @SpringBootApplication
public class Application {
  /**
   * The Data api log producer.
   */
  @Autowired
  DataApiProducer dataApiMsgProducer;

  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }
}
