// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.dataapi.core.bean;

import com.singtel5g.portal.core.utils.ObjectUtils;
import com.singtel5g.portal.dataapi.core.common.utils.UniqueKeyUtils;
import com.singtel5g.portal.dataapi.core.enums.FlowStepsStatues;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.springframework.util.StringUtils.isEmpty;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 7/12/2020<br>
 * Project      : <B>5g-platform-portal-core-modules </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link  CoreSchedulerMsgBean} use for
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CoreSchedulerMsgBean implements Serializable {
    private static final long serialVersionUID = 1905122041950251207L;
    @NotEmpty
    private long uniqueID;
    @NotEmpty
    private String uniqueKey;
    @NotEmpty
    private String orgCode;
    @NotEmpty
    private String jobType;
    @NotEmpty
    private String eventTopic;

    private FlowStepsStatues status;

    private Map<String, Object> metaData = new LinkedHashMap<>();

    private Map<String, Object> jobData = new LinkedHashMap<>();
    private Map<Integer, FlowSteps> stepsData = new LinkedHashMap<>();

    /**
     * Sets step data.
     *
     * @param flowSteps the flow steps
     */
    public void setStepData(FlowSteps flowSteps) {
        if (ObjectUtils.isNullOrEmpty(stepsData)) {
            stepsData.put(1, flowSteps);
        } else {
            Integer maxKey = stepsData.keySet()
                    .stream()
                    .filter(key -> key >= 0)
                    .max(Comparator.naturalOrder())
                    .orElse(0);
            stepsData.put(maxKey + 1, flowSteps);
        }
    }

    /**
     * Build unique id long.
     */
    public void buildUniqueID() {
        this.uniqueID = uniqueID == 0 ? UniqueKeyUtils.generateUniqueLongId() : uniqueID;
    }

    /**
     * Build unique key string.
     *
     * @param mainKey the main key
     * @param subKey  the sub key
     */
    public void buildUniqueKey(String mainKey, String subKey) {
        this.uniqueKey = isEmpty(uniqueKey) ? UniqueKeyUtils.generateUniqueKey(mainKey, subKey) : uniqueKey;
    }
}
