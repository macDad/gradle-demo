package com.singtel5g.portal.dataapi.core.adminClient;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.CreateAclsResult;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.kafka.common.KafkaFuture;
import org.apache.kafka.common.acl.AccessControlEntry;
import org.apache.kafka.common.acl.AclBinding;
import org.apache.kafka.common.acl.AclOperation;
import org.apache.kafka.common.acl.AclPermissionType;
import org.apache.kafka.common.resource.PatternType;
import org.apache.kafka.common.resource.ResourcePattern;
import org.apache.kafka.common.resource.ResourceType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;

/**
 * Create by: yongsheng.kng@Singtel
 *
 * <p>Date: 21/01/2021<br>
 * Description: Class {@code DataApiAdminClient} is used to manage the Kafka topic authorization <br>
 *
 */
@Slf4j
@Service
public class DataApiAdminClient {

    private AdminClient adminClient;

    private final Map<String, Object> dataApiAdminClientConfigs;

    private static final String PRINCIPAL_NAME_PREFIX = "User:CN=";

    private static final String HOST = "*";

    @Value("${keystore.owner}")
    private String keystoreOwner;

    /**
     * Instantiates a new Data api Kafka admin client.
     *
     * @param properties    the Kafka admin client configuration
     */
    @Autowired
    public DataApiAdminClient(Map<String, Object> properties) {
        this.dataApiAdminClientConfigs = (Map<String, Object>) properties.get("dataApiProducerConfigs");
    }

    /**
    * Add ACL to Kafka topic
    *
    * @param topicName the topic name
    * @param org   the organization code
    */
    public void createAcls(String topicName, String org)
          throws ExecutionException, InterruptedException {
      log.info("Perform create ACL - start");

      //Init Admin Client
      this.adminClient = AdminClient.create(this.dataApiAdminClientConfigs);

      //Check if new topic. If new topic, add ACL authorization.
      if(!isTopicExisted(topicName)){
        log.info(topicName + " is a new topic. Add new ACL is required.");
        List<AclBinding> aclList = new ArrayList<>();

        ResourcePattern resourcePattern = new ResourcePattern(
                ResourceType.TOPIC, topicName, PatternType.LITERAL);

        AccessControlEntry writeAccess = new AccessControlEntry(
                PRINCIPAL_NAME_PREFIX + keystoreOwner, HOST, AclOperation.WRITE, AclPermissionType.ALLOW);

        AccessControlEntry readAccess = new AccessControlEntry(
                PRINCIPAL_NAME_PREFIX + org, HOST, AclOperation.READ, AclPermissionType.ALLOW);

        AclBinding writeAcl = new AclBinding(resourcePattern, writeAccess);
        AclBinding readAcl = new AclBinding(resourcePattern, readAccess);

        aclList.add(writeAcl);
        aclList.add(readAcl);

        CreateAclsResult result = adminClient.createAcls(aclList);

        //Wait for create acl result
        for (KafkaFuture<Void> future : result.values().values()){
            future.get();
        }

        //Check create acl status. If create fails, throw exception.
        for(AclBinding aclBinding : result.values().keySet()){
            KafkaFuture<Void> kafkaFuture = result.values().get(aclBinding);
            log.info("Add " + aclBinding.entry() + " success:" + kafkaFuture.isDone());
            if(!kafkaFuture.isDone()){
                throw new ExecutionException(new Exception("Add ACL Failed: " + aclBinding.entry()));
            }
        }
      }
      //Close Admin Client
      this.adminClient.close();
      log.info("Perform create ACL - end");
    }

    /**
     * Check if topic exists
     *
     * @param topicName the topic name
     */
    private boolean isTopicExisted(String topicName)
          throws ExecutionException, InterruptedException {
      log.info("Perform is topic existed check - start");
      Set<String> topics = adminClient.listTopics(new ListTopicsOptions()).names().get();
      log.info("Perform is topic existed check - end");
      return topics.contains(topicName);
    }
}
