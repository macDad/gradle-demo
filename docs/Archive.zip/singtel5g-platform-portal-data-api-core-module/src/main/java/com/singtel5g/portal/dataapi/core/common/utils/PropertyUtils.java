package com.singtel5g.portal.dataapi.core.common.utils;

import com.singtel5g.portal.core.utils.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component
public class PropertyUtils {

    @Autowired
    private Environment env;

    /**
     * Evaluate whether a property should be loaded from
     * Spring property file or from system properties ( keyvault)
     *
     * @param input the input
     * @return the value
     */
    public String getValue(String input) {
        Boolean isSystemLoadProp = ObjectUtils.isNullOrEmpty(env.getProperty("5gplatform.load.app.property.check")) ||
                !Boolean.valueOf(env.getProperty("5gplatform.load.app.property.check"));

        return Boolean.TRUE.equals(isSystemLoadProp) ? System.getProperty(input) : env.getProperty(input);
    }
}
