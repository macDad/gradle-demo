// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.dataapi.core.common.utils;

import com.singtel5g.portal.core.utils.StringUtils;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

/**
 * Created by   : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 6/12/2020<br>
 * Project      : <B>5g-platform-portal-core-modules </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : This class {@link  UniqueKeyUtils} use as Global factory that can be used to create Unique Key
 */
@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class UniqueKeyUtils {
    /**
     * The constant DATA_API_CODE_PREFIX.
     */
    public static final String DATA_API_CODE_PREFIX = "DATA_API";
    /**
     * The constant DATE_TIME_FORMAT.
     */
    private static final String DATE_TIME_FORMAT = "yyMMddkkmmss";
    /**
     * The constant SEQUENCE_MAX.
     */
    private static final long SEQUENCE_MAX = 1000;
    /**
     * The constant FORMAT.
     */
    private static final String FORMAT = "%03d";
    /**
     * The constant lastTimeStamp.
     */
    private static volatile long lastTimeStamp = -1L;

    /**
     * The constant sequence.
     */
    private static volatile long sequence = 0L;

    /**
     * Generate Order id string.
     *
     * @return the string
     */
    public static String generateUniqueKey() {
        return generateUniqueKey(DATA_API_CODE_PREFIX, "DEF");
    }

    /**
     * Generate Order id string.
     *
     * @param mainKey the order code prefix
     * @param subKey  the vendor code prefix
     * @return the string
     */
    public static String generateUniqueKey(String mainKey, String subKey) {
        var randomString = StringUtils.getAlphaNumericString(4).toUpperCase();
        return String.format(
                "%s%s-%s%s", mainKey, subKey, randomString, generateUniqueStringId());
    }

    /**
     * /**
     * Generate long id string.
     *
     * @return the string
     */
    public static synchronized String generateUniqueStringId() {
        long timestamp = getCurrentDateTime();
        if (lastTimeStamp == timestamp) {
            sequence = (sequence + 1) % SEQUENCE_MAX;
            if (sequence == 0) {
                timestamp = tillNextMillis(lastTimeStamp);
            }
        } else {
            sequence = 0;
        }
        lastTimeStamp = timestamp;
        return timestamp + String.format(FORMAT, sequence);
    }

    /**
     * Till next millis long.
     *
     * @param lastTimestamp the last timestamp
     * @return the long
     */
    private static long tillNextMillis(long lastTimestamp) {
        long timestamp = getCurrentDateTime();
        while (timestamp <= lastTimestamp) {
            timestamp = getCurrentDateTime();
        }
        return timestamp;
    }

    /**
     * Gets current date time.
     *
     * @return the current date time
     */
    private static long getCurrentDateTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        LocalDateTime localDateTime = LocalDateTime.now();
        String ldtString = formatter.format(localDateTime);
        return Long.parseLong(Optional.of(ldtString).orElseGet(() -> "1"));
    }

    public static synchronized Long generateUniqueLongId() {
        return Long.valueOf(generateUniqueStringId());
    }
}
