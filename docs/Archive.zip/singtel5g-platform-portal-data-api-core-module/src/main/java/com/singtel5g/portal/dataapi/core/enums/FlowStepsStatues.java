// *************************************************************************************************
//
// PROJECT : Paragon 5G Platform™
// PRODUCT : Paragon 5G Platform™ - Backend
// ************************************************************************************************
//
// Copyright(C) 2020 Singapore Telecommunications Limited
// All rights reserved.
//
// This source code and all binaries derived from this source code here is intended for the sole
// use of Singapore Telecommunications Limited and contains information that is confidential
// and/or proprietary to the Singtel Group. Any use of the information contained herein (including,
// but not limited to, total or partial reproduction, communication, or dissemination in any form)
// by persons other than the employees of Singapore Telecommunications Limited is prohibited.
//
// *************************************************************************************************
package com.singtel5g.portal.dataapi.core.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Create by    : <B>MadukaJ@Singtel</B>
 *
 * <p>Date      : 11/10/2020<br>
 * Project      : <B>5g-platform-portal-core-modules </B><br>
 * Since        : version 1.0 <br></p>
 * Description  : {@code FlowStepsStatues} enum is use to manage Flow Steps Statues types within tha application *
 *
 * <p>usage Examples: * *
 *
 * <pre>
 *  *  FlowStepsStatues types = FlowStepsStatues.SUCCESS;
 *  *    types.statusTypeCode()          //SUCCESS
 *  *    types.getDbValue()             //0
 *  *    types.getJsonValue()           //SUCCESS
 *  *  </pre>
 */
@Getter
@AllArgsConstructor
public enum FlowStepsStatues {

    INITIAL("INITIAL", 0, "initial"),
    START("START", 1, "start"),
    FAIL("FAIL", 2, "fail"),
    SUCCESS("SUCCESS", 3, "success");
    private final String statusTypeCode;
    private final int dbValue;
    private final String jsonValue;
}
