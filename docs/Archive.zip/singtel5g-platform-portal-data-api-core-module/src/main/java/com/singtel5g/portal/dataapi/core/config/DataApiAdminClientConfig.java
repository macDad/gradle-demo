package com.singtel5g.portal.dataapi.core.config;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Create by: yongsheng.kng@Singtel
 *
 * <p>Date: 21/1/2021<br>
 * Description: Kafka Admin Client Configuration
 */
@Configuration
@EnableKafka
@EnableEncryptableProperties
public class DataApiAdminClientConfig {

    @Value("${bootstrap.servers.config.key}")
    private String bootstrapServersConfig;

    @Value("${security.protocol}")
    private String securityProtocol;

    @Value("${ssl.truststore.location.key}")
    private String trustStoreLocation;

    @Value("${ssl.truststore.password.key}")
    private String trustStorePassword;

    @Value("${ssl.keystore.location.key}")
    private String keyStoreLocation;

    @Value("${ssl.keystore.password.key}")
    private String keyStorePassword;

    @Value("${ssl.key.password.key}")
    private String keyPassword;

    @Value("${ssl.enabled}")
    private boolean sslEnabled;

    /**
     * Admin Client configs map.
     *
     * @return the map
     */
    @Bean
    public Map<String, Object> dataApiAdminClientConfigs() {
        Map<String, Object> props = new HashMap<>();
        // list of host:port pairs used for establishing the initial connections to the Kakfa cluster
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, System.getProperty(bootstrapServersConfig));
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        if (sslEnabled) {
            props.put("security.protocol", securityProtocol);
            props.put("ssl.truststore.location", System.getProperty(trustStoreLocation));
            props.put("ssl.truststore.password", System.getProperty(trustStorePassword));
            props.put("ssl.key.password", System.getProperty(keyPassword));
            props.put("ssl.keystore.password", System.getProperty(keyStorePassword));
            props.put("ssl.keystore.location", System.getProperty(keyStoreLocation));
            props.put("ssl.endpoint.identification.algorithm", "");
        }

    return props;
  }
}
