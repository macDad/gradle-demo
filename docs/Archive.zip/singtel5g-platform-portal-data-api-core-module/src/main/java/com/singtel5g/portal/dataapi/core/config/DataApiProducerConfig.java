package com.singtel5g.portal.dataapi.core.config;

import com.singtel5g.portal.dataapi.core.common.utils.PropertyUtils;
import com.singtel5g.portal.dataapi.core.models.DataApiMessageModel;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/5/2020<br>
 * Description:
 */
@Configuration
@EnableKafka
@EnableEncryptableProperties
public class DataApiProducerConfig {

    @Autowired
    private PropertyUtils utils;

    @Value("${bootstrap.servers.config.key}")
    private String bootstrapServersConfig;

    @Value("${security.protocol}")
    private String securityProtocol;

    @Value("${ssl.truststore.location.key}")
    private String trustStoreLocation;

    @Value("${ssl.truststore.password.key}")
    private String trustStorePassword;

    @Value("${ssl.keystore.location.key}")
    private String keyStoreLocation;

    @Value("${ssl.keystore.password.key}")
    private String keyStorePassword;

    @Value("${ssl.key.password.key}")
    private String keyPassword;

    @Value("${ssl.enabled}")
    private boolean sslEnabled;

    /**
     * Kafka template kafka template.
     *
     * @return the kafka template
     */
    @Bean
    public KafkaTemplate<String, DataApiMessageModel> dataApiTemplate() {
        return new KafkaTemplate<>(dataApiProducerFactory());
    }

    /**
     * Producer factory producer factory.
     *
     * @return the producer factory
     */
    @Bean
    public ProducerFactory<String, DataApiMessageModel> dataApiProducerFactory() {
        return new DefaultKafkaProducerFactory<>(dataApiProducerConfigs());
    }

    /**
     * Producer configs map.
     *
     * @return the map
     */
    @Bean
    public Map<String, Object> dataApiProducerConfigs() {
        Map<String, Object> props = new HashMap<>();
        // list of host:port pairs used for establishing the initial connections to the Kakfa cluster
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, utils.getValue(bootstrapServersConfig));
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        if (sslEnabled) {
            props.put("security.protocol", securityProtocol);
            props.put("ssl.truststore.location", utils.getValue(trustStoreLocation));
            props.put("ssl.truststore.password", utils.getValue(trustStorePassword));
            props.put("ssl.key.password", utils.getValue(keyPassword));
            props.put("ssl.keystore.password", utils.getValue(keyStorePassword));
            props.put("ssl.keystore.location", utils.getValue(keyStoreLocation));
            props.put("ssl.endpoint.identification.algorithm", "");
        }
        return props;
    }
}
