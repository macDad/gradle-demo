package com.singtel5g.portal.dataapi.core.producer;

import com.singtel5g.portal.dataapi.core.models.DataApiMessageModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaAdmin;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * Create by: MadukaJ@Singtel
 *
 * <p>Date: 4/5/2020<br>
 * Description: Class {@code DataApiMsgProducer} is used to manage the writing of <br>
 * dataApi log
 *
 * <p>LoggingWriter call NGCC API to write dataApi log with some <br>
 * customerized setting
 */
@Slf4j
@Service
public class DataApiProducer {
    private final KafkaTemplate<String, DataApiMessageModel> kafkaTemplate;

    private final KafkaAdmin kafkaAdmin;

    /**
     * Instantiates a new Data api log producer.
     *
     * @param kafkaAdmin    the kafka admin
     * @param kafkaTemplate the kafka template
     */
    @Autowired
    public DataApiProducer(KafkaAdmin kafkaAdmin,
                           KafkaTemplate<String, DataApiMessageModel> kafkaTemplate) {
        this.kafkaAdmin = kafkaAdmin;
        this.kafkaTemplate = kafkaTemplate;
    }

  /**
   * Perform dataApi log with necessary parameters.
   *
   * @param topicName the topic name
   * @param payload   the payload
   */
  public void send(String topicName, DataApiMessageModel payload) {

    log.info("Perform DataApi Event start.");
    log.info("sending payload='{}'", payload);
    kafkaTemplate.send(topicName, payload);
    log.info("Preform DataApi Event end.");
  }
}
