## Singtel 5G Platform Portal DataApi Module

##### This is a library module to use as an dataApi framework support for java projects.

If you change anything in this module please update the version and publish it to the artifactory server.

command to publish

`gradle clean build artifactoryPublish`